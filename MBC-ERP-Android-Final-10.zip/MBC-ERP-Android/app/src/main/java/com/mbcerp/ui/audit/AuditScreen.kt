package com.mbcerp.ui.audit

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.domain.calc.ValidationEngine
import com.mbcerp.repository.AuditRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/** AUDIT / VALIDATION SCREEN (AUDIT §2.11 "Audit Sheet"). Self-diagnostic only -- creates no data. */
class AuditViewModel(private val auditRepository: AuditRepository) : ViewModel() {
    private val _results = MutableStateFlow<List<ValidationEngine.AuditResult>>(emptyList())
    val results: StateFlow<List<ValidationEngine.AuditResult>> = _results
    private val _checking = MutableStateFlow(false)
    val checking: StateFlow<Boolean> = _checking

    fun runChecks() = viewModelScope.launch {
        _checking.value = true
        _results.value = auditRepository.runAllChecks()
        _checking.value = false
    }
}

class AuditViewModelFactory(private val auditRepository: AuditRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = AuditViewModel(auditRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditScreen(vm: AuditViewModel) {
    val results by vm.results.collectAsState()
    val checking by vm.checking.collectAsState()
    LaunchedEffect(Unit) { vm.runChecks() }

    Scaffold(topBar = { TopAppBar(title = { Text("Audit / Validation") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            val failCount = results.count { !it.ok }
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(
                    containerColor = if (failCount == 0) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.errorContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (failCount == 0) Icons.Default.CheckCircle else Icons.Default.Error,
                        contentDescription = null,
                        tint = if (failCount == 0) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            if (failCount == 0) "সব চেক পাশ" else "$failCount টা চেক-এ সমস্যা",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (failCount == 0) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            "${results.size} টা check চালানো হয়েছে",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (failCount == 0) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(results) { r ->
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                            leadingContent = {
                                Icon(
                                    if (r.ok) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (r.ok) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
                                )
                            },
                            headlineContent = { Text(r.check) },
                            supportingContent = r.detail?.let { { Text(it) } }
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { vm.runChecks() }, enabled = !checking, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (checking) "চেক করা হচ্ছে…" else "Re-run Checks")
            }
        }
    }
}
