package com.mbcerp.ui.cash

import androidx.compose.ui.res.stringResource

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.dao.CompanyProfileDao
import com.mbcerp.data.entity.CashSummaryAdjustmentEntity
import com.mbcerp.domain.calc.CashWaterfallCalculator
import com.mbcerp.domain.calc.ProfitDistributionCalculator
import com.mbcerp.repository.CashSummaryRepository
import com.mbcerp.repository.SetupRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * CASH SUMMARY SCREEN (Phase 6, AUDIT §2.7). Shows the full waterfall chain (never
 * just the final number) plus an editable Manual Adjustments form (Decision D2 --
 * replaces every hardcoded blue cell from the source sheet, e.g. the old "+10500")
 * and the 16-Anna profit distribution table.
 */
class CashSummaryViewModel(
    private val cashSummaryRepository: CashSummaryRepository,
    private val setupRepository: SetupRepository
) : ViewModel() {

    private val _waterfall = MutableStateFlow<CashWaterfallCalculator.WaterfallResult?>(null)
    val waterfall: StateFlow<CashWaterfallCalculator.WaterfallResult?> = _waterfall

    private val _profitShares = MutableStateFlow<List<ProfitDistributionCalculator.PartnerShare>>(emptyList())
    val profitShares: StateFlow<List<ProfitDistributionCalculator.PartnerShare>> = _profitShares

    private val _adjustments = MutableStateFlow<CashSummaryAdjustmentEntity?>(null)
    val adjustments: StateFlow<CashSummaryAdjustmentEntity?> = _adjustments

    fun load() = viewModelScope.launch {
        _waterfall.value = cashSummaryRepository.compute()
        val partners = setupRepository.observePartners().first()
        val netProfit = cashSummaryRepository.netProfit()
        _profitShares.value = ProfitDistributionCalculator.distribute(
            netProfit = netProfit,
            partners = partners.map { it.name to it.shareAnna }
        )
        val profile = setupRepository.observeCompanyProfile().first()
        _adjustments.value = cashSummaryRepository.getAdjustments(profile?.season ?: "2025-26")
    }

    fun saveAdjustments(a: CashSummaryAdjustmentEntity) = viewModelScope.launch {
        cashSummaryRepository.saveAdjustments(a)
        load()
    }
}

class CashSummaryViewModelFactory(
    private val cashSummaryRepository: CashSummaryRepository,
    private val setupRepository: SetupRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = CashSummaryViewModel(cashSummaryRepository, setupRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CashSummaryScreen(vm: CashSummaryViewModel) {
    val waterfall by vm.waterfall.collectAsState()
    val shares by vm.profitShares.collectAsState()
    val adjustments by vm.adjustments.collectAsState()
    var showEditDialog by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.load() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Cash Summary") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showEditDialog = true }) { Text("Edit Adjustments") }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            waterfall?.let { w ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Cash Waterfall", style = MaterialTheme.typography.titleMedium)
                        WaterfallLine("Total Sales + Capital + Adjustment", w.totalSalesAndCapital)
                        WaterfallLine("(-) Total Expense", -w.totalExpense)
                        WaterfallLine("= Current Cash (before due)", w.currentCashBeforeDue, bold = true)
                        WaterfallLine("(-) Partner Due", -w.partnerDue)
                        WaterfallLine("(-) Customer Due", -w.customerDue)
                        WaterfallLine("(-) 2024-25 Old Party Due", -w.oldPartyDue2024_25)
                        WaterfallLine("(-) Forward Due", -w.forwardDue)
                        WaterfallLine("(-) Other Adjustments", -w.otherAdjustments)
                        Divider(Modifier.padding(vertical = 4.dp))
                        WaterfallLine("FINAL CASH IN HAND", w.finalCashInHand, bold = true)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("16-Anna Profit Distribution", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.heightIn(max = 300.dp)) {
                items(shares) { s ->
                    ListItem(
                        headlineContent = { Text(s.partnerName) },
                        supportingContent = { Text("Share: ${s.shareAnna}/16 Ana  |  Profit Share: ৳${"%,.2f".format(s.profitShare)}") }
                    )
                    Divider()
                }
            }
            Text("Total Distributed: ৳${"%,.2f".format(shares.sumOf { it.profitShare })}", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(72.dp)) // room for the FAB
        }
    }

    if (showEditDialog && adjustments != null) {
        AdjustmentsEditDialog(current = adjustments!!, onDismiss = { showEditDialog = false }, onSave = {
            vm.saveAdjustments(it); showEditDialog = false
        })
    }
}

@Composable
private fun AdjustmentsEditDialog(
    current: CashSummaryAdjustmentEntity,
    onDismiss: () -> Unit,
    onSave: (CashSummaryAdjustmentEntity) -> Unit
) {
    var seasonFixed by remember { mutableStateOf(current.seasonFixedAdjustment.toString()) }
    var advanceNextYear by remember { mutableStateOf(current.advanceExpenseNextYear.toString()) }
    var coalDeposit by remember { mutableStateOf(current.coalRelatedDeposit.toString()) }
    var priorYearReturn by remember { mutableStateOf(current.priorYearDueReturn.toString()) }
    var oldDuePool by remember { mutableStateOf(current.oldDueStartingPool.toString()) }
    var forwardDue by remember { mutableStateOf(current.forwardDue.toString()) }
    var otherAdj by remember { mutableStateOf(current.otherAdjustments.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Manual Adjustments (Decision D2)") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("এই সব ফিল্ড Excel-এর Cash Summary sheet-এর ম্যানুয়াল (নীল) সেল -- এখানে কোনো hardcoded সংখ্যা নেই, সব editable।", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(seasonFixed, { seasonFixed = it }, label = { Text("Season Fixed Adjustment (আগের +10500)") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(advanceNextYear, { advanceNextYear = it }, label = { Text("Advance Expense for Next Year") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(coalDeposit, { coalDeposit = it }, label = { Text("Coal-related Deposit") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(priorYearReturn, { priorYearReturn = it }, label = { Text("Prior Year Due Return") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(oldDuePool, { oldDuePool = it }, label = { Text("2024-25 Old Due Starting Pool") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(forwardDue, { forwardDue = it }, label = { Text("Forward Due") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(otherAdj, { otherAdj = it }, label = { Text("Other Adjustments") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    current.copy(
                        seasonFixedAdjustment = seasonFixed.toDoubleOrNull() ?: 0.0,
                        advanceExpenseNextYear = advanceNextYear.toDoubleOrNull() ?: 0.0,
                        coalRelatedDeposit = coalDeposit.toDoubleOrNull() ?: 0.0,
                        priorYearDueReturn = priorYearReturn.toDoubleOrNull() ?: 0.0,
                        oldDueStartingPool = oldDuePool.toDoubleOrNull() ?: 0.0,
                        forwardDue = forwardDue.toDoubleOrNull() ?: 0.0,
                        otherAdjustments = otherAdj.toDoubleOrNull() ?: 0.0
                    )
                )
            }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
    )
}

@Composable
private fun WaterfallLine(label: String, value: Double, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = if (bold) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium)
        Text("৳${"%,.2f".format(value)}", style = if (bold) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium)
    }
}
