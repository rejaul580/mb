package com.mbcerp.ui.print

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.SaleEntity
import com.mbcerp.pdf.PdfGenerator
import com.mbcerp.repository.PrintRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * DELIVERY CHALLAN + MONEY RECEIPT (Phase-4: real PDF output added, item 8; Money
 * Receipt <-> Extra Payment link added, Decision D5). Delivery Challan is a pure
 * read-only voucher lookup (creates no data, exactly like the source sheet); its PDF
 * export is likewise read-only. Money Receipt can now optionally write a matching
 * Extra Payment row when the user explicitly opts in via the on-screen toggle --
 * never silent, never automatic without confirmation.
 */
class DeliveryChallanViewModel(private val printRepository: PrintRepository) : ViewModel() {
    private val _sale = MutableStateFlow<SaleEntity?>(null)
    val sale: StateFlow<SaleEntity?> = _sale
    private val _notFound = MutableStateFlow(false)
    val notFound: StateFlow<Boolean> = _notFound

    fun lookup(voucherNo: String) = viewModelScope.launch {
        val result = printRepository.findByVoucher(voucherNo)
        _sale.value = result
        _notFound.value = result == null
    }
}

class DeliveryChallanViewModelFactory(private val printRepository: PrintRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = DeliveryChallanViewModel(printRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryChallanScreen(vm: DeliveryChallanViewModel) {
    var voucherNo by remember { mutableStateOf("") }
    val sale by vm.sale.collectAsState()
    val notFound by vm.notFound.collectAsState()
    val context = LocalContext.current

    Scaffold(topBar = { TopAppBar(title = { Text("Delivery Challan") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Row {
                OutlinedTextField(voucherNo, { voucherNo = it }, label = { Text("Voucher No") }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Button(onClick = { vm.lookup(voucherNo) }) { Text("খুঁজুন") }
            }
            Spacer(Modifier.height(16.dp))
            if (notFound) Text("এই Voucher No-তে কোনো বিক্রয় পাওয়া যায়নি।", color = MaterialTheme.colorScheme.error)
            sale?.let { s ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("DELIVERY CHALLAN", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        Text("Date: ${s.date}")
                        Text("Voucher No: ${s.voucherNo}")
                        Text("Truck No: ${s.truckNo ?: "-"}")
                        Text("Party: ${s.partyName} (${s.partyType})")
                        Text("Location: ${s.location ?: "-"}")
                        Text("Brick Category: ${s.brickCategory}")
                        Text("Quantity: ${s.quantity}")
                        Text("Amount: ৳${s.amount}")
                        Text("(এই স্ক্রিন Sales Register থেকে read-only lookup -- কোনো নতুন ডেটা তৈরি করে না, Excel-এর মতোই)", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = {
                            val file = PdfGenerator.generateDeliveryChallan(context, s, "MBC Brickfield")
                            val uri = PdfGenerator.shareUriFor(context, file)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(intent, "Delivery Challan শেয়ার/প্রিন্ট করুন"))
                        }) { Text("PDF তৈরি করে শেয়ার/প্রিন্ট করুন") }
                    }
                }
            }
        }
    }
}

class MoneyReceiptViewModel(private val printRepository: PrintRepository) : ViewModel() {
    fun linkAsExtraPayment(partyType: String, partyName: String, date: String, amount: Double, remarks: String?) {
        viewModelScope.launch { printRepository.recordAsExtraPayment(partyType, partyName, date, amount, remarks) }
    }
}

class MoneyReceiptViewModelFactory(private val printRepository: PrintRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = MoneyReceiptViewModel(printRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoneyReceiptScreen(vm: MoneyReceiptViewModel) {
    val context = LocalContext.current
    var receiptNo by remember { mutableStateOf("MR-${System.currentTimeMillis() % 100000}") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var receivedFrom by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var against by remember { mutableStateOf("Customer/Party Due Collection") }
    var remarks by remember { mutableStateOf("") }
    var linkPartyType by remember { mutableStateOf("Customer") }
    var linkToLedger by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    Scaffold(topBar = { TopAppBar(title = { Text("Money Receipt") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(receiptNo, { receiptNo = it }, label = { Text("Receipt No") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(date, { date = it }, label = { Text("Date") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(receivedFrom, { receivedFrom = it }, label = { Text("Received From") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(against, { against = it }, label = { Text("Received Against") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(remarks, { remarks = it }, label = { Text("Remarks") }, modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(12.dp))
            Card {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = linkToLedger, onCheckedChange = { linkToLedger = it })
                        Text("এই receipt-টা Customer/Partner Ledger-এর Extra Payment হিসেবেও যোগ করুন (Decision D5)")
                    }
                    if (linkToLedger) {
                        Row {
                            FilterChip(selected = linkPartyType == "Customer", onClick = { linkPartyType = "Customer" }, label = { Text("Customer") })
                            Spacer(Modifier.width(8.dp))
                            FilterChip(selected = linkPartyType == "Partner", onClick = { linkPartyType = "Partner" }, label = { Text("Partner") })
                        }
                        Text("(এখানে 'Received From'-এর নামটাই Customer/Partner Ledger-এর ঠিক নাম হতে হবে)", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                val amt = amount.toDoubleOrNull() ?: 0.0
                if (linkToLedger && receivedFrom.isNotBlank()) {
                    vm.linkAsExtraPayment(linkPartyType, receivedFrom, date, amt, remarks.ifBlank { "Money Receipt $receiptNo" })
                }
                val file = PdfGenerator.generateMoneyReceipt(
                    context,
                    PdfGenerator.MoneyReceiptData(
                        receiptNo = receiptNo, date = date, receivedFrom = receivedFrom, mobile = mobile.ifBlank { null },
                        amount = amt, amountInWords = "৳$amt", receivedAgainst = against, remarks = remarks.ifBlank { null }
                    ),
                    "MBC Brickfield"
                )
                val uri = PdfGenerator.shareUriFor(context, file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Money Receipt শেয়ার/প্রিন্ট করুন"))
                saved = true
            }, modifier = Modifier.fillMaxWidth()) { Text("PDF তৈরি করে শেয়ার/প্রিন্ট করুন") }
            if (saved) Text("✓ সেভ হয়েছে" + if (linkToLedger) " এবং Ledger-এ যোগ হয়েছে" else "", color = MaterialTheme.colorScheme.primary)
        }
    }
}
