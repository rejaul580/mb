package com.mbcerp.cloud

/** Public client configuration. Never put a service-role key here. */
object SupabaseConfig {
    const val PROJECT_URL = "https://dpebbthtlayvkonijiha.supabase.co"
    const val PUBLISHABLE_KEY = "sb_publishable_VxTtUDFB-Bwj8_kEdeTQpA_tjuN2ztQ"
}
