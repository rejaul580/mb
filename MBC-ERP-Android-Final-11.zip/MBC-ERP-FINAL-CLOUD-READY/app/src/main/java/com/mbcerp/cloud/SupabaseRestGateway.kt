package com.mbcerp.cloud

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.Instant

/**
 * Minimal REST gateway for Supabase PostgREST/RPC. It deliberately uses only the
 * publishable client key and a user access token; service-role credentials never ship
 * in the APK. The access token is supplied by the authenticated session.
 */
class SupabaseRestGateway(
    private val accessTokenProvider: () -> String?,
    private val client: OkHttpClient = OkHttpClient()
) : CloudSyncGateway {
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    override suspend fun push(record: CloudRecord, expectedVersion: Long?): Result<CloudRecord> =
        withContext(Dispatchers.IO) {
            runCatching {
                val token = accessTokenProvider() ?: error("AUTH_REQUIRED")
                val body = JSONObject().apply {
                    put("p_entity", record.entity)
                    put("p_record_key", record.recordKey)
                    put("p_payload", record.payload)
                    put("p_client_updated_at", record.updatedAt)
                    put("p_device_id", record.deviceId ?: JSONObject.NULL)
                    put("p_expected_version", expectedVersion ?: JSONObject.NULL)
                }.toString()
                val req = Request.Builder()
                    .url("${SupabaseConfig.PROJECT_URL}/rest/v1/rpc/upsert_erp_record")
                    .post(body.toRequestBody(jsonType))
                    .header("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                    .header("Authorization", "Bearer $token")
                    .header("Prefer", "return=representation")
                    .build()
                client.newCall(req).execute().use { r ->
                    val text = r.body?.string().orEmpty()
                    if (!r.isSuccessful) error("HTTP_${r.code}:$text")
                    val obj = if (text.trimStart().startsWith("[")) JSONArray(text).optJSONObject(0) else JSONObject(text)
                    CloudRecord(
                        entity = obj.getString("entity"),
                        recordKey = obj.getString("record_key"),
                        payload = obj.getJSONObject("payload"),
                        updatedAt = obj.getString("updated_at"),
                        version = obj.getLong("version"),
                        deviceId = obj.optString("device_id").takeIf { it.isNotBlank() && it != "null" }
                    )
                }
            }
        }

    override suspend fun pull(entity: String, sinceIso: String?): Result<List<CloudRecord>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val token = accessTokenProvider() ?: error("AUTH_REQUIRED")
                val encodedEntity = URLEncoder.encode(entity, Charsets.UTF_8.name())
                val url = buildString {
                    append("${SupabaseConfig.PROJECT_URL}/rest/v1/erp_records?entity=eq.$encodedEntity&order=updated_at.asc")
                    if (!sinceIso.isNullOrBlank()) append("&updated_at=gt.${URLEncoder.encode(sinceIso, Charsets.UTF_8.name())}")
                }
                val req = Request.Builder().url(url).get()
                    .header("apikey", SupabaseConfig.PUBLISHABLE_KEY)
                    .header("Authorization", "Bearer $token")
                    .build()
                client.newCall(req).execute().use { r ->
                    val text = r.body?.string().orEmpty()
                    if (!r.isSuccessful) error("HTTP_${r.code}:$text")
                    val arr = JSONArray(text)
                    buildList {
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            add(CloudRecord(o.getString("entity"), o.getString("record_key"), o.getJSONObject("payload"), o.getString("updated_at"), o.getLong("version"), o.optString("device_id").takeIf { it.isNotBlank() && it != "null" }))
                        }
                    }
                }
            }
        }
}
