package com.mbcerp.ui.auth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.auth.AuthManager
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class LoginViewModel(private val authManager: AuthManager) : ViewModel() {
    private val _isFirstRun = MutableStateFlow<Boolean?>(null)
    val isFirstRun: StateFlow<Boolean?> = _isFirstRun
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _success = MutableStateFlow(false)
    val success: StateFlow<Boolean> = _success

    fun checkFirstRun() = viewModelScope.launch { _isFirstRun.value = authManager.isFirstRun() }
    fun createOwner(username: String, pin: String, confirmPin: String) = viewModelScope.launch {
        _error.value = null
        if (pin.length < 4) { _error.value = "PIN কমপক্ষে ৪ সংখ্যার হতে হবে"; return@launch }
        if (pin != confirmPin) { _error.value = "PIN দুটো মিলছে না"; return@launch }
        authManager.createOwnerAccount(username, pin); _success.value = true
    }
    fun login(username: String, pin: String) = viewModelScope.launch {
        _error.value = null
        if (authManager.login(username, pin)) _success.value = true else _error.value = "ভুল Username বা PIN"
    }
}

class LoginViewModelFactory(private val authManager: AuthManager) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = LoginViewModel(authManager) as T
}

@Composable
fun LoginScreen(vm: LoginViewModel, onLoggedIn: () -> Unit) {
    val isFirstRun by vm.isFirstRun.collectAsState()
    val error by vm.error.collectAsState()
    val success by vm.success.collectAsState()
    LaunchedEffect(Unit) { vm.checkFirstRun() }
    LaunchedEffect(success) { if (success) onLoggedIn() }

    var username by remember { mutableStateOf("owner") }
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF020405), Color(0xFF0A0D0F), Color(0xFF160A03)))
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(BrickOrange.copy(alpha = .10f), radius = size.minDimension * .75f, center = Offset(size.width * .5f, size.height * .27f))
            drawCircle(BrickOrange.copy(alpha = .035f), radius = size.minDimension * .95f, center = Offset(size.width * .5f, size.height * .92f))
        }

        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(22.dp))
            Text("MBC BRICKS ERP", color = TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
            Text("PREMIUM", color = BrickOrange, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.4.sp)
            Spacer(Modifier.height(12.dp))
            BrickStackLogo(Modifier.size(148.dp, 92.dp))
            Spacer(Modifier.height(6.dp))
            Text("MBC", color = BrickOrange, fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("BRICKS", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.5.sp)
            Spacer(Modifier.height(14.dp))

            Card(
                Modifier.fillMaxWidth().widthIn(max = 390.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xE90A0E10)),
                border = androidx.compose.foundation.BorderStroke(1.dp, AppStroke),
                elevation = CardDefaults.cardElevation(12.dp)
            ) {
                Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Lock, null, tint = BrickOrange, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.height(7.dp))
                    Text("Welcome Back", color = TextPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (isFirstRun == true) "Create your Owner PIN" else "Please enter your PIN to continue",
                        color = TextSecondary, fontSize = 11.sp
                    )
                    Spacer(Modifier.height(14.dp))

                    if (isFirstRun == true) {
                        DarkField(username, { username = it }, "Username")
                        Spacer(Modifier.height(8.dp))
                        DarkField(pin, { pin = it.filter(Char::isDigit).take(8) }, "PIN (4+ digits)", true)
                        Spacer(Modifier.height(8.dp))
                        DarkField(confirmPin, { confirmPin = it.filter(Char::isDigit).take(8) }, "Confirm PIN", true)
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            repeat(4) { i ->
                                Box(
                                    Modifier.size(49.dp).clip(RoundedCornerShape(12.dp)).background(AppSurface3)
                                        .border(1.dp, if (i < pin.length) BrickOrange else AppStroke, RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center
                                ) { if (i < pin.length) Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(BrickOrange)) }
                            }
                            IconButton(
                                onClick = { },
                                modifier = Modifier.size(49.dp).clip(RoundedCornerShape(12.dp)).background(AppSurface3)
                            ) { Icon(Icons.Default.Fingerprint, null, tint = BrickOrange) }
                        }
                        Spacer(Modifier.height(14.dp))
                        NumberPad(
                            onDigit = { if (pin.length < 8) pin += it },
                            onDelete = { if (pin.isNotEmpty()) pin = pin.dropLast(1) },
                            onSubmit = { vm.login(username, pin) }
                        )
                    }

                    error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = ErrorRed, fontSize = 11.sp) }
                    Spacer(Modifier.height(13.dp))
                    Button(
                        onClick = { if (isFirstRun == true) vm.createOwner(username, pin, confirmPin) else vm.login(username, pin) },
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        shape = RoundedCornerShape(11.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BrickOrange)
                    ) { Text(if (isFirstRun == true) "CREATE OWNER" else "LOGIN", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, letterSpacing = 1.2.sp) }
                    Spacer(Modifier.height(7.dp))
                    Text(if (isFirstRun == true) "Secure local PIN access" else "Forgot PIN?", color = TextSecondary, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.weight(1f))
            Text("MBC BRICKS ERP  •  PREMIUM EDITION", color = TextSecondary, fontSize = 9.sp, letterSpacing = .8.sp)
            Spacer(Modifier.height(4.dp))
            Text("Version 1.0.0", color = TextSecondary.copy(alpha = .65f), fontSize = 8.sp)
        }
    }
}

@Composable
private fun BrickStackLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val brickW = size.width * .26f
        val brickH = size.height * .17f
        val gap = size.width * .018f
        val rows = listOf(3, 4, 5)
        rows.forEachIndexed { r, count ->
            val total = count * brickW + (count - 1) * gap
            val left = (size.width - total) / 2f
            val y = size.height * (.12f + r * .27f)
            repeat(count) { c ->
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(BrickOrangeBright, BrickOrangeDark)),
                    topLeft = Offset(left + c * (brickW + gap), y),
                    size = Size(brickW, brickH),
                    cornerRadius = CornerRadius(5f, 5f)
                )
            }
        }
    }
}

@Composable private fun DarkField(value: String, onValue: (String) -> Unit, label: String, password: Boolean = false) {
    OutlinedTextField(
        value, onValue, label = { Text(label, fontSize = 11.sp) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(11.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrickOrange, unfocusedBorderColor = AppStroke,
            focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary,
            focusedLabelColor = BrickOrange, unfocusedLabelColor = TextSecondary,
            focusedContainerColor = AppSurface2, unfocusedContainerColor = AppSurface2
        )
    )
}

@Composable
private fun NumberPad(onDigit: (String) -> Unit, onDelete: () -> Unit, onSubmit: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "✓")).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                row.forEach { key ->
                    val click = when (key) { "⌫" -> onDelete; "✓" -> onSubmit; else -> ({ onDigit(key) }) }
                    OutlinedButton(
                        onClick = click,
                        modifier = Modifier.weight(1f).height(42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = if (key == "✓") BrickOrange else TextPrimary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (key == "✓") BrickOrange.copy(.65f) else AppStroke)
                    ) { Text(key, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}
