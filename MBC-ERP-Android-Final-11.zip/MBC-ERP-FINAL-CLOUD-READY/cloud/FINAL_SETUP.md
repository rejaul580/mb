# MBC ERP FINAL CLOUD SETUP

## What is included
- Supabase PostgreSQL schema with RLS
- Owner/Manager/Viewer roles
- Generic ERP record store for sync-safe JSON payloads
- Version + timestamp conflict protection
- Audit log
- Google OAuth setup instructions
- Exact seed SQL for 3,802 sales + 1,547 expenses + setup/old-due data
- Android public project configuration placeholder
- Backup UI and Google Drive backup code removed
- Android allowBackup=false

## Required final actions in Supabase
1. Run `supabase/schema.sql` in SQL Editor.
2. Run `migration/seed_records.sql`.
3. Run `migration/seed_setup.sql`.
4. Enable Google provider and configure OAuth.
5. Change the first intended Owner user's `erp_users.role` from VIEWER to OWNER using the Supabase SQL editor.

## Important
The SQL is the safe deployment artifact. It is not executed automatically from this environment because doing so would require a privileged Supabase credential. Do not paste a service-role key into the Android app or GitHub repository.
