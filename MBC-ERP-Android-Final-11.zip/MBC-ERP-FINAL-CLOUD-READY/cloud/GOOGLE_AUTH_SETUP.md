# Google Account Login – MBC ERP

1. In Supabase: Authentication → Providers → Google → Enable.
2. Create a Google OAuth Web client in Google Cloud Console.
3. Use Supabase's displayed callback URL as the OAuth redirect URI.
4. Put the Google Client ID/Secret only in Supabase; never commit them to GitHub.
5. Add the MBC Android deep link later only if native Google OAuth return is desired; the safer first release is Supabase-hosted OAuth with app deep-link return.

The Android app must use the Supabase project URL and the public publishable/anon key only.
