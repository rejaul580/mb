# Google sign-in redirect

Supabase Auth must be configured with Google as a provider. Add the Android callback URL:

`mbcerp://login-callback`

Add the same URL to Supabase Auth URL configuration / redirect allow-list. The Google OAuth client is created in Google Cloud Console and its client ID/secret are entered into Supabase Auth Provider settings. Never put a Google client secret in the Android app.
