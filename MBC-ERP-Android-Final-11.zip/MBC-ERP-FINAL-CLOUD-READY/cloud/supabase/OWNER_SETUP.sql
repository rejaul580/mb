-- Run AFTER the owner signs in once with Google.
-- Replace the email with the owner's real Google account email.
update public.erp_users
set role='OWNER', is_active=true, updated_at=now()
where lower(email)=lower('OWNER_GOOGLE_EMAIL_HERE');
