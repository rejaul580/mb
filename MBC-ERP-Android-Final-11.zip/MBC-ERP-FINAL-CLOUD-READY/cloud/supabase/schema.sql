
-- MBC ERP FINAL CLOUD SCHEMA
-- Supabase PostgreSQL. Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.erp_users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  display_name text,
  role text not null default 'VIEWER' check (role in ('OWNER','MANAGER','VIEWER')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.erp_records (
  id uuid primary key default gen_random_uuid(),
  entity text not null,
  record_key text not null,
  payload jsonb not null,
  version bigint not null default 1,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id),
  device_id text,
  is_deleted boolean not null default false,
  unique(entity, record_key)
);
create index if not exists erp_records_entity_idx on public.erp_records(entity);
create index if not exists erp_records_updated_idx on public.erp_records(updated_at);

create table if not exists public.erp_audit_log (
  id uuid primary key default gen_random_uuid(),
  entity text not null,
  record_key text not null,
  action text not null check(action in ('INSERT','UPDATE','DELETE','SYNC')),
  before_payload jsonb,
  after_payload jsonb,
  changed_by uuid references auth.users(id),
  device_id text,
  created_at timestamptz not null default now()
);
create index if not exists erp_audit_created_idx on public.erp_audit_log(created_at desc);

create or replace function public.is_owner() returns boolean language sql stable as $$
  select exists(select 1 from public.erp_users where id=auth.uid() and role='OWNER' and is_active);
$$;
create or replace function public.is_manager_or_owner() returns boolean language sql stable as $$
  select exists(select 1 from public.erp_users where id=auth.uid() and role in ('OWNER','MANAGER') and is_active);
$$;

alter table public.erp_users enable row level security;
alter table public.erp_records enable row level security;
alter table public.erp_audit_log enable row level security;

drop policy if exists users_self_or_owner on public.erp_users;
create policy users_self_or_owner on public.erp_users for select using (id=auth.uid() or public.is_owner());
drop policy if exists owner_manage_users on public.erp_users;
create policy owner_manage_users on public.erp_users for all using (public.is_owner()) with check (public.is_owner());

drop policy if exists records_read on public.erp_records;
create policy records_read on public.erp_records for select using (public.is_manager_or_owner() or exists(select 1 from public.erp_users u where u.id=auth.uid() and u.role='VIEWER' and u.is_active));
drop policy if exists records_write on public.erp_records;
create policy records_write on public.erp_records for insert with check (public.is_manager_or_owner());
drop policy if exists records_update on public.erp_records;
create policy records_update on public.erp_records for update using (public.is_manager_or_owner()) with check (public.is_manager_or_owner());
drop policy if exists records_delete on public.erp_records;
create policy records_delete on public.erp_records for delete using (public.is_owner());

drop policy if exists audit_read on public.erp_audit_log;
create policy audit_read on public.erp_audit_log for select using (public.is_owner() or changed_by=auth.uid());

create or replace function public.upsert_erp_record(
  p_entity text, p_record_key text, p_payload jsonb, p_client_updated_at timestamptz,
  p_device_id text default null, p_expected_version bigint default null
) returns public.erp_records
language plpgsql security invoker as $$
declare r public.erp_records; newver bigint;
begin
  select * into r from public.erp_records where entity=p_entity and record_key=p_record_key for update;
  if r.id is not null and p_expected_version is not null and r.version <> p_expected_version then
    raise exception 'CONFLICT:%', r.version using errcode='40001';
  end if;
  if r.id is not null and r.updated_at > p_client_updated_at then
    raise exception 'STALE:%', r.version using errcode='40001';
  end if;
  newver := coalesce(r.version,0)+1;
  insert into public.erp_records(entity,record_key,payload,version,updated_at,updated_by,device_id,is_deleted)
  values(p_entity,p_record_key,p_payload,newver,greatest(coalesce(p_client_updated_at,now()),now()),auth.uid(),p_device_id,false)
  on conflict(entity,record_key) do update set payload=excluded.payload, version=excluded.version,
    updated_at=excluded.updated_at, updated_by=excluded.updated_by, device_id=excluded.device_id, is_deleted=false
  returning * into r;
  insert into public.erp_audit_log(entity,record_key,action,before_payload,after_payload,changed_by,device_id)
  values(p_entity,p_record_key,case when newver=1 then 'INSERT' else 'UPDATE' end,null,p_payload,auth.uid(),p_device_id);
  return r;
end; $$;

-- Auth trigger: profile row is created when a Google-authenticated user is created.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.erp_users(id,email,display_name,role) values(new.id,coalesce(new.email,''),coalesce(new.raw_user_meta_data->>'full_name',new.raw_user_meta_data->>'name',''),'VIEWER') on conflict(id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
