# DECISIONS.md — চূড়ান্ত সিদ্ধান্ত ও গুরুত্বপূর্ণ Audit findings

## ৮টা Open Question — চূড়ান্ত সিদ্ধান্ত (safest Excel-compatible behavior)

| # | প্রশ্ন | চূড়ান্ত সিদ্ধান্ত | কোথায় Implement হয়েছে |
|---|---|---|---|
| D1 | Sales Register কলাম T ("Side Party Mobile" header vs formula mismatch) | Reserved nullable field (`sidePartyMobile`) রাখা হয়েছে, migration-এ কিছু import করা হয়নি (উৎস অনির্ভরযোগ্য, header ও formula একে অপরের সাথে মেলে না)। ভবিষ্যতে ইউজার নিজে থেকে পূরণ করবেন। | `SaleEntity.sidePartyMobile` |
| D2 | Cash Summary-র হার্ডকোডেড "+10500" | Editable per-season "Manual Adjustment" রেকর্ডে সরানো হয়েছে (`seasonFixedAdjustment`), migration-এ ঐতিহাসিক মান (10500) দিয়ে seed করা, Cash Summary screen-এর "Edit Adjustments" ডায়ালগ থেকে বদলানো যায়। | `CashSummaryAdjustmentEntity`, `ui/cash/CashSummaryScreen.kt` |
| D3 | Row capacity (Excel-এর 10,000-row limit) | SQLite/Room-এ কোনো hard cap নেই — Sales/Expense unbounded। | সব DAO |
| D4 | Multi-user/cloud sync | **Single-device offline-first (local Room/SQLite)** — চূড়ান্ত। Google Drive backup/restore (item 6) যোগ হয়েছে data-loss protection-এর জন্য, কিন্তু এটা "multi-user real-time sync" নয় — একজন ইউজার backup নেয়, পরে সেই বা অন্য একটা ডিভাইসে restore করে। | `repository/`, `backup/DriveBackupManager.kt` |
| D5 | Money Receipt ↔ Extra Payment link | **যোগ করা হয়েছে** (আগে decoupled ছিল, এখন resolved) — Money Receipt সেভ করলে, "Received Against" = Customer/Partner Due Collection হলে, স্বয়ংক্রিয়ভাবে সংশ্লিষ্ট Extra Payment টেবিলে entry যোগ হয় (ইউজার চাইলে বন্ধ করতে পারে টগল দিয়ে)। | `ui/print/PrintScreens.kt` (MoneyReceiptScreen), `repository/PrintRepository.kt` |
| D6 | Production Register brick-type coverage | Excel-এর numeric parity বজায় রাখতে **শুধু "1 No"/"2 No" কভারেজ অবিকল রাখা হয়েছে** — ইচ্ছাকৃতভাবে expand করা হয়নি, যাতে migrated historical stock-সংখ্যা Excel-এর সাথে না মেলার ঝুঁকি না থাকে। | `StockCalculator.productionStockEstimate()` |
| D7 | Old-due log ও Extra Payment-এর edit permission | **Append-only + soft-delete** ছিল, এখন সম্পূর্ণ **Edit flow যোগ হয়েছে** (item 4) — soft-delete থেকে full edit-এ upgrade, কিন্তু delete এখনো soft (audit trail বজায় থাকে, hard-delete নেই)। | সব entity-তে `isDeleted`, নতুন Edit UI |
| D8 | Offline vs Online | **সম্পূর্ণ offline-first কোর ERP-এর জন্য** (অপরিবর্তিত) — কিন্তু Weather Alert (item 5) ও Google Drive Backup (item 6) নতুন optional ফিচার হিসেবে ইন্টারনেট ব্যবহার করে, শুধু তখনই যখন সেগুলো ব্যবহার করা হয় (কোর বিক্রয়/খরচ এন্ট্রি কখনো ইন্টারনেটের উপর নির্ভর করে না)। | `weather/`, `backup/` প্যাকেজ |

## D-quirk-1 — সম্পূর্ণ সমাধান (গভীর audit-এ নতুন, গুরুত্বপূর্ণ আবিষ্কার)

আগের ধাপে (Phase 3) এটাকে "৪ জন কাস্টমারের বিরল ব্যতিক্রম" হিসেবে ভুলভাবে ডকুমেন্ট করা হয়েছিল।
পূর্ণ ৩৯৩-কাস্টমার validation চালানোর পর দেখা গেছে **এটা আসলে নিয়ম, ব্যতিক্রম নয়**:

- **Partner Ledger**: একই, সামঞ্জস্যপূর্ণ formula — Detail screen ও All-Partner-List উভয়ই
  baseline-date-aware হিসাব ব্যবহার করে। কোনো সমস্যা নেই (১৩/১৩ partner verified)।
- **Customer Ledger**: মূল Excel ফাইলে **দুইটা সম্পূর্ণ ভিন্ন formula** আছে একই "Total Due" নামে:
  - **Detail screen** (একজন কাস্টমার select করলে, row 8): `Total Sales(all-time) −
    Received at Sale(all-time) − Extra Payment` — এটাই প্রকৃত, নির্ভুল বকেয়া।
  - **All-Customer-List** (row 670+, সবার তালিকা): `Opening Due − Extra Payment` —
    Sales Register-এর প্রকৃত বিক্রয়/পরিশোধ ডেটা **একদমই ধরে না**।
  - যেহেতু ৩৯৩ জনের মধ্যে ৩৭৫ জনের Setup-এ কোনো Opening Due লেখাই নেই (０), তাদের সবার
    জন্য All-Customer-List সবসময় ৳0 দেখাত — তাদের প্রকৃত বকেয়া যতই হোক না কেন। এটা মূল
    স্প্রেডশিটের সবচেয়ে বেশি ব্যবহৃত summary view-এর একটা **real, high-impact bug**।
  - লাইভ ফাইলে থাকা cached snapshot দিয়ে এটা স্বতন্ত্রভাবে নিশ্চিত করা হয়েছে: Customer
    Ledger!B3-তে সেভের সময় "faici driver" select করা ছিল, cached D8=৩২,৬০০ (সঠিক
    detail-formula উত্তর), কিন্তু একই কাস্টমারের All-list সারি তার পুরনো Opening Due-ই দেখাচ্ছিল।

**App-এর সিদ্ধান্ত (Excel logic পরিবর্তন না করে):** দুটো formula-ই অবিকল রাখা হয়েছে
(`DueCalculator.customerDue()` — `totalDueDetailScreen` ও `totalDueAllListScreen` আলাদা
ফিল্ড), Ledger screen-এ দুটোই স্পষ্ট লেবেল সহ দেখানো হয় ("প্রকৃত বকেয়া" বনাম "পুরনো
Excel-এ যা দেখাত"), এবং কোনটা আসল হিসাবের জন্য ব্যবহার করা উচিত তা স্পষ্টভাবে বলা আছে।
Dashboard ও Cash Summary-র company-wide total customer due একটা **তৃতীয়, independent,
সঠিক formula** ব্যবহার করে (`CustomerOpeningDueTotal + SUMIFS(post-baseline sales
activity)`, Cash Summary!B12) যেটা সব ৩৯৩ কাস্টমার জুড়ে সঠিকভাবে verified — তাই Dashboard-এর
"Total Customer Due" সংখ্যাটা এই বাগ দ্বারা প্রভাবিত না।

## নতুন আবিষ্কার: Case-Insensitive Name Matching (Excel পরিমার্জনা)

Excel-এর `SUMIFS`/`MATCH`/`COUNTIFS` টেক্সট তুলনা **case-insensitive** (উপরের "faici driver"
vs "FAICI DRIVER" উদাহরণ প্রমাণ করে)। কিন্তু Kotlin-এর `String ==` এবং SQLite-এর ডিফল্ট `=`
উভয়ই **case-sensitive**। এটা একটা real parity bug ছিল যা এই ধাপে ঠিক করা হয়েছে:
- Domain layer (`FormulaPatterns.filterSalesByParty`, `filterExpensesByCategory`) —
  এখন `.equals(x, ignoreCase = true)` ব্যবহার করে।
- SQL layer (Room `@Query`) — `partyName`, `partyType`, `category` মিলানোর সব জায়গায়
  `COLLATE NOCASE` যোগ করা হয়েছে (`Daos.kt`)।
- Unit test যোগ করা হয়েছে এই নির্দিষ্ট আচরণ লক করে রাখতে।
