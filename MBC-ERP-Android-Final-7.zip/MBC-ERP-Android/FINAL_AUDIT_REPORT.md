# চূড়ান্ত AUDIT REPORT — "সব শেষ করে দাও" নির্দেশের ফলাফল

## যা সত্যিকারভাবে টেস্ট করে verify করা হয়েছে (Java mirror harness দিয়ে, কারণ sandbox-এ kotlinc নেই)

| Check group | ফলাফল |
|---|---|
| Core ERP calculation engine (Sales/Expense totals, Partner Due, Cash Waterfall, Profit Distribution, Diesel/Coal Stock, Expense-by-category) | **462/462 PASS** |
| — এর মধ্যে সব ৩৯৩ জন কাস্টমারের Due individually | ৩৯৩/৩৯৩ (all-list formula) |
| — Customer/Partner Ledger detail-screen formula, লাইভ cached snapshot দিয়ে cross-check | ২/২ (FAICI DRIVER, Saeed) |
| Case-insensitive name matching fix | verified against real "faici driver"/"FAICI DRIVER" scenario |
| Weather rain-risk calculator (৯টা scenario) | **11/11 PASS** (Java mirror) |
| Kotlin/Gradle build brace-paren balance (৪৯ ফাইল) | সব balanced |
| Repository constructor ↔ MbcErpApp wiring cross-check | সব ঠিক আছে (কোনো mismatch নেই) |
| ViewModelFactory reference ↔ definition cross-check (AppNav.kt) | সব resolve হয় |
| Duplicate top-level class/object নাম চেক | কোনো duplicate নেই |

## যা লেখা হয়েছে কিন্তু চালানো/verify করা যায়নি (honest listing)

| আইটেম | কেন verify করা যায়নি |
|---|---|
| Android Gradle build (`./gradlew assembleDebug`) | Sandbox-এ network নেই (curl দিয়ে সরাসরি নিশ্চিত করা হয়েছে: `dl.google.com` ও Gradle distribution URL দুটোই `403 host_not_allowed`) — Gradle/AGP/Kotlin/Compose compiler ডাউনলোড করা অসম্ভব |
| Instrumented tests (`MigrationIntegrationTest`, `EditFlowInstrumentedTest`) | কোনো emulator/device নেই এই sandbox-এ |
| Weather API লাইভ fetch (Open-Meteo) | নেটওয়ার্ক নেই |
| WorkManager periodic scheduling | Android runtime নেই |
| Notification পাঠানো | Android runtime নেই |
| Google Drive sign-in/upload/download | নেটওয়ার্ক নেই + developer-side OAuth setup দরকার (Google Cloud Console-এ, যেটা এই sandbox থেকে করা অসম্ভব) |
| PDF ফাইল visually সঠিক কিনা | Android runtime/emulator নেই, শুধু code logic hand-review করা হয়েছে |
| Compose UI screen-গুলো visually render হয় কিনা | কোনো emulator নেই |

## এই ধাপে পাওয়া ও ঠিক করা real bug (গুরুত্বপূর্ণ)

1. **D-quirk-1 সম্পূর্ণ সমাধান**: মূল audit-এ ভুলভাবে "৪ জন কাস্টমারের বিরল ব্যতিক্রম" বলা
   হয়েছিল। পূর্ণ ৩৯৩-কাস্টমার validation-এ ধরা পড়েছে এটা আসলে **৩৭৫/৩৯৩ কাস্টমারের জন্য
   নিয়ম** — মূল Excel-এর "All-Customer-List" Total Due কলাম সেই সব কাস্টমারের জন্য সবসময়
   ৳0 দেখাত যাদের Setup-এ Opening Due লেখা ছিল না, তাদের প্রকৃত বকেয়া যতই হোক। এখন দুই
   formula-ই আলাদা label সহ দেখানো হয়, "প্রকৃত বকেয়া" স্পষ্টভাবে চিহ্নিত।
2. **Case-insensitive matching bug**: Excel-এর SUMIFS/MATCH case-insensitive, কিন্তু
   আগের Kotlin/SQL কোড case-sensitive ছিল — লাইভ ডেটায় ("faici driver" vs "FAICI DRIVER")
   এটা প্রমাণিত সমস্যা ছিল, এখন ঠিক করা হয়েছে (domain layer + `COLLATE NOCASE`)।

## এখনো Unresolved / বাকি কাজ

1. **কোনো প্রকৃত APK নেই** — এই sandbox-এ কম্পাইল করা অসম্ভব। প্রোজেক্ট Android Studio-তে
   খুলে Gradle sync + Run করলেই build হওয়া উচিত, কিন্তু সেটা এখনো কেউ চালিয়ে দেখেনি।
2. Google Drive backup-এর সব টেবিল এখনো export/import কভার করে না — মূল টেবিল (Sales,
   Expense, Partners, Customers, Company Profile, Expense Categories, Brick Types) কভার
   করা হয়েছে, বাকি ছোট mini-ledger টেবিল (Extra Payment, Diesel/Coal Issue, Production,
   Asset Register, Old Due Log, Cash Summary Adjustment, Weather Settings) এখনো বাদ আছে
   (কোডে স্পষ্টভাবে নোট করা আছে)।
3. Bengali localization infrastructure (strings.xml) তৈরি হয়েছে কিন্তু বেশিরভাগ screen-এর
   ভেতরের Text() এখনো hardcoded (already mostly Bengali, কিন্তু Android-এর string-resource
   সিস্টেমের মাধ্যমে না) — পুরোপুরি migrate করা হয়নি।
4. App icon placeholder vector drawable দিয়ে বানানো হয়েছে (professional designer-করা আইকন
   না) — production release-এর আগে replace করা উচিত।
5. PDF-এ ব্যবহৃত icon (`android.R.drawable.ic_dialog_alert`) placeholder — production-এ
   একটা কাস্টম notification icon দরকার (vector, transparent background)।

## এই ধাপে যোগ হওয়া মোট কোড
৪৯টা Kotlin ফাইল, ৬,৩১৪ লাইন (Phase 1-3-এর ৩৬ ফাইল/৪,৫১২ লাইন থেকে +১৩ ফাইল/+১,৮০২ লাইন)।
