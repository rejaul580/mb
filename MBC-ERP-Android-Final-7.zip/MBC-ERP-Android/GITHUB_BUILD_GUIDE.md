# GitHub-এ পুশ করে App Build করার সম্পূর্ণ গাইড

> **এই workflow দুটো এই sandbox-এ সরাসরি চালিয়ে দেখা যায়নি** (এখানে network blocked —
> `curl https://github.com` করলেও `403` আসে)। তবে আলাদা web-search tool দিয়ে
> `gradle/actions/setup-gradle` ও `android-actions/setup-android`-এর official,
> হালনাগাদ documentation পড়ে প্রতিটা step যাচাই করা হয়েছে, এবং সেই যাচাইয়ে ২টা real
> সমস্যা ধরা পড়ে ঠিক করা হয়েছে (নিচে বিস্তারিত)। GitHub-এর নিজের রানারে প্রথমবার
> push করার পরের run log-ই চূড়ান্ত প্রমাণ।

## ধাপ ১: ZIP থেকে GitHub repo তৈরি করা

```bash
unzip MBC-ERP-Android-Final.zip
cd MBC-ERP-Android

git init
git add .
git commit -m "Initial commit: MBC Brickfield ERP Android app"

# GitHub-এ একটা নতুন empty repo বানান (README ছাড়া), তারপর:
git remote add origin https://github.com/<your-username>/<repo-name>.git
git branch -M main
git push -u origin main
```

এই ZIP-এ ইতিমধ্যে `.gitignore` আছে (keystore, local.properties, build output বাদ যাবে
automatic)। `.github/workflows/` ফোল্ডারে **দুইটা workflow** আগে থেকেই বসানো আছে —
push করার সাথে সাথেই GitHub Actions কাজ শুরু করবে।

## ধাপ ২: Debug APK — automatic (কিছু করতে হবে না)

`main` branch-এ push করলেই **`android-ci.yml`** workflow নিজে থেকে চলবে:
1. JDK 17 + Android SDK + Gradle সেটআপ করবে
2. Gradle wrapper jar নতুন করে বানাবে (এই sandbox-এ যেটা বানানো সম্ভব হয়নি, network না
   থাকায় — GitHub Actions-এ network আছে, তাই ওখানে এটা কাজ করবে)
3. Unit test চালাবে (`domain/calc` ও `domain/entry` — যেগুলো এই sandbox-এ Java mirror
   দিয়ে ৪৭৩/৪৭৩ pass দেখিয়েছি, ওগুলোই এখন Kotlin/JUnit দিয়ে সরাসরি চলবে)
4. Debug APK বানাবে

**APK কোথায় পাবেন:** GitHub repo-তে **Actions** ট্যাব → সর্বশেষ workflow run → নিচে
**Artifacts** সেকশনে **`mbc-erp-debug-apk`** — ডাউনলোড করে সরাসরি ফোনে ইনস্টল করা যাবে
(Settings → Security → "Unknown sources" চালু করে APK ফাইল খুললেই ইনস্টল হবে)।

## ধাপ ৩: Signed Release APK (Play Store-এ দেওয়ার জন্য, ঐচ্ছিক)

Play Store বা officially distribute করতে চাইলে APK-টা signed হতে হবে। এই ধাপ ম্যানুয়াল
সেটআপ লাগবে (এক-বারই):

```bash
# আপনার নিজের কম্পিউটারে (JDK ইনস্টল থাকতে হবে):
keytool -genkey -v -keystore release.keystore -alias mbc_erp \
  -keyalg RSA -keysize 2048 -validity 10000

# Base64 এ এনকোড করুন:
base64 -w0 release.keystore > release.keystore.b64
```

তারপর GitHub repo-তে: **Settings → Secrets and variables → Actions → New repository
secret** — এই ৪টা secret যোগ করুন:

| Secret নাম | মান |
|---|---|
| `KEYSTORE_BASE64` | `release.keystore.b64` ফাইলের ভেতরের পুরো টেক্সট |
| `KEYSTORE_PASSWORD` | keytool-এ যে password দিয়েছেন |
| `KEY_ALIAS` | `mbc_erp` (বা যা দিয়েছেন) |
| `KEY_PASSWORD` | key password |

এরপর GitHub-এর **Actions** ট্যাবে গিয়ে **"Android Release Build (signed)"** workflow
select করে **"Run workflow"** বাটনে চাপুন — এটা manual-trigger, প্রতি push-এ চলে না
(যাতে ভুলবশত release build না হয়ে যায়)।

## ধাপ ৪: নিজের কম্পিউটারে সরাসরি build করতে চাইলে (GitHub ছাড়াই)

Android Studio ইনস্টল থাকলে সবচেয়ে সহজ: **File → Open** → `MBC-ERP-Android` ফোল্ডার
সিলেক্ট করুন, Gradle sync হতে দিন (প্রথমবার ইন্টারনেট লাগবে), তারপর **Run**।

Terminal থেকে (Android SDK + JDK 17 ইনস্টল থাকলে):
```bash
cd MBC-ERP-Android

# প্রথমবার wrapper jar বানাতে হবে (system-এ gradle ইনস্টল থাকলে):
gradle wrapper --gradle-version 8.7

chmod +x ./gradlew

./gradlew testDebugUnitTest      # unit test চালান (৪৭৩+ check)
./gradlew assembleDebug          # debug APK বানান
./gradlew assembleRelease        # release APK (keystore.properties দরকার)
```

Debug APK পাবেন: `app/build/outputs/apk/debug/app-debug.apk`

## ধাপ ৫: Google Drive Backup ফিচার চালু করতে (ঐচ্ছিক)

`backup/BackupModels.kt`-এর top comment-এ পুরো নির্দেশনা আছে — সংক্ষেপে: Google Cloud
Console-এ একটা প্রজেক্ট বানিয়ে Drive API চালু করতে হবে, একটা OAuth client ID বানাতে
হবে (আপনার app-এর signing certificate-এর SHA-1 লাগবে — সেটা উপরের keystore বানানোর পর
`keytool -list -v -keystore release.keystore` দিয়ে পাবেন), তারপর `google-services.json`
ফাইল প্রজেক্টে বসাতে হবে (এই ফাইলটা `.gitignore`-এ আছে, কখনো commit করবেন না)।

## সংক্ষেপে — শুধু এই কমান্ডগুলো লাগবে

```bash
# ১ম বার:
git init && git add . && git commit -m "Initial commit"
git remote add origin <your-repo-url>
git push -u origin main
# → GitHub Actions automatically build করবে, Actions ট্যাব থেকে APK নামান

# পরের প্রতিটা পরিবর্তনের পর:
git add .
git commit -m "your message"
git push
# → আবার automatic build হবে
```
