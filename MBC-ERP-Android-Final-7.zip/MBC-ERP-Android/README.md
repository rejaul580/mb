# MBC Brickfield ERP — Android App (Phase 1)

উৎস: `MBC_Brickfield_ERP_English_2025-26_03-08-2026-1.xlsx` (৫৮ sheet, ৩,৮০২ Sales row,
১,৫৪৭ Expense row)। সম্পূর্ণ audit-এর জন্য দেখুন `MBC_Brickfield_ERP_Audit_Report.md` (Phase 0)
এবং এই Phase 1 প্যাকেজের `DECISIONS.md`।

## এই প্যাকেজে কী আছে

```
MBC-ERP-Android/
├── DECISIONS.md              <- ৮টা Open Question-এর applied decision
├── VALIDATION_REPORT.md      <- Excel vs App engine validation ফলাফল (65/65 PASS)
├── README.md                 <- এই ফাইল
├── build.gradle.kts / settings.gradle.kts / gradle.properties   <- root Gradle config
├── app/
│   ├── build.gradle.kts      <- app module dependencies (Room, Compose, Coroutines, JSON)
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── assets/migration/ <- Excel থেকে extract করা সব ডেটা (sales, expense, setup, mini-ledgers)
│   │   └── java/com/mbcerp/
│   │       ├── MbcErpApp.kt          <- Application class, manual DI wiring
│   │       ├── MainActivity.kt       <- Entry point (migration progress -> Setup screen)
│   │       ├── data/
│   │       │   ├── entity/           <- সব Room @Entity (Setup + Transaction tables)
│   │       │   ├── dao/              <- সব Room @Dao
│   │       │   ├── db/AppDatabase.kt
│   │       │   └── migration/ExcelDataImporter.kt   <- 3,802+1,547 row import engine
│   │       ├── domain/calc/          <- ৬টা reusable formula pattern + due/cash/stock/profit engine
│   │       ├── domain/entry/         <- Entry Guide Engine (৭-rule guided entry, Phase 2)
│   │       ├── repository/           <- Repository layer (Setup/Sales/Expense/Ledger/CashSummary)
│   │       ├── auth/AuthManager.kt   <- Local PIN authentication
│   │       └── ui/
│   │           ├── setup/            <- Setup screen (Compose) — master data + baseline date config
│   │           ├── sales/            <- Sales Entry (guided) + Sales List/Search (Phase 2)
│   │           ├── expense/          <- Expense Entry + Expense List/Search (Phase 2)
│   │           └── nav/AppNav.kt     <- Bottom-nav graph wiring all screens (Phase 2)
│   └── src/test/java/com/mbcerp/domain/{calc,entry}/   <- JUnit tests (calculation + entry-guide engines)
├── scripts/extract_excel_data.py     <- পুনরুৎপাদনযোগ্য Excel->JSON extraction script
└── validation/
    ├── src/Validate.java             <- Standalone Java validation harness (কোনো dependency ছাড়া)
    ├── data/                         <- validation-এর জন্য raw + expected ground-truth JSON
    └── RESULT.txt                    <- সর্বশেষ রান: PASS=65 FAIL=0
```

## কীভাবে চালাবেন (Build Instructions)

এই sandbox-এ নেটওয়ার্ক না থাকায় Gradle build সরাসরি চালানো যায়নি (দেখুন
`VALIDATION_REPORT.md` — "যা validate করা যায়নি" সেকশন)। Android Studio (Hedgehog/Koala বা
নতুন) দিয়ে সাধারণভাবে খুলুন:

```bash
# Android Studio দিয়ে:
File > Open > MBC-ERP-Android/  (root ফোল্ডার সিলেক্ট করুন)
# প্রথমবার Gradle sync হতে দিন (ইন্টারনেট দরকার — dependency ডাউনলোডের জন্য)
# তারপর Run 'app' (একটা emulator বা physical device-এ)
```

প্রথম লঞ্চে অ্যাপ `ExcelDataImporter.runIfNeeded()` চালাবে যা `assets/migration/*.json` থেকে
পুরো ডেটাসেট import করবে (row-count integrity check সহ — কোনো row miss হলে exception ছুঁড়ে
migration আটকে দেবে, চুপচাপ ডেটা হারাবে না)।

## Calculation Engine যাচাই (কোনো Android লাগে না)

```bash
cd validation
java src/Validate.java
```

## JUnit Unit Tests (Gradle সহ)

```bash
./gradlew :app:testDebugUnitTest
```

## Phase 1-এ যা করা হয়েছে (User-এর ১১-দফা checklist অনুযায়ী)

1. ✅ Database schema — `data/entity/` (১৯টা entity: master + transaction + mini-ledger)
2. ✅ SQLite/offline-first architecture — Room + কোনো network dependency নেই (Decision D4/D8)
3. ✅ Setup screen — `ui/setup/SetupScreen.kt` (৭ ট্যাব: Company, Partners, Majhis, Brick
   Types, Equipment, Expense Categories, Customers)
4. ✅ Authentication architecture — `auth/AuthManager.kt` (local PIN, SHA-256+salt, role field)
5. ✅ Baseline Date configuration — Setup screen "Company" ট্যাবে editable, `CompanyProfileEntity.dueBaselineDate`
6. ✅ Manual Adjustment structure — `CashSummaryAdjustmentEntity` (৭টা editable ফিল্ড, hardcoded সংখ্যা নেই)
7. ✅ Sales Register migration (৩,৮০২ row, integrity-checked) — `ExcelDataImporter.importSales()`
8. ✅ Expense Register migration (১,৫৪৭ row, integrity-checked) — `ExcelDataImporter.importExpenses()`
9. ✅ ৬টা reusable calculation pattern — `domain/calc/FormulaPatterns.kt`
10. ✅ Customer/Partner Due calculation — `domain/calc/DueCalculator.kt` + `LedgerRepository`
11. ✅ Cash Summary architecture — `domain/calc/CashWaterfallCalculator.kt` + `CashSummaryRepository`

## Phase 2-এ যা যোগ হয়েছে (Sales/Expense entry + list/search + Entry-Guide ৭-rule engine)

- ✅ **Entry Guide Engine** (`domain/entry/EntryGuideEngine.kt`) — AUDIT §6.1-এ documented ৭টা
  বাস্তব পরিস্থিতির মধ্যে প্রথম ৫টা (Sales Register-ভিত্তিক) একটা guided `EntryMode` picker-এ
  রূপান্তরিত: Regular Sale, Partner Due Settlement, Advance to Partner, Advance Sale, Due
  Transfer Between Partners। প্রতিটা মোড সঠিক +/- চিহ্ন **নিজে থেকেই** বসায় — ক্লার্ককে আর হাতে
  মনে রাখতে হবে না। বাকি ২টা (discount/rounding, general expense) Expense Entry screen-এর
  category selection দিয়েই কভার হয় (Excel-এও একই আচরণ)।
- ✅ **Sales Entry Screen** (`ui/sales/SalesEntryScreen.kt`) — guided mode picker + rate
  auto-lookup (Pattern 1) + duplicate-voucher guard
- ✅ **Sales List/Search Screen** (`ui/sales/SalesListScreen.kt`) — voucher/party/truck দিয়ে
  live search, Customer/Partner filter, লাইভ Due calculation (Pattern-এ কখনো store হয় না)
- ✅ **Expense Entry Screen** (`ui/expense/ExpenseEntryScreen.kt`) — category dropdown (Setup
  থেকে), Excavator/Drum Truck category হলে conditional Equipment dropdown (Excel-এর dynamic
  dropdown pattern অবিকল)
- ✅ **Expense List/Search Screen** (`ui/expense/ExpenseListScreen.kt`)
- ✅ **Navigation** (`ui/nav/AppNav.kt`) — bottom-nav দিয়ে Sales/Expense/Setup-এর মধ্যে যাতায়াত,
  Dashboard-এর Quick Menu hyperlink-এর ধারণা অনুসরণ করে
- ✅ Tests: `EntryGuideEngineTest.kt` — ৭টা scenario-র মধ্যে ৫টা (sign-flip সহ) সব cover করা,
  একটা negative test (counterparty ছাড়া due-transfer আটকানো) সহ

## এখনো Unresolved (সংক্ষিপ্ত — বিস্তারিত DECISIONS.md ও নিচের চূড়ান্ত চ্যাট উত্তরে)

- Gradle build বাস্তবে চালিয়ে APK তৈরি করে দেখা (network দরকার, এই sandbox-এ সম্ভব হয়নি)
- ৮টা Open Question-এর জন্য user-এর **প্রকৃত** সিদ্ধান্ত (এই ধাপে reasonable default প্রয়োগ
  করা হয়েছে, DECISIONS.md-এ পুরো তালিকা)
- "Received at Sale" দ্বৈত-formula quirk-এর UI treatment confirm করা (DECISIONS.md D-quirk-1)
- Customer/Partner Ledger, Dashboard, Diesel/Coal Register, Majhi Ledger, Equipment Register,
  Cash Summary UI স্ক্রিন, Production Register, Asset Register, Delivery Challan/Money Receipt
  print flow — এখনো বাকি (Phase 3+ scope, roadmap আগের audit report §10-এ আছে)
- Entry Guide rule #6 (discount/rounding)-এর জন্য Setup-এ "Discount/Rounding" category আগে থেকে
  থাকা লাগবে — migration data-তে না থাকলে ইউজারকে Setup ট্যাব থেকে একবার যোগ করে নিতে হবে
- Sales/Expense Entry screen-এ এখনো **edit** flow নেই (শুধু Add + soft-delete; List screen-এ
  swipe-to-edit Phase 3-এ যোগ হবে)

## Phase 3-9 (এই প্যাকেজে সম্পূর্ণ যোগ হয়েছে — user-এর "সব শেষ করে দাও" নির্দেশ অনুযায়ী)

সবগুলো Repository-তে wiring + Compose UI স্ক্রিন যোগ করা হয়েছে, ৩৬টা Kotlin ফাইল (৪,৫১২ লাইন) মোট।

| Phase | স্ক্রিন/ফিচার | ফাইল |
|---|---|---|
| 3 | Customer/Partner Ledger (Due summary + all-partner list + D-quirk-1 উভয় formula পাশাপাশি) | `ui/ledger/LedgerScreen.kt` |
| 4 | Diesel/Coal/Majhi/Equipment Register (৪টা tab, এক screen) | `ui/registers/RegistersScreen.kt` |
| 5 | Expense Summary + Ledger Viewer (৪১টা HL_ sheet + Ledger Viewer-এর প্রতিস্থাপন, generic category picker) | `ui/registers/LedgerViewerScreen.kt` |
| 6 | Cash Summary (পূর্ণ waterfall display + editable Manual Adjustments dialog + 16-Anna profit distribution) | `ui/cash/CashSummaryScreen.kt` |
| 7 | Dashboard (১২টা KPI card) + Daily Report (dialog) | `ui/dashboard/DashboardScreen.kt` |
| 8 | Production Register (stock estimate + entry form) + Asset Register (manual entry list) | `ui/production/ProductionScreen.kt`, `ui/asset/AssetRegisterScreen.kt` |
| 9 | Audit/Validation screen (সব check pass/fail সহ) + Delivery Challan (read-only voucher lookup) + Money Receipt (standalone print form) | `ui/audit/AuditScreen.kt`, `ui/print/PrintScreens.kt` |
| — | Login/PIN screen (Phase 1-এর Auth architecture-এর UI, আগে missing ছিল) | `ui/auth/LoginScreen.kt` |
| — | পূর্ণ Navigation (Dashboard/Sales/Expense bottom-nav + "আরও" bottom-sheet-এ বাকি ৯টা স্ক্রিন) | `ui/nav/AppNav.kt` |

### নতুন Repository classes
`RegisterRepository`, `DashboardRepository`, `ProductionRepository`, `AssetRegisterRepository`,
`AuditRepository`, `PrintRepository` — সব `repository/Repositories.kt`-এ, বিদ্যমান DAO/calc
engine-এর উপর ভিত্তি করে তৈরি (কোনো নতুন calculation logic লাগেনি, শুধু UI wiring)।

### এখনো সততার সাথে Unresolved (সম্পূর্ণ প্রজেক্ট শেষে চূড়ান্ত তালিকা)

1. **Gradle build বাস্তবে চালানো হয়নি** — এই sandbox-এ কোনো নেটওয়ার্ক নেই, তাই Android
   Gradle Plugin/Compose Compiler/Gradle wrapper jar ডাউনলোড করা যায়নি। সব Kotlin ফাইল
   brace/paren-balance ও import-সঠিকতা manually verify করা হয়েছে, কিন্তু প্রকৃত
   `./gradlew assembleDebug` Android Studio-তে প্রথমবার চালিয়ে confirm করা প্রয়োজন।
2. **৮টা Open Question-এর user-এর প্রকৃত সিদ্ধান্ত** এখনো conversation-এ সরাসরি দেওয়া হয়নি —
   Phase 1-এ নেওয়া reasonable default (DECISIONS.md) পুরো প্রজেক্ট জুড়ে ব্যবহৃত হয়েছে।
3. **D-quirk-1** ("Received at Sale" দ্বৈত-formula) — Ledger screen-এ দুটোই আলাদা লেবেলে
   দেখানো হচ্ছে, কিন্তু কোনটা "প্রধান" হিসেবে highlight হবে সেটা এখনো confirm করা হয়নি।
4. **Edit flow** এখনো নেই কোনো entry screen-এ (শুধু Add + soft-delete; List screen থেকে
   click করে edit করার UI যোগ করা বাকি)।
5. **Money Receipt ↔ Extra Payment auto-link** (Decision D5 অনুযায়ী ইচ্ছাকৃতভাবে বাদ)।
6. **Instrumented/integration test** (আসল Room database-এর বিপরীতে পুরো migration + সব
   screen-এর end-to-end যাচাই) — শুধু domain-layer unit test আছে (calc + entry engine),
   Android Studio-তে Gradle চালানোর পরেই সেটা করা সম্ভব।
7. **অ্যাপ আইকন, splash screen, Bengali app-wide localization (strings.xml)** — এখনো
   placeholder/English-only আছে, production release-এর আগে দরকার।
8. **PDF/Print output** (Delivery Challan, Money Receipt) — এখনো শুধু on-screen preview,
   প্রকৃত PDF generate/share/print করার কোড যোগ হয়নি (`pdf` skill/Android PrintManager
   API দিয়ে সহজে যোগ করা যাবে, কিন্তু এই ধাপে করা হয়নি)।

এই ৮টা বিষয় ছাড়া, audit report-এর original roadmap (§10, Phase 0-10) অনুযায়ী architecture,
schema, calculation logic, এবং সব প্রধান screen-এর কোড **সম্পূর্ণ**।

## এই ধাপের নতুন ডকুমেন্ট (সব ১৫টা আইটেম অনুযায়ী "সব শেষ করে দাও" নির্দেশের ফলাফল)

- `FINAL_AUDIT_REPORT.md` — কী সত্যিকারভাবে টেস্ট হয়েছে (462+11=473 automated checks
  PASS) বনাম কী লেখা হয়েছে কিন্তু চালানো যায়নি, সম্পূর্ণ honest breakdown
- `SHEET_COVERAGE_MATRIX.md` — সব ৫৮টা Excel sheet → App screen mapping
- `DECISIONS.md` — ৮টা প্রশ্নের চূড়ান্ত সিদ্ধান্ত + D-quirk-1-এর সম্পূর্ণ, সংশোধিত সমাধান
  (আগের "৪ জন কাস্টমারের ব্যতিক্রম" বর্ণনা ভুল ছিল, exists এখন সংশোধিত)
- `VALIDATION_REPORT.md` (Phase 1-এর, এখনো প্রাসঙ্গিক) + validation/ ফোল্ডারে আপডেট করা
  Java harness (৪৬২/৪৬২)

## নতুন প্যাকেজ/ফোল্ডার (এই ধাপে)
- `weather/` — Rain-risk calculator (১১/১১ verified), API client, WorkManager worker,
  notification builder (সব code-complete, network/device-untested)
- `backup/` — Google Drive backup/restore (code-complete, developer-side OAuth setup
  দরকার, network-untested)
- `pdf/` — Delivery Challan ও Money Receipt-এর প্রকৃত PDF generator
- `ui/weather/`, `ui/backup/` — সংশ্লিষ্ট screen
- `app/src/androidTest/` — instrumented test (migration, edit flow, case-insensitivity
  regression) — device/emulator ছাড়া চালানো যায়নি

**সৎ চূড়ান্ত অবস্থা:** কোনো প্রকৃত APK build হয়নি (network/Android SDK নেই এই sandbox-এ,
`curl` দিয়ে সরাসরি নিশ্চিত করা)। সব কোড Android Studio-তে খুলে Gradle sync করে build করা
প্রয়োজন — এটাই পরবর্তী, মানুষের করা ধাপ। বিস্তারিত `FINAL_AUDIT_REPORT.md`-এ।

## UI Polish (এই ধাপে যোগ হয়েছে)

আগের ধাপ পর্যন্ত অ্যাপ Compose-এর ডিফল্ট বেগুনি Material palette দিয়ে চলছিল
(শুধু `MaterialTheme { }` — কোনো custom branding ছিল না)। এই ধাপে:

- **`ui/theme/`** — সম্পূর্ণ ব্র্যান্ডেড Material3 theme (`Color.kt`, `Type.kt`, `Shape.kt`,
  `Theme.kt`): ইটভাটা-ভিত্তিক পোড়া-মাটির (fired-brick) রঙের প্যালেট, light + dark দুটোই,
  status bar color সমন্বয় সহ। `MainActivity.kt`-এ `MbcErpTheme` wire করা হয়েছে — এখন **পুরো
  অ্যাপ automatically** এই branding পায় (প্রতিটা screen আলাদা করে বদলাতে হয়নি)।
- **Dashboard** — বড়, prominent "Cash In Hand" hero card + icon ও রঙ-কোডেড (Due বেশি হলে
  লাল, কম/শূন্য হলে সবুজ) KPI grid + loading spinner + polished Daily Report dialog।
- **Login screen** — gradient background, card-based layout, PIN ফিল্ড masked
  (`PasswordVisualTransformation`), lock icon।
- **Migration loading/error screen** — branded, card-based error display।
- **Empty states** — Sales/Expense List এখন খালি থাকলে "কোনো এন্ট্রি নেই" স্পষ্টভাবে দেখায়
  (আগে খালি screen দেখাতো যেটা ভাঙা মনে হতে পারত) — নতুন shared `ui/common/EmptyState.kt`।

**Business logic-এ কোনো পরিবর্তন হয়নি** — এই ধাপের পরও core validation harness
**৪৬২/৪৬২ PASS** (আগের মতোই), যাচাই করা হয়েছে।

**এখনো UI polish বাকি** (সময়ের কারণে এই ধাপে করা হয়নি): Setup ট্যাব-গুলোর ভেতরের card
styling, Ledger/Registers/Cash Summary screen-এর deeper visual polish, loading skeleton
animation, pull-to-refresh, list item swipe actions। কোর navigation flow ও সবচেয়ে বেশি
ব্যবহৃত screen (Dashboard, Login, Sales/Expense List) অগ্রাধিকার পেয়েছে।

## এই ধাপে সম্পূর্ণ করা বাকি কাজ (যা sandbox-এর মধ্যে সম্ভব ছিল)

আগের উত্তরে দেওয়া "বাকি কাজের তালিকা" থেকে যেগুলো network/Android SDK ছাড়াই সম্পূর্ণ করা
সম্ভব ছিল, সেগুলো এই ধাপে করা হয়েছে:

- ✅ **Master data edit সম্পূর্ণ** — Majhi, Brick Type, Equipment, Expense Category-র জন্যও
  এখন tap-to-edit যোগ হয়েছে (আগে শুধু Partner ও Customer-এ ছিল, Add-only বাকিগুলোতে)।
- ✅ **Google Drive backup সব টেবিল কভার করে** — আগে ৭টা টেবিল কভার করত (Sales, Expense,
  Partners, Customers, Company Profile, কিছু আংশিক), এখন **১৮টা টেবিলের সবগুলো**: majhis,
  equipment, brick_types, expense_categories, customer/partner extra payments,
  diesel_issues, coal_usages, equipment_working_hours, production_entries,
  asset_register, old_due_collections, cash_summary_adjustments,
  weather_alert_settings — সব export+import (restore) দুই দিকেই যোগ হয়েছে।
- ✅ **Release build infrastructure** — `keystore.properties.example` টেমপ্লেট,
  signing config (developer নিজের keystore বসালেই কাজ করবে), `.gitignore`,
  পূর্ণাঙ্গ `proguard-rules.pro` (Room, org.json, Google API client, WorkManager-এর
  জন্য keep rules)। **সততার সাথে**: `isMinifyEnabled` ইচ্ছাকৃতভাবে `false` রাখা হয়েছে —
  R8 shrinking আসলে চালিয়ে যাচাই করার কোনো উপায় এই sandbox-এ নেই, তাই untested অবস্থায়
  minification চালু করাটা ঝুঁকিপূর্ণ (silent runtime crash হতে পারে)। Rules ready আছে,
  চালু করার আগে একটা real device-এ টেস্ট করে নিতে হবে।
- ✅ **Notification icon** — placeholder system icon (`ic_dialog_alert`) সরিয়ে একটা
  আসল branded vector drawable (`ic_notification_rain.xml`, cloud+raindrop glyph)
  দেওয়া হয়েছে।

### এখনো বাকি (এই ধাপের পরও, honestly)
- Bengali string-resource migration সম্পূর্ণ হয়নি (আগের মতোই, বেশিরভাগ Text() hardcoded)
- Setup ট্যাব বাদে বাকি screen-গুলোর (Ledger, Registers, Cash Summary, Production,
  Asset Register, Audit, Print, Weather) deeper visual polish বাকি — theme সব জায়গায়
  automatically apply হয়েছে (রঙ/font/shape), কিন্তু layout-level পুনর্বিন্যাস হয়নি
- Diesel/Coal/Working-Hours backup যোগ হলেও, এই তিনটার জন্য কোনো "Issue/Usage entry" UI
  screen এখনো নেই (শুধু auto-computed purchase summary আছে Registers screen-এ) — তাই এই
  টেবিলগুলো এখনো ব্যবহারিকভাবে সবসময় খালি থাকবে যতক্ষণ না সেই entry UI যোগ হয়
- প্রকৃত APK build, device test, live network test — আগের মতোই sandbox limitation

## এই ধাপে আরও যোগ হয়েছে

- ✅ **Diesel Issue / Coal Usage / Equipment Working Hours entry UI** — আগে এই ৩টা টেবিলে
  ডেটা লেখার কোনো in-app উপায় ছিল না (শুধু Excel migration ও Drive restore-এর মাধ্যমে
  আসত), তাই এগুলো ব্যবহারিকভাবে সবসময় খালি থাকত। এখন Registers screen-এর Diesel/Coal ট্যাবে
  "Issue/Usage এন্ট্রি দিন" বাটন এবং Equipment ট্যাবে "Working Hours এন্ট্রি দিন" বাটন যোগ
  হয়েছে — Diesel/Coal Stock হিসাব (purchased − issued) এখন সত্যিকারভাবে কার্যকর।

সব পরিবর্তনের পরও: brace/paren balance ✅, duplicate class check ✅, core validation
**৪৬২/৪৬২ PASS**, weather calculator **১১/১১ PASS** — অপরিবর্তিত।

## এই ধাপে আরও যোগ হয়েছে (UI polish + string-resource migration সম্প্রসারণ)

- ✅ **Audit, Asset Register, Production, Ledger Viewer screen polish** — Card-based
  consistent styling, EmptyState, রঙ-কোডেড status card (আগে এই ৪টা screen একদম plain
  ListItem-ভিত্তিক ছিল, কোনো Card/theme color ব্যবহার হয়নি)।
- ✅ **Navigation label-গুলো এখন সত্যিকারের locale-aware** — আগে `AppNav.kt`-এর bottom-nav
  ও "আরও" মেনুর label hardcoded String ছিল (strings.xml-এ entry থাকলেও ব্যবহার হতো না)।
  এখন `@StringRes` + `stringResource()` দিয়ে wire করা হয়েছে — ইংরেজি locale-এ ডিভাইস
  চালালে `values-en/strings.xml` থেকে automatically ইংরেজি label দেখাবে।
- ✅ **Save/Cancel/Add বাটন label** — ৯টা screen জুড়ে ৪১টা repeated hardcoded
  `Text("Save")`/`Text("Cancel")`/`Text("Add")` string resource-এ migrate করা হয়েছে।

### সততার সাথে এখনো বাকি
- সম্পূর্ণ ১০০% string-resource migration হয়নি — এন্ট্রি ফর্মের field label (Date,
  Amount, Category ইত্যাদি) ও বেশিরভাগ descriptive/help টেক্সট এখনো hardcoded Bengali।
  সবচেয়ে বেশি-repeat হওয়া common action label-গুলো (Save/Cancel/Add) এবং সব navigation
  label অগ্রাধিকার পেয়েছে (এগুলোর translation-value সবচেয়ে বেশি)।
- Weather ও Print screen-এর layout-level polish এখনো বাকি (আগের মতোই)।
- প্রকৃত APK build/device test — sandbox limitation, অপরিবর্তিত, এটাই এখনো সমাধান-অযোগ্য।

সব পরিবর্তনের পরও: ৫৬টা ফাইল ৭,৫৪৩ লাইন, brace/paren balance ✅, duplicate class ✅,
core validation **৪৬২/৪৬২ PASS**, weather calculator **১১/১১ PASS**।

## GitHub-এ Build করার জন্য (নতুন)

সরাসরি দেখুন: **`GITHUB_BUILD_GUIDE.md`** — GitHub repo বানানো থেকে শুরু করে debug/
release APK পাওয়া পর্যন্ত সম্পূর্ণ ধাপে ধাপে গাইড।

`.github/workflows/` ফোল্ডারে দুইটা ready-made GitHub Actions workflow আছে:
- **`android-ci.yml`** — প্রতি push-এ automatic: unit test চালায় + debug APK বানায়
- **`android-release.yml`** — manual-trigger, signed release APK বানায় (keystore secret লাগবে)

**যাচাই করা হয়েছে (web search দিয়ে, sandbox-এর নিজের network দিয়ে না — সেটা এখনো blocked,
`curl` দিয়ে পুনরায় নিশ্চিত করা হয়েছে):** এই sandbox থেকে সরাসরি GitHub Actions চালানো
সম্ভব না, কিন্তু আলাদা web-search tool দিয়ে `gradle/actions/setup-gradle`,
`android-actions/setup-android`-এর official ও হালনাগাদ documentation পড়ে নিশ্চিত করা
হয়েছে যে workflow-এর প্রতিটা action ও parameter সঠিক। এই যাচাইয়ে ২টা real সমস্যা ধরা
পড়ে ঠিক করা হয়েছে:
1. `gradle-version: '8.7'` ও `validate-wrappers: false` parameter যোগ করা হয়েছে —
   এগুলো ছাড়া `setup-gradle` step নিজেই fail করতে পারত, কারণ এই প্রজেক্টে
   `gradle-wrapper.jar` ফাইলটা নেই (sandbox-এ network না থাকায় বানানো যায়নি), আর
   `setup-gradle`-এর default আচরণ হলো প্রতিটা wrapper jar validate করা।
2. `android-actions/setup-android`-এর default শুধু `tools platform-tools` ইনস্টল
   করে — `compileSdk 34`-এর জন্য দরকারি `platforms;android-34` ও
   `build-tools;34.0.0` এখন স্পষ্টভাবে `packages` parameter-এ যোগ করা হয়েছে।

এরপরও, **GitHub-এর নিজের রানারে প্রথমবার সত্যিকারভাবে চালিয়ে দেখাটাই চূড়ান্ত যাচাই** —
Actions ট্যাবে run log দেখে কোনো সমস্যা থাকলে আমাকে জানালে সেটা ঠিক করে দেব।
