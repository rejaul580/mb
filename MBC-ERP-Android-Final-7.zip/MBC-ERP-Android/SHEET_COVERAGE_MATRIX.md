# SHEET COVERAGE MATRIX — সব ৫৮টা Excel Sheet vs App Screen

এই টেবিল আসল audit report-এর §1-এ চিহ্নিত প্রতিটা sheet-কে App-এর কোন screen/repository
কভার করছে তা দেখায়, item 12 ("verify all 58 sheets and all major screens") অনুযায়ী।

| # | Excel Sheet | App Coverage | Status |
|---|---|---|---|
| 1 | Entry Guide | `domain/entry/EntryGuideEngine.kt`-এর ডকুমেন্টেশন হিসেবে encode করা (৭টা rule) | ✅ সম্পূর্ণ |
| 2 | Dashboard | `ui/dashboard/DashboardScreen.kt` (১২টা KPI card) | ✅ সম্পূর্ণ |
| 3 | Daily Report | `ui/dashboard/DashboardScreen.kt`-এর Daily Report dialog | ✅ সম্পূর্ণ |
| 4 | Cash Summary | `ui/cash/CashSummaryScreen.kt` (waterfall + adjustments + profit distribution) | ✅ সম্পূর্ণ |
| 5 | Setup | `ui/setup/SetupScreen.kt` (৭ ট্যাব, সব master data + edit flow) | ✅ সম্পূর্ণ |
| 6 | Sales Register | `ui/sales/SalesEntryScreen.kt` + `SalesListScreen.kt` (entry+list+edit+delete) | ✅ সম্পূর্ণ |
| 7 | Customer Ledger | `ui/ledger/LedgerScreen.kt` (দুই formula-ই আলাদাভাবে, D-quirk-1 resolved) | ✅ সম্পূর্ণ |
| 8 | Partner Ledger | `ui/ledger/LedgerScreen.kt` (একই screen, Partner ট্যাব) | ✅ সম্পূর্ণ |
| 9 | Expense Register | `ui/expense/ExpenseEntryScreen.kt` + `ExpenseListScreen.kt` (entry+list+edit+delete) | ✅ সম্পূর্ণ |
| 10 | Diesel Register | `ui/registers/RegistersScreen.kt` (Diesel ট্যাব) | ✅ সম্পূর্ণ |
| 11 | Coal Register | `ui/registers/RegistersScreen.kt` (Coal ট্যাব) | ✅ সম্পূর্ণ |
| 12 | Majhi Ledger | `ui/registers/RegistersScreen.kt` (Majhi ট্যাব) | ✅ সম্পূর্ণ |
| 13 | Equipment Register | `ui/registers/RegistersScreen.kt` (Equipment ট্যাব) | ✅ সম্পূর্ণ |
| 14 | Expense Summary | `ui/registers/LedgerViewerScreen.kt`-এর category-totals অংশ | ✅ সম্পূর্ণ |
| 15 | Ledger Viewer | `ui/registers/LedgerViewerScreen.kt`-এর category-picker অংশ | ✅ সম্পূর্ণ |
| 16 | Asset Register | `ui/asset/AssetRegisterScreen.kt` | ✅ সম্পূর্ণ (manual-entry only, Excel-এর মতোই) |
| 17 | Audit Sheet | `ui/audit/AuditScreen.kt` (সব check যান্ত্রিকভাবে re-run হয়) | ✅ সম্পূর্ণ |
| 18 | Delivery Challan | `ui/print/PrintScreens.kt` (read-only lookup + real PDF export) | ✅ সম্পূর্ণ |
| 19 | Money Receipt | `ui/print/PrintScreens.kt` (+ Extra Payment link, PDF export) | ✅ সম্পূর্ণ |
| 20 | Production Register | `ui/production/ProductionScreen.kt` | ✅ সম্পূর্ণ (Decision D6: শুধু 1No/2No কভারেজ, ইচ্ছাকৃত) |
| 21-61 | HL_* (৪১টা hidden category-ledger sheet) | `ui/registers/LedgerViewerScreen.kt`-এর একক generic category-filter (Pattern 3) | ✅ সম্পূর্ণ (৪১টা আলাদা screen লাগেনি, ডিজাইন অনুযায়ী) |

## নতুন App-only ফিচার (কোনো Excel sheet-এ ছিল না)
| ফিচার | Screen | Status |
|---|---|---|
| Login/PIN Auth | `ui/auth/LoginScreen.kt` | ✅ সম্পূর্ণ (কোড লেখা, device-এ untested) |
| Weather Alert | `ui/weather/WeatherScreen.kt` + `weather/` package | ⚠️ Core logic (rain-risk calc) ১১/১১ verified; live API/notification/background worker কোড লেখা কিন্তু network/device-untested |
| Google Drive Backup | `ui/backup/BackupScreen.kt` + `backup/` package | ⚠️ কোড লেখা, OAuth setup দরকার (developer-only ধাপ), network-untested |

## Coverage সারসংক্ষেপ
- **৫৮/৫৮ Excel sheet** app-এ কোনো না কোনো screen/repository দিয়ে কভার হয়েছে (কোড লেভেলে)।
- **কোর ERP calculation logic** (Sales/Expense/Ledger/Cash Summary/Stock) পূর্ণাঙ্গভাবে
  Excel-এর সাথে মিলিয়ে validate করা হয়েছে (৪৬২/৪৬২ automated check, `VALIDATION_REPORT.md`)।
- **UI screen-গুলো** কোড আকারে সম্পূর্ণ কিন্তু **কোনোটাই device/emulator-এ চালিয়ে visually
  verify করা হয়নি** (sandbox limitation, নিচে দেখুন)।
