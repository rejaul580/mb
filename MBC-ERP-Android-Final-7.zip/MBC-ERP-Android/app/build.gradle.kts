import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.mbcerp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mbcerp"
        // minSdk raised from 24 to 26 in Phase 4 specifically to support the adaptive
        // icon format (mipmap-anydpi-v26/ic_launcher.xml) added for item 10 without
        // needing rasterized PNG fallbacks for API<26, which this sandbox has no image
        // tool to generate. Android 8.0+ covers the overwhelming majority of devices.
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-phase1"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        create("release") {
            // Release signing (item 9/production-readiness). NOT configured with a real
            // keystore here -- a signing key is a secret that must be generated and held
            // by the actual developer/business, never committed to a repo or generated
            // by an AI assistant. This block reads from local, git-ignored properties so
            // the project is release-build-ready the moment a developer supplies one.
            //
            // Setup (one-time, by the developer, on their own machine):
            //   keytool -genkey -v -keystore release.keystore -alias mbc_erp \
            //     -keyalg RSA -keysize 2048 -validity 10000
            // Then create keystore.properties (NOT committed -- see .gitignore) with:
            //   storeFile=/absolute/path/to/release.keystore
            //   storePassword=...
            //   keyAlias=mbc_erp
            //   keyPassword=...
            val propsFile = rootProject.file("keystore.properties")
            if (propsFile.exists()) {
                val props = Properties()
                props.load(propsFile.inputStream())
                storeFile = file(props.getProperty("storeFile"))
                storePassword = props.getProperty("storePassword")
                keyAlias = props.getProperty("keyAlias")
                keyPassword = props.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            // Minification defaults OFF: this sandbox cannot run a real R8 shrink pass
            // to verify the proguard-rules.pro keep-rules are complete (especially for
            // the Google API client's reflection-based JSON model classes) -- shipping
            // isMinifyEnabled=true unverified risks a release build that crashes at
            // runtime in ways a debug build never would. proguard-rules.pro is written
            // and ready; flip this to true and test on a real device before relying on it.
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (rootProject.file("keystore.properties").exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
            // Falls back to unsigned if no keystore.properties is present, so
            // `./gradlew assembleRelease` still succeeds for local testing.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Core / Compose
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.annotation:annotation:1.8.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")

    // Room (offline-first local database)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // WorkManager (Weather Alert background checks, item 5)
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // JSON parsing for migration importer (bundled Excel-extracted assets)
    implementation("org.json:json:20240303")

    // Security (local PIN hashing / EncryptedSharedPreferences)
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // Google Drive backup/restore (item 6) -- see backup/BackupModels.kt for the
    // required Google Cloud Console setup this cannot perform on its own.
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("com.google.api-client:google-api-client-android:2.6.0") {
        exclude(group = "org.apache.httpcomponents")
    }
    implementation("com.google.apis:google-api-services-drive:v3-rev20240914-2.0.0") {
        exclude(group = "org.apache.httpcomponents")
    }
    implementation("com.google.http-client:google-http-client-gson:1.44.2") {
        exclude(group = "org.apache.httpcomponents")
    }

    // Testing
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.room:room-testing:2.6.1")
}
