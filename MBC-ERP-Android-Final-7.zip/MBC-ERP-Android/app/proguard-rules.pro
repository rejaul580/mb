# MBC Brickfield ERP -- ProGuard/R8 rules for release builds.
# NOT device/build tested (see FINAL_AUDIT_REPORT.md) -- written against each
# library's documented consumer-rules requirements; verify with an actual
# `./gradlew assembleRelease` before shipping.

# ---- Room ----
# Room's annotation processor (KSP) generates the DAO implementations at compile
# time and ships its own consumer ProGuard rules, but Room entities must keep
# their field names intact since column binding happens by reflection-free codegen
# referencing these exact class shapes.
-keep class com.mbcerp.data.entity.** { *; }
-keep class com.mbcerp.weather.WeatherCacheEntity { *; }
-keep class com.mbcerp.weather.WeatherAlertSettingsEntity { *; }

# ---- org.json (used by ExcelDataImporter, LocalExportImport, backup/weather JSON) ----
-keep class org.json.** { *; }
-dontwarn org.json.**

# ---- Google Drive / Google API client (item 6) ----
# The Google API client libraries use reflection for JSON (de)serialization of
# their generated model classes; keep them intact under R8.
-keep class com.google.api.services.drive.** { *; }
-keep class com.google.api.client.** { *; }
-dontwarn com.google.api.client.**
-dontwarn com.google.api.services.drive.**
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# ---- Google Sign-In / Play Services Auth ----
-keep class com.google.android.gms.auth.** { *; }
-dontwarn com.google.android.gms.auth.**

# ---- WorkManager (Weather Alert background worker) ----
# WorkManager instantiates Worker subclasses by reflection via their class name;
# an obfuscated/renamed class would break WeatherAlertWorker.schedule() silently.
-keep class com.mbcerp.weather.WeatherAlertWorker { *; }
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.CoroutineWorker

# ---- Kotlin coroutines / Flow debug metadata (keeps stack traces meaningful) ----
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# ---- General Android/Kotlin housekeeping ----
-keepattributes SourceFile,LineNumberTable
-keepattributes *Annotation*
-dontwarn kotlin.**
