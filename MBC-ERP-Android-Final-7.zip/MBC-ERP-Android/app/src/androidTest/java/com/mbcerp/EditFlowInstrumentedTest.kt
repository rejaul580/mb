package com.mbcerp

import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.mbcerp.data.db.AppDatabase
import com.mbcerp.data.entity.SaleEntity
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Device-level test for the edit/update flow (item 4) against a real Room/SQLite
 * instance (in-memory, but exercising the real generated DAO implementation --
 * something the pure-JVM domain tests cannot do, since Room's DAO implementations are
 * annotation-processor-generated and require the Android Room runtime).
 *
 * NOT EXECUTED in this sandbox -- see MigrationIntegrationTest's class doc for why.
 */
@RunWith(AndroidJUnit4::class)
class EditFlowInstrumentedTest {
    private lateinit var db: AppDatabase

    @Before
    fun setup() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
    }

    @After
    fun teardown() { db.close() }

    @Test
    fun updateSale_persistsChanges() = runBlocking {
        val id = db.saleDao().insert(
            SaleEntity(date = "2026-08-01", partyType = "Customer", partyName = "Test", brickCategory = "1 No", amount = 1000.0)
        )
        val original = db.saleDao().getAll().first { it.id == id }
        db.saleDao().update(original.copy(amount = 1500.0, remarks = "corrected"))

        val updated = db.saleDao().getAll().first { it.id == id }
        assertEquals(1500.0, updated.amount, 0.001)
        assertEquals("corrected", updated.remarks)
    }

    @Test
    fun softDelete_removesFromActiveListButRowStillExistsInTable() = runBlocking {
        val id = db.saleDao().insert(
            SaleEntity(date = "2026-08-01", partyType = "Customer", partyName = "Test", brickCategory = "1 No", amount = 1000.0)
        )
        db.saleDao().softDelete(id)
        val activeRows = db.saleDao().getAll() // observeAll/getAll both filter isDeleted = 0
        assertTrue(activeRows.none { it.id == id })
    }

    @Test
    fun caseInsensitivePartyNameMatch_worksAtTheSqlLayer() = runBlocking {
        db.saleDao().insert(
            SaleEntity(date = "2026-08-01", partyType = "Customer", partyName = "FAICI DRIVER", brickCategory = "1 No", amount = 1000.0)
        )
        // Regression test for the case-insensitivity bug fixed in this session --
        // confirms the Room @Query's COLLATE NOCASE actually works against real SQLite,
        // not just the in-memory Kotlin filtering logic already covered by JVM tests.
        val matched = db.saleDao().getForParty("customer", "faici driver")
        assertEquals(1, matched.size)
    }
}
