package com.mbcerp

import androidx.room.Room
import androidx.room.testing.MigrationTestHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.mbcerp.data.db.AppDatabase
import com.mbcerp.data.migration.ExcelDataImporter
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.io.IOException

/**
 * INSTRUMENTED / DEVICE-LEVEL TESTS (item 7).
 *
 * IMPORTANT HONESTY NOTE: this sandbox has no Android emulator or connected device, so
 * these tests have been written against the documented AndroidX Test / Room-testing
 * APIs but have NEVER BEEN RUN. They are included so that running
 * `./gradlew connectedAndroidTest` on a real device/emulator is a one-command
 * verification step for whoever builds this project, not something that needs to be
 * written from scratch. Do not treat their presence as evidence they pass.
 *
 * To actually run them: `./gradlew connectedAndroidTest` with a device/emulator attached.
 */
@RunWith(AndroidJUnit4::class)
class MigrationIntegrationTest {

    @Test
    @Throws(IOException::class)
    fun migration1To2_addsWeatherTablesWithoutDataLoss() {
        val helper = MigrationTestHelper(
            InstrumentationRegistry.getInstrumentation(),
            AppDatabase::class.java
        )
        val dbName = "migration-test"
        // Create the DB at version 1 schema, insert a row, then run the real migration
        // and confirm the row is still there (Sales Register data survival check).
        var db = helper.createDatabase(dbName, 1)
        db.execSQL(
            "INSERT INTO sales (date, partyType, partyName, brickCategory, quantity, rate, amount, " +
            "advancePayment, cashReceived, createdAt, updatedAt, isDeleted) VALUES " +
            "('2026-08-01','Customer','Test Customer','1 No',100,9.5,950,0,950,0,0,0)"
        )
        db.close()

        db = helper.runMigrationsAndValidate(dbName, 2, true, AppDatabase.MIGRATION_1_2)
        val cursor = db.query("SELECT COUNT(*) FROM sales WHERE partyName = 'Test Customer'")
        cursor.moveToFirst()
        assertEquals(1, cursor.getInt(0))
        cursor.close()

        val weatherCursor = db.query("SELECT COUNT(*) FROM weather_alert_settings")
        weatherCursor.moveToFirst()
        assertEquals(0, weatherCursor.getInt(0)) // table exists, empty until configured
        weatherCursor.close()
    }

    @Test
    fun fullMigration_importsExactRowCounts() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val importer = ExcelDataImporter(context, db)
        importer.runIfNeeded()

        assertEquals(ExcelDataImporter.EXPECTED_SALES_ROWS, db.saleDao().getAll().size)
        assertEquals(ExcelDataImporter.EXPECTED_EXPENSE_ROWS, db.expenseDao().getAll().size)
        db.close()
    }

    @Test
    fun reRunningMigration_isIdempotent() = runBlocking {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val importer = ExcelDataImporter(context, db)
        importer.runIfNeeded()
        val firstCount = db.saleDao().getAll().size
        importer.runIfNeeded() // should be a no-op (companyProfile already exists)
        val secondCount = db.saleDao().getAll().size
        assertEquals(firstCount, secondCount)
        db.close()
    }
}
