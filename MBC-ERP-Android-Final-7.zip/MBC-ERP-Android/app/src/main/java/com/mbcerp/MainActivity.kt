package com.mbcerp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mbcerp.ui.auth.LoginScreen
import com.mbcerp.ui.auth.LoginViewModel
import com.mbcerp.ui.auth.LoginViewModelFactory
import com.mbcerp.ui.nav.AppNavHost
import com.mbcerp.ui.theme.MbcErpTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        val app = application as MbcErpApp

        setContent {
            MbcErpTheme {
                var migrating by remember { mutableStateOf(true) }
                var migrationError by remember { mutableStateOf<String?>(null) }
                var loggedIn by remember { mutableStateOf(app.authManager.isLoggedIn()) }
                val scope = rememberCoroutineScope()

                LaunchedEffect(Unit) {
                    scope.launch {
                        try {
                            app.importer.runIfNeeded()
                        } catch (e: Exception) {
                            migrationError = e.message
                        } finally {
                            migrating = false
                        }
                    }
                }

                when {
                    migrating -> MigrationLoadingScreen()
                    migrationError != null -> MigrationErrorScreen(migrationError!!)
                    !loggedIn -> {
                        val vm: LoginViewModel = viewModel(factory = LoginViewModelFactory(app.authManager))
                        LoginScreen(vm, onLoggedIn = { loggedIn = true })
                    }
                    else -> AppNavHost(app)
                }
            }
        }
    }
}

@Composable
fun MigrationLoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary, strokeWidth = 3.dp)
            Spacer(Modifier.height(24.dp))
            Text(
                "MBC ইটভাটা ERP",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Excel ডেটা import হচ্ছে…",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                "৩,৮০২ বিক্রয় + ১,৫৪৭ খরচ এন্ট্রি",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun MigrationErrorScreen(message: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
            shape = MaterialTheme.shapes.large
        ) {
            Column(Modifier.padding(20.dp)) {
                Text(
                    "Migration ব্যর্থ হয়েছে",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Spacer(Modifier.height(10.dp))
                Text(message, color = MaterialTheme.colorScheme.onErrorContainer)
                Spacer(Modifier.height(10.dp))
                Text(
                    "কোনো আংশিক ডেটা লেখা হয়নি (import একটাই transaction-এ চলে)। " +
                    "Bundled asset ফাইল ঠিক করে reinstall করুন।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
    }
}
