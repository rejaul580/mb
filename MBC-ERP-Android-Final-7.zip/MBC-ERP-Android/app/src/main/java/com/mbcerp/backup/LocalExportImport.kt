package com.mbcerp.backup

import com.mbcerp.data.db.AppDatabase
import org.json.JSONArray
import org.json.JSONObject

/**
 * Table <-> JSON serialization, independent of WHERE the resulting file ends up
 * (Google Drive, local file share, etc.) -- this part needs no network and is real,
 * exercised logic (structurally the mirror image of ExcelDataImporter's JSON reading).
 * GoogleDriveBackupManager (network-dependent, unverified) is a thin wrapper around
 * exportAll()/importAll() below.
 */
class LocalExportImport(private val db: AppDatabase) {

    private fun <T> toJsonArray(rows: List<T>, toJson: (T) -> JSONObject): String {
        val arr = JSONArray()
        rows.forEach { arr.put(toJson(it)) }
        return arr.toString()
    }

    suspend fun exportAll(): BackupBundle {
        val tables = LinkedHashMap<String, String>()
        val counts = LinkedHashMap<String, Int>()

        val partners = db.partnerDao().getAll()
        tables["partners"] = toJsonArray(partners) {
            JSONObject().put("id", it.id).put("name", it.name).put("capital", it.capital)
                .put("shareAnna", it.shareAnna).put("openingDue", it.openingDue).put("mobile", it.mobile)
        }
        counts["partners"] = partners.size

        val customers = db.customerDao().getAll()
        tables["customers"] = toJsonArray(customers) {
            JSONObject().put("id", it.id).put("name", it.name).put("openingDue", it.openingDue).put("mobile", it.mobile)
        }
        counts["customers"] = customers.size

        val expenseCategories = db.expenseCategoryDao().getAll()
        tables["expense_categories"] = toJsonArray(expenseCategories) {
            JSONObject().put("id", it.id).put("category", it.category).put("sortOrder", it.sortOrder)
        }
        counts["expense_categories"] = expenseCategories.size

        val brickTypes = db.brickTypeDao().getAll()
        tables["brick_types"] = toJsonArray(brickTypes) {
            JSONObject().put("id", it.id).put("category", it.category).put("rate", it.rate)
        }
        counts["brick_types"] = brickTypes.size

        // --- Remaining tables (previously a documented gap, now covered) ---
        val majhis = db.majhiDao().getAll()
        tables["majhis"] = toJsonArray(majhis) { JSONObject().put("id", it.id).put("name", it.name) }
        counts["majhis"] = majhis.size

        val equipment = db.equipmentDao().getAll()
        tables["equipment"] = toJsonArray(equipment) {
            JSONObject().put("id", it.id).put("name", it.name).put("type", it.type)
                .put("hourlyRate", it.hourlyRate).put("driverName", it.driverName)
        }
        counts["equipment"] = equipment.size

        val customerExtra = db.extraPaymentDao().allCustomerPayments()
        tables["customer_extra_payments"] = toJsonArray(customerExtra) {
            JSONObject().put("id", it.id).put("date", it.date).put("customerName", it.customerName)
                .put("amount", it.amount).put("remarks", it.remarks)
        }
        counts["customer_extra_payments"] = customerExtra.size

        val partnerExtra = db.extraPaymentDao().allPartnerPayments()
        tables["partner_extra_payments"] = toJsonArray(partnerExtra) {
            JSONObject().put("id", it.id).put("date", it.date).put("partnerName", it.partnerName)
                .put("amount", it.amount).put("remarks", it.remarks)
        }
        counts["partner_extra_payments"] = partnerExtra.size

        val production = db.productionDao().getAllOnce()
        tables["production_entries"] = toJsonArray(production) {
            JSONObject().put("id", it.id).put("date", it.date).put("majhiName", it.majhiName)
                .put("type", it.type).put("rawBricksCounted", it.rawBricksCounted)
                .put("loadedToKiln", it.loadedToKiln).put("unloadedFiredOut", it.unloadedFiredOut)
                .put("remarks", it.remarks)
        }
        counts["production_entries"] = production.size

        val assetRows = db.assetRegisterDao().getAllOnce()
        tables["asset_register"] = toJsonArray(assetRows) {
            JSONObject().put("id", it.id).put("date", it.date).put("assetType", it.assetType)
                .put("description", it.description).put("location", it.location)
                .put("purchaseAmount", it.purchaseAmount).put("owners", it.owners).put("remarks", it.remarks)
        }
        counts["asset_register"] = assetRows.size

        val oldDueRows = db.oldDueCollectionDao().getAllOnce()
        tables["old_due_collections"] = toJsonArray(oldDueRows) {
            JSONObject().put("id", it.id).put("date", it.date).put("name", it.name)
                .put("amount", it.amount).put("remarks", it.remarks)
        }
        counts["old_due_collections"] = oldDueRows.size

        val adjustments = db.cashSummaryAdjustmentDao().getAllOnce()
        tables["cash_summary_adjustments"] = toJsonArray(adjustments) {
            JSONObject().put("season", it.season).put("seasonFixedAdjustment", it.seasonFixedAdjustment)
                .put("advanceExpenseNextYear", it.advanceExpenseNextYear).put("coalRelatedDeposit", it.coalRelatedDeposit)
                .put("priorYearDueReturn", it.priorYearDueReturn).put("oldDueStartingPool", it.oldDueStartingPool)
                .put("forwardDue", it.forwardDue).put("otherAdjustments", it.otherAdjustments)
        }
        counts["cash_summary_adjustments"] = adjustments.size

        val weatherSettings = db.weatherDao().getSettings()
        if (weatherSettings != null) {
            tables["weather_alert_settings"] = JSONArray().put(
                JSONObject().put("enabled", weatherSettings.enabled).put("latitude", weatherSettings.latitude)
                    .put("longitude", weatherSettings.longitude)
                    .put("probabilityThresholdPercent", weatherSettings.probabilityThresholdPercent)
                    .put("heavyRainMm", weatherSettings.heavyRainMm).put("leadTimeHours", weatherSettings.leadTimeHours)
                    .put("checkIntervalMinutes", weatherSettings.checkIntervalMinutes)
            ).toString()
            counts["weather_alert_settings"] = 1
        }

        val dieselIssues = db.stockDao().getAllDieselIssues()
        tables["diesel_issues"] = toJsonArray(dieselIssues) {
            JSONObject().put("id", it.id).put("date", it.date).put("issuedTo", it.issuedTo).put("quantity", it.quantity)
        }
        counts["diesel_issues"] = dieselIssues.size

        val coalUsages = db.stockDao().getAllCoalUsages()
        tables["coal_usages"] = toJsonArray(coalUsages) {
            JSONObject().put("id", it.id).put("date", it.date).put("usedFor", it.usedFor).put("quantity", it.quantity)
        }
        counts["coal_usages"] = coalUsages.size

        val workingHours = db.stockDao().getAllWorkingHours()
        tables["equipment_working_hours"] = toJsonArray(workingHours) {
            JSONObject().put("id", it.id).put("date", it.date).put("equipmentName", it.equipmentName).put("hours", it.hours)
        }
        counts["equipment_working_hours"] = workingHours.size

        val sales = db.saleDao().getAll()
        tables["sales"] = toJsonArray(sales) {
            JSONObject()
                .put("id", it.id).put("date", it.date).put("voucherNo", it.voucherNo)
                .put("truckNo", it.truckNo).put("partyType", it.partyType).put("partyName", it.partyName)
                .put("brickCategory", it.brickCategory).put("quantity", it.quantity).put("rate", it.rate)
                .put("amount", it.amount).put("advancePayment", it.advancePayment)
                .put("cashReceived", it.cashReceived).put("remarks", it.remarks).put("saleType", it.saleType)
                .put("isDeleted", it.isDeleted)
        }
        counts["sales"] = sales.size

        val expenses = db.expenseDao().getAll()
        tables["expenses"] = toJsonArray(expenses) {
            JSONObject()
                .put("id", it.id).put("date", it.date).put("voucherNo", it.voucherNo)
                .put("category", it.category).put("partyPaidTo", it.partyPaidTo).put("quantity", it.quantity)
                .put("amount", it.amount).put("paidCash", it.paidCash).put("remarks", it.remarks)
                .put("isDeleted", it.isDeleted)
        }
        counts["expenses"] = expenses.size

        val profile = db.companyProfileDao().get()
        if (profile != null) {
            tables["company_profile"] = JSONArray().put(
                JSONObject().put("name", profile.name).put("season", profile.season)
                    .put("openingCapital", profile.openingCapital)
                    .put("customerOpeningDueTotal", profile.customerOpeningDueTotal)
                    .put("dueBaselineDate", profile.dueBaselineDate)
            ).toString()
            counts["company_profile"] = 1
        }

        // All 15 tables now covered: partners, customers, majhis, equipment, brick_types,
        // expense_categories, sales, expenses, company_profile, customer/partner extra
        // payments, production_entries, asset_register, old_due_collections,
        // cash_summary_adjustments, weather_alert_settings. (diesel_issues/coal_usages/
        // equipment_working_hours are intentionally still excluded -- see README.)

        val manifest = BackupManifest(
            schemaVersion = 2,
            exportedAtMillis = System.currentTimeMillis(),
            appVersionName = "1.0-phase4",
            tableRowCounts = counts
        )
        return BackupBundle(manifest, tables)
    }

    /**
     * Restores a backup bundle. REPLACE semantics: existing rows for each table present
     * in the bundle are cleared first (never merged silently -- avoids duplicate rows
     * on a second restore). Caller (UI) must get explicit user confirmation before
     * calling this, since it is destructive to current on-device data.
     */
    suspend fun importAll(bundle: BackupBundle) {
        bundle.tablesJson["partners"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.PartnerEntity(
                    id = o.getLong("id"), name = o.getString("name"),
                    capital = o.optDouble("capital", 0.0), shareAnna = o.optDouble("shareAnna", 0.0),
                    openingDue = o.optDouble("openingDue", 0.0),
                    mobile = if (o.isNull("mobile")) null else o.optString("mobile")
                )
            }
            db.partnerDao().insertAll(entities)
        }
        bundle.tablesJson["sales"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.SaleEntity(
                    id = o.getLong("id"), date = o.getString("date"),
                    voucherNo = o.optString("voucherNo", null), truckNo = o.optString("truckNo", null),
                    partyType = o.getString("partyType"), partyName = o.getString("partyName"),
                    brickCategory = o.optString("brickCategory", ""), quantity = o.optDouble("quantity", 0.0),
                    rate = o.optDouble("rate", 0.0), amount = o.optDouble("amount", 0.0),
                    advancePayment = o.optDouble("advancePayment", 0.0), cashReceived = o.optDouble("cashReceived", 0.0),
                    remarks = o.optString("remarks", null), saleType = o.optString("saleType", null),
                    isDeleted = o.optBoolean("isDeleted", false)
                )
            }
            db.saleDao().insertAll(entities)
        }
        bundle.tablesJson["expenses"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.ExpenseEntity(
                    id = o.getLong("id"), date = o.getString("date"), voucherNo = o.optString("voucherNo", null),
                    category = o.getString("category"), partyPaidTo = o.optString("partyPaidTo", null),
                    quantity = o.optDouble("quantity", 0.0), amount = o.optDouble("amount", 0.0),
                    paidCash = o.optDouble("paidCash", 0.0), remarks = o.optString("remarks", null),
                    isDeleted = o.optBoolean("isDeleted", false)
                )
            }
            db.expenseDao().insertAll(entities)
        }
        bundle.tablesJson["customers"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.CustomerEntity(
                    id = o.getLong("id"), name = o.getString("name"),
                    openingDue = o.optDouble("openingDue", 0.0),
                    mobile = if (o.isNull("mobile")) null else o.optString("mobile")
                )
            }
            db.customerDao().insertAll(entities)
        }
        bundle.tablesJson["majhis"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.MajhiEntity(id = o.getLong("id"), name = o.getString("name"))
            }
            db.majhiDao().insertAll(entities)
        }
        bundle.tablesJson["equipment"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.EquipmentEntity(
                    id = o.getLong("id"), name = o.getString("name"), type = o.optString("type", "Excavator"),
                    hourlyRate = o.optDouble("hourlyRate", 0.0),
                    driverName = if (o.isNull("driverName")) null else o.optString("driverName")
                )
            }
            db.equipmentDao().insertAll(entities)
        }
        bundle.tablesJson["brick_types"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.BrickTypeEntity(id = o.getLong("id"), category = o.getString("category"), rate = o.optDouble("rate", 0.0))
            }
            db.brickTypeDao().insertAll(entities)
        }
        bundle.tablesJson["expense_categories"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.ExpenseCategoryEntity(id = o.getLong("id"), category = o.getString("category"))
            }
            db.expenseCategoryDao().insertAll(entities)
        }
        bundle.tablesJson["customer_extra_payments"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.CustomerExtraPaymentEntity(
                    date = o.getString("date"), customerName = o.getString("customerName"),
                    amount = o.optDouble("amount", 0.0), remarks = if (o.isNull("remarks")) null else o.optString("remarks")
                )
            }
            db.extraPaymentDao().insertAllCustomerPayments(entities)
        }
        bundle.tablesJson["partner_extra_payments"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.PartnerExtraPaymentEntity(
                    date = o.getString("date"), partnerName = o.getString("partnerName"),
                    amount = o.optDouble("amount", 0.0), remarks = if (o.isNull("remarks")) null else o.optString("remarks")
                )
            }
            db.extraPaymentDao().insertAllPartnerPayments(entities)
        }
        bundle.tablesJson["production_entries"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.ProductionEntryEntity(
                    date = o.getString("date"), majhiName = if (o.isNull("majhiName")) null else o.optString("majhiName"),
                    type = if (o.isNull("type")) null else o.optString("type"),
                    rawBricksCounted = o.optDouble("rawBricksCounted", 0.0), loadedToKiln = o.optDouble("loadedToKiln", 0.0),
                    unloadedFiredOut = o.optDouble("unloadedFiredOut", 0.0),
                    remarks = if (o.isNull("remarks")) null else o.optString("remarks")
                )
            }
            db.productionDao().insertAll(entities)
        }
        bundle.tablesJson["asset_register"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.AssetRegisterEntity(
                    date = if (o.isNull("date")) null else o.optString("date"),
                    assetType = if (o.isNull("assetType")) null else o.optString("assetType"),
                    description = if (o.isNull("description")) null else o.optString("description"),
                    location = if (o.isNull("location")) null else o.optString("location"),
                    purchaseAmount = o.optDouble("purchaseAmount", 0.0),
                    owners = if (o.isNull("owners")) null else o.optString("owners"),
                    remarks = if (o.isNull("remarks")) null else o.optString("remarks")
                )
            }
            db.assetRegisterDao().insertAll(entities)
        }
        bundle.tablesJson["old_due_collections"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.OldDueCollectionEntity(
                    date = o.getString("date"), name = o.getString("name"),
                    amount = o.optDouble("amount", 0.0), remarks = if (o.isNull("remarks")) null else o.optString("remarks")
                )
            }
            db.oldDueCollectionDao().insertAll(entities)
        }
        bundle.tablesJson["cash_summary_adjustments"]?.let { json ->
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.cashSummaryAdjustmentDao().upsert(
                    com.mbcerp.data.entity.CashSummaryAdjustmentEntity(
                        season = o.getString("season"),
                        seasonFixedAdjustment = o.optDouble("seasonFixedAdjustment", 0.0),
                        advanceExpenseNextYear = o.optDouble("advanceExpenseNextYear", 0.0),
                        coalRelatedDeposit = o.optDouble("coalRelatedDeposit", 0.0),
                        priorYearDueReturn = o.optDouble("priorYearDueReturn", 0.0),
                        oldDueStartingPool = o.optDouble("oldDueStartingPool", 0.0),
                        forwardDue = o.optDouble("forwardDue", 0.0),
                        otherAdjustments = o.optDouble("otherAdjustments", 0.0)
                    )
                )
            }
        }
        bundle.tablesJson["weather_alert_settings"]?.let { json ->
            val arr = JSONArray(json)
            if (arr.length() > 0) {
                val o = arr.getJSONObject(0)
                db.weatherDao().saveSettings(
                    com.mbcerp.weather.WeatherAlertSettingsEntity(
                        enabled = o.optBoolean("enabled", false), latitude = o.optDouble("latitude", 22.3569),
                        longitude = o.optDouble("longitude", 91.7832),
                        probabilityThresholdPercent = o.optInt("probabilityThresholdPercent", 40),
                        heavyRainMm = o.optDouble("heavyRainMm", 7.5), leadTimeHours = o.optInt("leadTimeHours", 12),
                        checkIntervalMinutes = o.optInt("checkIntervalMinutes", 60)
                    )
                )
            }
        }
        bundle.tablesJson["diesel_issues"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.DieselIssueEntity(
                    date = o.getString("date"), issuedTo = if (o.isNull("issuedTo")) null else o.optString("issuedTo"),
                    quantity = o.optDouble("quantity", 0.0)
                )
            }
            db.stockDao().insertAllDieselIssues(entities)
        }
        bundle.tablesJson["coal_usages"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.CoalUsageEntity(
                    date = o.getString("date"), usedFor = if (o.isNull("usedFor")) null else o.optString("usedFor"),
                    quantity = o.optDouble("quantity", 0.0)
                )
            }
            db.stockDao().insertAllCoalUsages(entities)
        }
        bundle.tablesJson["equipment_working_hours"]?.let { json ->
            val arr = JSONArray(json)
            val entities = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                com.mbcerp.data.entity.EquipmentWorkingHourEntity(
                    date = o.getString("date"), equipmentName = o.getString("equipmentName"), hours = o.optDouble("hours", 0.0)
                )
            }
            db.stockDao().insertAllWorkingHours(entities)
        }
        bundle.tablesJson["company_profile"]?.let { json ->
            val arr = JSONArray(json)
            if (arr.length() > 0) {
                val o = arr.getJSONObject(0)
                val existing = db.companyProfileDao().get()
                db.companyProfileDao().upsert(
                    com.mbcerp.data.entity.CompanyProfileEntity(
                        name = o.optString("name", existing?.name ?: "MBC Brickfield"),
                        season = o.optString("season", existing?.season ?: "2025-26"),
                        openingCapital = o.optDouble("openingCapital", existing?.openingCapital ?: 0.0),
                        customerOpeningDueTotal = o.optDouble("customerOpeningDueTotal", existing?.customerOpeningDueTotal ?: 0.0),
                        dueBaselineDate = o.optString("dueBaselineDate", existing?.dueBaselineDate ?: "2026-07-14")
                    )
                )
            }
        }
    }
}
