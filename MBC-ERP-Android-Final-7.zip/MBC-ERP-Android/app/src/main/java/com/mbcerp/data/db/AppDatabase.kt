package com.mbcerp.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.mbcerp.data.dao.*
import com.mbcerp.data.entity.*
import com.mbcerp.weather.WeatherAlertSettingsEntity
import com.mbcerp.weather.WeatherCacheEntity
import com.mbcerp.weather.WeatherDao

/**
 * Offline-first local database (Decision D4 / D8): the app runs 100% locally on-device.
 * No network / server dependency for core operation. Repository interfaces are written
 * so a remote-sync data source could be added later (Phase 2+) without touching UI code.
 */
@Database(
    entities = [
        CompanyProfileEntity::class,
        PartnerEntity::class,
        MajhiEntity::class,
        BrickTypeEntity::class,
        EquipmentEntity::class,
        ExpenseCategoryEntity::class,
        CustomerEntity::class,
        SaleEntity::class,
        ExpenseEntity::class,
        CustomerExtraPaymentEntity::class,
        PartnerExtraPaymentEntity::class,
        DieselIssueEntity::class,
        CoalUsageEntity::class,
        EquipmentWorkingHourEntity::class,
        ProductionEntryEntity::class,
        AssetRegisterEntity::class,
        OldDueCollectionEntity::class,
        CashSummaryAdjustmentEntity::class,
        AppUserEntity::class,
        WeatherCacheEntity::class,
        WeatherAlertSettingsEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun companyProfileDao(): CompanyProfileDao
    abstract fun partnerDao(): PartnerDao
    abstract fun majhiDao(): MajhiDao
    abstract fun brickTypeDao(): BrickTypeDao
    abstract fun equipmentDao(): EquipmentDao
    abstract fun expenseCategoryDao(): ExpenseCategoryDao
    abstract fun customerDao(): CustomerDao
    abstract fun saleDao(): SaleDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun extraPaymentDao(): ExtraPaymentDao
    abstract fun stockDao(): StockDao
    abstract fun productionDao(): ProductionDao
    abstract fun assetRegisterDao(): AssetRegisterDao
    abstract fun oldDueCollectionDao(): OldDueCollectionDao
    abstract fun cashSummaryAdjustmentDao(): CashSummaryAdjustmentDao
    abstract fun appUserDao(): AppUserDao
    abstract fun weatherDao(): com.mbcerp.weather.WeatherDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        /**
         * v1 -> v2: adds the two Weather Alert tables (item 5). Written as a real
         * Migration (not fallbackToDestructiveMigration) so that if this app is ever
         * actually shipped at v1 and later updated, existing users' Sales/Expense data
         * is preserved rather than wiped. NOT device-tested (no emulator in this
         * sandbox) -- the SQL below was hand-verified against Room's expected column
         * types for each @Entity field (see WeatherEntities.kt), but a real
         * MigrationTestHelper run (androidx.room:room-testing) is still recommended
         * before shipping -- see EditFlowInstrumentedTest.kt / README for how to run it.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `weather_cache` (
                        `id` INTEGER NOT NULL PRIMARY KEY,
                        `fetchedAtMillis` INTEGER NOT NULL,
                        `latitude` REAL NOT NULL,
                        `longitude` REAL NOT NULL,
                        `forecastJson` TEXT NOT NULL
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `weather_alert_settings` (
                        `id` INTEGER NOT NULL PRIMARY KEY,
                        `enabled` INTEGER NOT NULL,
                        `latitude` REAL NOT NULL,
                        `longitude` REAL NOT NULL,
                        `probabilityThresholdPercent` INTEGER NOT NULL,
                        `heavyRainMm` REAL NOT NULL,
                        `leadTimeHours` INTEGER NOT NULL,
                        `checkIntervalMinutes` INTEGER NOT NULL,
                        `minMinutesBetweenAlerts` INTEGER NOT NULL,
                        `lastAlertAtMillis` INTEGER NOT NULL,
                        `lastAlertedHourBucket` INTEGER NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mbc_erp.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
