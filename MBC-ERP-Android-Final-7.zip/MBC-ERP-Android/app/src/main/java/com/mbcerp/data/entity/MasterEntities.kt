package com.mbcerp.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * All entities below mirror the "Setup" sheet blocks (see AUDIT REPORT §2.1).
 * Decision D4: single local database, no server-side foreign keys required —
 * SQLite autoincrement ids are local-only and stable across the life of the app.
 */

@Entity(tableName = "company_profile")
data class CompanyProfileEntity(
    @PrimaryKey val id: Int = 1, // singleton row
    val name: String,
    val season: String,
    val address: String? = null,
    val phones: String? = null,
    val tagline: String? = null,
    val openingCapital: Double,          // Setup!B7 = SUM(partners.capital) - recomputed, not stored authoritative
    val customerOpeningDueTotal: Double, // Setup!B3
    /** Decision D2: "Due Baseline Date" (Setup!B8) — all due-formulas only count sales AFTER this date. */
    val dueBaselineDate: String,         // ISO yyyy-MM-dd
    val defaultDamagePercent: Double = 0.05,
    val seasonEndOverridePercent: Double? = null
)

@Entity(tableName = "partners")
data class PartnerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val capital: Double = 0.0,
    /** Anna share out of 16 (traditional Bangladeshi partnership share unit). Setup!T column. */
    val shareAnna: Double = 0.0,
    val openingDue: Double = 0.0,
    val mobile: String? = null,
    val isActive: Boolean = true
)

@Entity(tableName = "majhis")
data class MajhiEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isActive: Boolean = true
)

@Entity(tableName = "brick_types")
data class BrickTypeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val rate: Double,
    val unitSize: Double? = null,
    val unitDescription: String? = null,
    val sortOrder: Int = 0
)

@Entity(tableName = "equipment")
data class EquipmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** "Excavator" or "Drum Truck" (Setup!K column dropdown) */
    val type: String,
    val hourlyRate: Double = 0.0,
    val driverName: String? = null,
    val isActive: Boolean = true
)

@Entity(tableName = "expense_categories")
data class ExpenseCategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val sortOrder: Int = 0,
    val isActive: Boolean = true
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val openingDue: Double = 0.0,
    val mobile: String? = null,
    val isActive: Boolean = true
)

/**
 * Decision D2: Cash Summary manual-adjustment cells (formerly hardcoded / typed directly
 * into cells like the "+10500" found in Cash Summary!B5). Stored per-season so the app
 * never hardcodes a magic number in code.
 */
@Entity(tableName = "cash_summary_adjustments")
data class CashSummaryAdjustmentEntity(
    @PrimaryKey val season: String, // e.g. "2025-26"
    val seasonFixedAdjustment: Double = 0.0,     // Cash Summary!B5 "+10500" term
    val advanceExpenseNextYear: Double = 0.0,    // Cash Summary!B7 (manual, blue cell)
    val coalRelatedDeposit: Double = 0.0,        // Cash Summary!B8 (manual, blue cell)
    val priorYearDueReturn: Double = 0.0,        // Cash Summary!B9 (manual, blue cell)
    val oldDueStartingPool: Double = 0.0,        // Cash Summary!B61 (manual constant, e.g. 272000)
    val forwardDue: Double = 0.0,                // Cash Summary!B14 (manual, kept 0 to avoid double count)
    val otherAdjustments: Double = 0.0           // Cash Summary!B15 (manual, blue cell)
)

/** Decision D7: append-only ledger of pre-season (2024-25) old-party-due collections. */
@Entity(tableName = "old_due_collections")
data class OldDueCollectionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val name: String,
    val amount: Double,
    val remarks: String? = null,
    val isDeleted: Boolean = false
)

/** Local app user for PIN-based authentication (Decision D4 — single device, no server). */
@Entity(tableName = "app_users")
data class AppUserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val pinHash: String,   // SHA-256(pin + salt), see AuthManager
    val salt: String,
    val role: String = "OWNER", // OWNER / MANAGER / VIEWER — role gate for future multi-user phase
    val isActive: Boolean = true
)
