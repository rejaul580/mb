package com.mbcerp.data.migration

import android.content.Context
import androidx.room.withTransaction
import com.mbcerp.data.db.AppDatabase
import com.mbcerp.data.entity.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * EXCEL -> APP ONE-TIME MIGRATION IMPORTER (Phase 1 items 7 & 8).
 *
 * The source workbook (`MBC_Brickfield_ERP_English_2025-26_03-08-2026-1.xlsx`) was
 * parsed once, offline, with the Python script at /scripts/extract_excel_data.py
 * (included in this project for reproducibility/auditability). That script read every
 * INPUT cell (never a formula result for the transaction tables — formulas like N=K-L-M
 * are recomputed live by FormulaPatterns, never imported as stored numbers) and wrote
 * them to the JSON files bundled under app/src/main/assets/migration/.
 *
 * This importer reads those bundled JSON assets and bulk-inserts them into Room on
 * first launch. It is idempotent (guarded by a "migration done" flag) and runs inside
 * a single Room transaction per table for performance and atomicity.
 *
 * Row counts are asserted against the audited totals (3,802 sales / 1,547 expenses) so
 * that a corrupted or truncated asset file fails loudly instead of silently importing
 * partial data — this directly satisfies "do not lose or simplify any existing data".
 */
class ExcelDataImporter(
    private val context: Context,
    private val db: AppDatabase
) {
    companion object {
        const val EXPECTED_SALES_ROWS = 3802
        const val EXPECTED_EXPENSE_ROWS = 1547
    }

    class MigrationIntegrityException(message: String) : Exception(message)

    suspend fun runIfNeeded() {
        val alreadyDone = db.companyProfileDao().get() != null
        if (alreadyDone) return
        // Single atomic transaction: either the whole migration lands, or none of it does
        // (never leave the local DB half-migrated if something throws partway through).
        db.withTransaction {
            importSetupMaster()
            importSales()
            importExpenses()
            importMiniLedgers()
        }
    }

    private fun readAsset(name: String): String {
        context.assets.open("migration/$name").use { input ->
            BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { return it.readText() }
        }
    }

    private fun optDouble(o: JSONObject, key: String): Double =
        if (o.isNull(key)) 0.0 else o.optDouble(key, 0.0).let { if (it.isNaN()) 0.0 else it }

    private fun optStr(o: JSONObject, key: String): String? =
        if (o.isNull(key)) null else o.optString(key, null)?.takeIf { it != "null" }

    // ---------------------------------------------------------------- Setup master data
    private suspend fun importSetupMaster() {
        val json = JSONObject(readAsset("setup_master.json"))

        val cp = json.getJSONObject("company_profile")
        db.companyProfileDao().upsert(
            CompanyProfileEntity(
                name = optStr(cp, "name") ?: "MBC Brickfield",
                season = optStr(cp, "season") ?: "2025-26",
                address = optStr(cp, "address"),
                phones = optStr(cp, "phones"),
                tagline = optStr(cp, "tagline"),
                openingCapital = optDouble(cp, "opening_capital"),
                customerOpeningDueTotal = optDouble(cp, "customer_opening_due_total"),
                dueBaselineDate = optStr(cp, "due_baseline_date") ?: "2026-07-14",
                defaultDamagePercent = optDouble(cp, "default_damage_pct").takeIf { it > 0 } ?: 0.05,
                seasonEndOverridePercent = optDouble(cp, "season_end_override_pct").takeIf { it > 0 }
            )
        )

        val partners = json.getJSONArray("partners")
        db.partnerDao().insertAll((0 until partners.length()).map { i ->
            val p = partners.getJSONObject(i)
            PartnerEntity(
                name = p.getString("name"),
                capital = optDouble(p, "capital"),
                shareAnna = optDouble(p, "share_anna"),
                openingDue = optDouble(p, "opening_due"),
                mobile = optStr(p, "mobile")
            )
        })

        val majhis = json.getJSONArray("majhis")
        db.majhiDao().insertAll((0 until majhis.length()).map { i ->
            MajhiEntity(name = majhis.getJSONObject(i).getString("name"))
        })

        val brickTypes = json.getJSONArray("brick_types")
        db.brickTypeDao().insertAll((0 until brickTypes.length()).map { i ->
            val b = brickTypes.getJSONObject(i)
            BrickTypeEntity(
                category = b.getString("category"),
                rate = optDouble(b, "rate"),
                unitSize = optDouble(b, "unit_size"),
                unitDescription = optStr(b, "unit_description"),
                sortOrder = i
            )
        })

        val equipment = json.getJSONArray("equipment")
        db.equipmentDao().insertAll((0 until equipment.length()).map { i ->
            val e = equipment.getJSONObject(i)
            EquipmentEntity(
                name = e.getString("name"),
                type = optStr(e, "type") ?: "Excavator",
                hourlyRate = optDouble(e, "hourly_rate"),
                driverName = optStr(e, "driver")
            )
        })

        val categories = json.getJSONArray("expense_categories")
        db.expenseCategoryDao().insertAll((0 until categories.length()).map { i ->
            ExpenseCategoryEntity(category = categories.getJSONObject(i).getString("category"), sortOrder = i)
        })

        val customers = json.getJSONArray("customers")
        db.customerDao().insertAll((0 until customers.length()).map { i ->
            val c = customers.getJSONObject(i)
            CustomerEntity(
                name = c.getString("name"),
                openingDue = optDouble(c, "opening_due"),
                mobile = optStr(c, "mobile")
            )
        })
    }

    // ---------------------------------------------------------------- Sales Register (3,802 rows)
    private suspend fun importSales() {
        val arr: JSONArray = JSONArray(readAsset("sales_register.json"))
        if (arr.length() != EXPECTED_SALES_ROWS) {
            throw MigrationIntegrityException(
                "Sales Register row count mismatch: expected $EXPECTED_SALES_ROWS, found ${arr.length()}. " +
                "Aborting import to avoid silently losing data."
            )
        }
        val entities = (0 until arr.length()).map { i ->
            val r = arr.getJSONObject(i)
            SaleEntity(
                date = optStr(r, "date") ?: "",
                voucherNo = optStr(r, "voucher_no"),
                truckNo = optStr(r, "truck_no"),
                partyType = optStr(r, "party_type") ?: "",
                partyName = optStr(r, "party_name") ?: "",
                location = optStr(r, "location"),
                sideParty = optStr(r, "side_party"),
                sidePartyMobile = null, // AUDIT §9 Q1: source column T is ambiguous, not imported
                brickCategory = optStr(r, "brick_category") ?: "",
                quantity = optDouble(r, "quantity"),
                rate = optDouble(r, "rate"),
                amount = optDouble(r, "amount"),
                advancePayment = optDouble(r, "advance_payment"),
                cashReceived = optDouble(r, "cash_received"),
                remarks = optStr(r, "remarks"),
                saleType = optStr(r, "sale_type")
            )
        }
        db.saleDao().insertAll(entities)
        val imported = db.saleDao().getAll().size
        if (imported != EXPECTED_SALES_ROWS) {
            throw MigrationIntegrityException("Post-import Sales count $imported != expected $EXPECTED_SALES_ROWS")
        }
    }

    // ---------------------------------------------------------------- Expense Register (1,547 rows)
    private suspend fun importExpenses() {
        val arr: JSONArray = JSONArray(readAsset("expense_register.json"))
        if (arr.length() != EXPECTED_EXPENSE_ROWS) {
            throw MigrationIntegrityException(
                "Expense Register row count mismatch: expected $EXPECTED_EXPENSE_ROWS, found ${arr.length()}. " +
                "Aborting import to avoid silently losing data."
            )
        }
        val entities = (0 until arr.length()).map { i ->
            val r = arr.getJSONObject(i)
            ExpenseEntity(
                date = optStr(r, "date") ?: "",
                voucherNo = optStr(r, "voucher_no"),
                category = optStr(r, "category") ?: "",
                partyPaidTo = optStr(r, "party_paid_to"),
                quantity = optDouble(r, "quantity"),
                unit = optStr(r, "unit"),
                rate = optDouble(r, "rate"),
                amount = optDouble(r, "amount"),
                paidCash = optDouble(r, "paid_cash"),
                remarks = optStr(r, "remarks"),
                paymentMethod = optStr(r, "payment_method")
            )
        }
        db.expenseDao().insertAll(entities)
        val imported = db.expenseDao().getAll().size
        if (imported != EXPECTED_EXPENSE_ROWS) {
            throw MigrationIntegrityException("Post-import Expense count $imported != expected $EXPECTED_EXPENSE_ROWS")
        }
    }

    // ---------------------------------------------------------------- Mini-ledgers (Extra payments, stock issues, etc.)
    private suspend fun importMiniLedgers() {
        importJsonArrayIfPresent("customer_extra_payments.json") { r ->
            db.extraPaymentDao().insertCustomerPayment(
                CustomerExtraPaymentEntity(
                    date = optStr(r, "date") ?: "",
                    customerName = optStr(r, "customer_name") ?: "",
                    amount = optDouble(r, "amount"),
                    remarks = optStr(r, "remarks")
                )
            )
        }
        importJsonArrayIfPresent("partner_extra_payments.json") { r ->
            db.extraPaymentDao().insertPartnerPayment(
                PartnerExtraPaymentEntity(
                    date = optStr(r, "date") ?: "",
                    partnerName = optStr(r, "partner_name") ?: "",
                    amount = optDouble(r, "amount"),
                    remarks = optStr(r, "remarks")
                )
            )
        }
        importJsonArrayIfPresent("diesel_issues.json") { r ->
            db.stockDao().insertDieselIssue(
                DieselIssueEntity(date = optStr(r, "date") ?: "", issuedTo = optStr(r, "issued_to"), quantity = optDouble(r, "quantity"))
            )
        }
        importJsonArrayIfPresent("coal_usages.json") { r ->
            db.stockDao().insertCoalUsage(
                CoalUsageEntity(date = optStr(r, "date") ?: "", usedFor = optStr(r, "used_for"), quantity = optDouble(r, "quantity"))
            )
        }
        importJsonArrayIfPresent("equipment_working_hours.json") { r ->
            db.stockDao().insertWorkingHour(
                EquipmentWorkingHourEntity(
                    date = optStr(r, "date") ?: "",
                    equipmentName = optStr(r, "equipment_name") ?: "",
                    hours = optDouble(r, "hours"),
                    rate = optDouble(r, "rate")
                )
            )
        }
        importJsonArrayIfPresent("production_entries.json") { r ->
            db.productionDao().insert(
                ProductionEntryEntity(
                    date = optStr(r, "date") ?: "",
                    serialRef = optStr(r, "serial_ref"),
                    majhiName = optStr(r, "majhi_name"),
                    type = optStr(r, "type"),
                    rawBricksCounted = optDouble(r, "raw_bricks_counted"),
                    loadedToKiln = optDouble(r, "loaded_to_kiln"),
                    unloadedFiredOut = optDouble(r, "unloaded_fired_out"),
                    remarks = optStr(r, "remarks")
                )
            )
        }
        importJsonArrayIfPresent("asset_register.json") { r ->
            db.assetRegisterDao().insert(
                AssetRegisterEntity(
                    date = optStr(r, "date"),
                    assetType = optStr(r, "asset_type"),
                    description = optStr(r, "description"),
                    location = optStr(r, "location"),
                    area = optDouble(r, "area"),
                    unit = optStr(r, "unit"),
                    purchaseAmount = optDouble(r, "purchase_amount"),
                    documentRef = optStr(r, "document_ref"),
                    owners = optStr(r, "owners"),
                    remarks = optStr(r, "remarks")
                )
            )
        }
        importJsonArrayIfPresent("old_due_collections.json") { r ->
            db.oldDueCollectionDao().insert(
                OldDueCollectionEntity(
                    date = optStr(r, "date") ?: "",
                    name = optStr(r, "name") ?: "",
                    amount = optDouble(r, "amount"),
                    remarks = optStr(r, "remarks")
                )
            )
        }

        // Decision D2: seed Cash Summary manual adjustments for the migrated season,
        // replacing every hardcoded number found in the source sheet (e.g. "+10500").
        val cp = db.companyProfileDao().get()
        db.cashSummaryAdjustmentDao().upsert(
            CashSummaryAdjustmentEntity(
                season = cp?.season ?: "2025-26",
                seasonFixedAdjustment = 10500.0,   // migrated verbatim from Cash Summary!B5, now editable
                advanceExpenseNextYear = 0.0,
                coalRelatedDeposit = 0.0,
                priorYearDueReturn = 0.0,
                oldDueStartingPool = 272000.0,     // migrated verbatim from Cash Summary!B61
                forwardDue = 0.0,
                otherAdjustments = 0.0
            )
        )
    }

    private inline fun importJsonArrayIfPresent(assetName: String, block: (JSONObject) -> Unit) {
        val text = runCatching { readAsset(assetName) }.getOrNull() ?: return
        val arr = JSONArray(text)
        for (i in 0 until arr.length()) block(arr.getJSONObject(i))
    }
}
