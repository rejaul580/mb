package com.mbcerp.domain.calc

import com.mbcerp.data.entity.CashSummaryAdjustmentEntity

/**
 * Cash Summary "waterfall" engine (AUDIT REPORT §2.7 / §4.3). Reproduces the exact
 * chain of subtractions found in the Cash Summary sheet, cell by cell. All manual
 * blue-cell inputs (Decision D2) are passed in via [CashSummaryAdjustmentEntity]
 * instead of being hardcoded — this specifically replaces the "+10500" magic number
 * that was typed directly into Cash Summary!B5 in the source file.
 */
object CashWaterfallCalculator {

    data class WaterfallResult(
        val totalSalesAndCapital: Double,   // B5
        val totalExpense: Double,           // B6
        val currentCashBeforeDue: Double,   // B10
        val partnerDue: Double,             // B11
        val customerDue: Double,            // B12
        val oldPartyDue2024_25: Double,     // B13
        val forwardDue: Double,             // B14
        val otherAdjustments: Double,       // B15
        val finalCashInHand: Double         // B16 — the number the manager actually cares about
    )

    fun compute(
        totalSales: Double,
        openingCapital: Double,
        totalExpense: Double,
        totalPartnerDue: Double,
        totalCustomerDue: Double,
        oldDueTotalCollected: Double,
        adjustments: CashSummaryAdjustmentEntity
    ): WaterfallResult {
        val totalSalesAndCapital = totalSales + openingCapital + adjustments.seasonFixedAdjustment
        val currentCash = totalSalesAndCapital -
            totalExpense -
            adjustments.advanceExpenseNextYear -
            adjustments.coalRelatedDeposit +
            adjustments.priorYearDueReturn
        val oldPartyDue = adjustments.oldDueStartingPool - oldDueTotalCollected
        val finalCash = currentCash -
            totalPartnerDue -
            totalCustomerDue -
            oldPartyDue -
            adjustments.forwardDue -
            adjustments.otherAdjustments

        return WaterfallResult(
            totalSalesAndCapital = totalSalesAndCapital,
            totalExpense = totalExpense,
            currentCashBeforeDue = currentCash,
            partnerDue = totalPartnerDue,
            customerDue = totalCustomerDue,
            oldPartyDue2024_25 = oldPartyDue,
            forwardDue = adjustments.forwardDue,
            otherAdjustments = adjustments.otherAdjustments,
            finalCashInHand = finalCash
        )
    }

    /** Season P&L (Cash Summary rows 20-24): simple, ignores due/capital by design. */
    fun netProfitLoss(totalSales: Double, totalExpense: Double): Double = totalSales - totalExpense
}

/** 16-Anna partner profit distribution engine (Cash Summary rows 26-57). */
object ProfitDistributionCalculator {
    data class PartnerShare(val partnerName: String, val shareAnna: Double, val profitShare: Double)

    fun distribute(netProfit: Double, partners: List<Pair<String, Double>>): List<PartnerShare> =
        partners.map { (name, annaShare) ->
            PartnerShare(name, annaShare, annaShare / 16.0 * netProfit)
        }
}
