package com.mbcerp.domain.calc

import com.mbcerp.data.entity.SaleEntity
import java.time.LocalDate

/**
 * Customer / Partner Ledger due-calculation engine (AUDIT REPORT §2.4).
 *
 * D-QUIRK-1 — FULL RESOLUTION (supersedes the Phase-1/2 partial finding). Deep-audit of
 * the actual cell formulas (not just the documented pattern) revealed the source file's
 * PARTNER and CUSTOMER ledgers are NOT structurally identical, despite looking that way:
 *
 * PARTNER LEDGER: ONE consistent Due formula, used on both the single-party detail
 * screen (row 8) and the all-partner list (row 1670+):
 *     Due = openingDue + SUMIFS(amount, date>baseline) - SUMIFS(advance, date>baseline)
 *           - SUMIFS(cash, date>baseline) - extraPayment
 * This is Pattern 5 / FormulaPatterns.calcDue -- verified against all 13 partners, 100% match.
 *
 * CUSTOMER LEDGER: the two screens use TWO GENUINELY DIFFERENT formulas for the same
 * label ("Total Due") -- this is a real inconsistency in the original spreadsheet, not
 * a display quirk:
 *   - Detail screen (Customer Ledger row 8, D8 = A8-B8-C8): totalSales(ALL time, no
 *     baseline filter) - receivedAtSale(ALL time: SUMIFS(advance)+SUMIFS(cash)) -
 *     extraPayment. Never touches Setup opening due at all.
 *   - All-customer list (Customer Ledger row 670+, E670 = B670-C670-D670, which
 *     algebraically reduces to): openingDue - extraPayment. Never touches the Sales
 *     Register's actual amount/advance/cash figures for that customer at all.
 *
 * SEVERITY (confirmed against the full 393-customer dataset, not a rare edge case):
 * this is NOT a narrow 4-customer discrepancy -- it affects effectively every customer
 * who was never given an explicit "Opening Due" value in Setup!R (the overwhelming
 * majority, 375 of 393 in the current data have openingDue=0). For those customers the
 * all-customer-list screen shows Total Due = 0 regardless of how much they actually
 * owe, while the detail screen (select that one customer, look at row 8) shows the
 * real, accurate outstanding balance. This is a genuine, high-impact defect in the
 * source spreadsheet's most-used summary view, confirmed by cross-referencing a live
 * cached snapshot in the file itself (Customer Ledger!B3 was saved with "faici driver"
 * selected; cached D8 = 32,600 -- the correct detail-formula answer -- while that same
 * customer's row in the all-customer list below shows only their old opening due).
 *
 * Per "do not change the original Excel logic": BOTH customer formulas are reproduced
 * exactly as-is below, never merged or "corrected". The app surfaces both, clearly
 * labeled, on the Ledger screen -- see ui/ledger/LedgerScreen.kt -- rather than silently
 * picking one, so a bookkeeper sees exactly what the two Excel screens would have shown.
 */
object DueCalculator {

    fun totalSalesFor(sales: List<SaleEntity>, partyType: String, partyName: String): Double =
        FormulaPatterns.filterSalesByParty(sales, partyType, partyName).sumOf { it.amount }

    /** SUMIFS(advance)+SUMIFS(cash), ALL time, no baseline filter -- used by both party types' detail screens. */
    fun receivedAtSaleAllTime(sales: List<SaleEntity>, partyType: String, partyName: String): Double =
        FormulaPatterns.filterSalesByParty(sales, partyType, partyName)
            .sumOf { it.advancePayment + it.cashReceived }

    // ---------------------------------------------------------------- PARTNER (single consistent formula)

    data class PartnerDueSummary(
        val partnerName: String,
        val totalSales: Double,
        val receivedAtSaleAllTime: Double,
        val extraPayment: Double,
        val totalDue: Double // baseline-date-aware, Pattern 5 -- same formula on both Partner Ledger screens
    )

    fun partnerDue(
        sales: List<SaleEntity>,
        partnerName: String,
        openingDue: Double,
        baselineDate: LocalDate,
        extraPaymentTotal: Double
    ): PartnerDueSummary {
        val totalSales = totalSalesFor(sales, "Partner", partnerName)
        val received = receivedAtSaleAllTime(sales, "Partner", partnerName)
        val due = FormulaPatterns.calcDue(sales, "Partner", partnerName, openingDue, baselineDate, extraPaymentTotal)
        return PartnerDueSummary(partnerName, totalSales, received, extraPaymentTotal, due)
    }

    // ---------------------------------------------------------------- CUSTOMER (two genuinely different formulas)

    data class CustomerDueSummary(
        val customerName: String,
        val totalSalesAllTime: Double,
        val receivedAtSaleAllTime: Double,
        val extraPayment: Double,
        val openingDue: Double,
        /** Detail screen (row 8) formula: totalSales - receivedAtSale - extraPayment. All-time, no baseline. */
        val totalDueDetailScreen: Double,
        /** All-customer-list screen (row 670+) formula: openingDue - extraPayment. Ignores Sales Register net activity. */
        val totalDueAllListScreen: Double
    ) {
        /** True when the two source-file formulas disagree for this customer (see class doc). */
        val formulasDisagree: Boolean get() = kotlin.math.abs(totalDueDetailScreen - totalDueAllListScreen) > 0.5
    }

    fun customerDue(
        sales: List<SaleEntity>,
        customerName: String,
        openingDue: Double,
        extraPaymentTotal: Double
    ): CustomerDueSummary {
        val totalSales = totalSalesFor(sales, "Customer", customerName)
        val received = receivedAtSaleAllTime(sales, "Customer", customerName)
        val detailDue = totalSales - received - extraPaymentTotal
        val allListDue = openingDue - extraPaymentTotal
        return CustomerDueSummary(
            customerName = customerName,
            totalSalesAllTime = totalSales,
            receivedAtSaleAllTime = received,
            extraPayment = extraPaymentTotal,
            openingDue = openingDue,
            totalDueDetailScreen = detailDue,
            totalDueAllListScreen = allListDue
        )
    }
}
