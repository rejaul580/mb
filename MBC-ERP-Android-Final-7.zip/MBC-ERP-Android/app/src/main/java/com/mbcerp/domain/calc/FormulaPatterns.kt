package com.mbcerp.domain.calc

import com.mbcerp.data.entity.SaleEntity
import com.mbcerp.data.entity.ExpenseEntity
import java.time.LocalDate

/**
 * FORMULA PATTERNS — pure, side-effect-free re-implementations of the 6 core repeating
 * Excel formula patterns documented in AUDIT REPORT §4.1. Every function here has an
 * equivalent, verified-correct implementation in /validation/src/Validate.java, which
 * was run against the real 3,802 Sales + 1,547 Expense rows and matched the Excel
 * cached formula results with 0 discrepancies (see VALIDATION_REPORT.md).
 *
 * These are intentionally framework-free (no Room/Android types) so they are trivially
 * unit-testable on the JVM without an emulator (see app/src/test/.../FormulaPatternsTest.kt).
 */
object FormulaPatterns {

    /** Pattern 1 — Rate Auto-Lookup: Sales Register!J = INDEX(RateList, MATCH(category, BrickTypeList)) */
    fun lookupRate(category: String, brickTypeToRate: Map<String, Double>): Double =
        brickTypeToRate[category] ?: 0.0

    /** Sales Register!N = K - L - M (computed on read, never persisted — matches Excel's live formula) */
    fun salesDue(amount: Double, advance: Double, cashReceived: Double): Double =
        amount - advance - cashReceived

    /** Expense Register!J = H - I (computed on read) */
    fun expenseDuePayable(amount: Double, paidCash: Double): Double =
        amount - paidCash

    /** Pattern 3 — Filtered-Row Puller: category-filtered view (replaces all 41 HL_ sheets + Ledger Viewer).
     *  Case-insensitive, matching Excel's SUMIFS/COUNTIFS text comparison (verified against live
     *  data: source file has "faici driver" in a selector cell matching "FAICI DRIVER" rows). */
    fun filterExpensesByCategory(expenses: List<ExpenseEntity>, category: String): List<ExpenseEntity> =
        expenses.filter { !it.isDeleted && it.category.equals(category, ignoreCase = true) }

    fun filterSalesByParty(sales: List<SaleEntity>, partyType: String, partyName: String): List<SaleEntity> =
        sales.filter { !it.isDeleted && it.partyType.equals(partyType, ignoreCase = true) && it.partyName.equals(partyName, ignoreCase = true) }

    /** Pattern 4 — Running Balance: Customer/Partner Ledger!P = cumulative SUM of (advance+cash-amount) up to row */
    fun runningBalances(rows: List<SaleEntity>): List<Double> {
        var running = 0.0
        return rows.map { r ->
            running += (r.advancePayment + r.cashReceived - r.amount)
            running
        }
    }

    /**
     * Pattern 5 — Due Calculation (baseline-date-aware). Used identically for both
     * Customer Ledger and Partner Ledger (AUDIT §2.4). Only sales strictly AFTER the
     * baseline date are counted on top of the Setup opening-due figure; everything up to
     * and including the baseline date is assumed already folded into openingDue.
     */
    fun calcDue(
        sales: List<SaleEntity>,
        partyType: String,
        partyName: String,
        openingDue: Double,
        baselineDate: LocalDate,
        extraPaymentTotal: Double
    ): Double {
        var sumAmount = 0.0
        var sumAdvance = 0.0
        var sumCash = 0.0
        for (row in sales) {
            if (row.isDeleted) continue
            if (!row.partyType.equals(partyType, ignoreCase = true) || !row.partyName.equals(partyName, ignoreCase = true)) continue
            val d = runCatching { LocalDate.parse(row.date) }.getOrNull() ?: continue
            if (!d.isAfter(baselineDate)) continue // Excel: Date > BaselineDate (strict)
            sumAmount += row.amount
            sumAdvance += row.advancePayment
            sumCash += row.cashReceived
        }
        return openingDue + sumAmount - sumAdvance - sumCash - extraPaymentTotal
    }

    /** Pattern 6 — row-level validator, mirrors Sales Register!S / Expense Register!R IF-chain. */
    fun validateSalesRow(row: SaleEntity): String? = when {
        row.voucherNo.isNullOrBlank() -> "Voucher Number Missing"
        row.partyName.isBlank() -> "Party Name Missing"
        row.quantity <= 0.0 && row.brickCategory.isNotBlank() -> "Quantity Missing"
        row.brickCategory.isBlank() && row.quantity > 0.0 -> "Brick Category Missing"
        row.rate <= 0.0 || row.amount <= 0.0 -> "Rate/Amount Zero - Check"
        row.amount > 0.0 && row.date.isBlank() -> "Date Missing"
        else -> null
    }

    fun validateExpenseRow(row: ExpenseEntity): String? = when {
        row.voucherNo.isNullOrBlank() -> "Voucher Number Missing"
        row.category.isBlank() -> "Category Missing"
        row.amount <= 0.0 -> "Amount Zero - Check"
        row.amount > 0.0 && row.date.isBlank() -> "Date Missing"
        else -> null
    }
}
