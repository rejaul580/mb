package com.mbcerp.domain.calc

import com.mbcerp.data.entity.ExpenseEntity

/**
 * Stock engine: Diesel Register / Coal Register / Production Register (AUDIT §2.6, §2.9).
 * All three share the same structural shape: stock = purchased/produced - issued/used/sold.
 */
object StockCalculator {

    data class StockResult(val purchasedOrProduced: Double, val totalCost: Double, val issuedOrUsed: Double, val currentStock: Double)

    fun dieselStock(expenses: List<ExpenseEntity>, dieselIssuedTotal: Double): StockResult {
        val purchased = expenses.filter { !it.isDeleted && it.category == "Diesel" }.sumOf { it.quantity }
        val cost = expenses.filter { !it.isDeleted && (it.category == "Diesel" || it.category == "Diesel Transport") }.sumOf { it.amount }
        return StockResult(purchased, cost, dieselIssuedTotal, purchased - dieselIssuedTotal)
    }

    fun coalStock(expenses: List<ExpenseEntity>, coalUsedTotal: Double): StockResult {
        val purchased = expenses.filter { !it.isDeleted && it.category == "Coal Purchase" }.sumOf { it.quantity }
        val cost = expenses.filter {
            !it.isDeleted && it.category in setOf("Coal Purchase", "Coal Transport", "Coal Breaking")
        }.sumOf { it.amount }
        return StockResult(purchased, cost, coalUsedTotal, purchased - coalUsedTotal)
    }

    /**
     * Production Register stock estimate (AUDIT §2.9). Faithful to source: ONLY brick
     * categories "1 No" and "2 No" (Manual + Auto) are counted, per Decision D6 —
     * preserved exactly rather than "fixed" to cover all brick types, to keep numeric
     * parity with the historical Excel figures. A configurable category list is a
     * documented Phase-2 enhancement (see DECISIONS.md D6).
     */
    fun productionStockEstimate(
        totalLoadedToKiln: Double,
        damagePercent: Double,
        totalSoldOfCoveredCategories: Double
    ): Double {
        val estimatedProduced = totalLoadedToKiln * (1 - damagePercent)
        return estimatedProduced - totalSoldOfCoveredCategories
    }
}

/** Reconciliation / Audit engine (AUDIT §2.11 "Audit Sheet"). */
object ValidationEngine {

    data class AuditResult(val check: String, val ok: Boolean, val detail: String? = null)

    /** Setup!Audit — partner share-of-16-anna total must equal 100% (i.e. Anna total = 16). */
    fun checkPartnerShareTotal(totalShareAnna: Double): AuditResult {
        val ok = kotlin.math.abs(totalShareAnna - 16.0) < 0.0001
        return AuditResult("Partner Share Total = 16 Anna", ok, "actual=$totalShareAnna")
    }

    fun checkNoDuplicateNames(names: List<String>, label: String): AuditResult {
        val dupes = names.groupingBy { it }.eachCount().filter { it.value > 1 }.keys
        return AuditResult("No duplicate $label", dupes.isEmpty(), if (dupes.isNotEmpty()) "duplicates=$dupes" else null)
    }

    /** Expense Register total must reconcile exactly with the sum of Expense Summary category totals. */
    fun checkExpenseReconciliation(registerTotal: Double, summaryTotal: Double): AuditResult {
        val ok = kotlin.math.abs(registerTotal - summaryTotal) < 0.01
        return AuditResult("Expense Register = Expense Summary", ok, "register=$registerTotal summary=$summaryTotal")
    }
}
