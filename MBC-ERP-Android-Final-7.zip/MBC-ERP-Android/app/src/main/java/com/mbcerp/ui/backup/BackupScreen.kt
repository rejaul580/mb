package com.mbcerp.ui.backup

import androidx.compose.ui.res.stringResource

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.mbcerp.backup.BackupBundle
import com.mbcerp.backup.GoogleDriveBackupManager
import com.mbcerp.backup.LocalExportImport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * GOOGLE DRIVE BACKUP/RESTORE SCREEN (item 6). Sign-in, manual "Backup Now", and a
 * list of available backups to restore from, with an explicit confirm step before
 * restore (since restore replaces on-device data).
 */
class BackupViewModel(
    private val exportImport: LocalExportImport,
    private val driveManager: GoogleDriveBackupManager
) : ViewModel() {

    private val _account = MutableStateFlow<GoogleSignInAccount?>(null)
    val account: StateFlow<GoogleSignInAccount?> = _account

    private val _backups = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val backups: StateFlow<List<Pair<String, String>>> = _backups

    private val _status = MutableStateFlow<String?>(null)
    val status: StateFlow<String?> = _status

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy

    fun checkSignIn() {
        _account.value = driveManager.lastSignedInAccount()
    }

    fun onSignedIn(account: GoogleSignInAccount) {
        _account.value = account
        refreshBackupList()
    }

    fun refreshBackupList() {
        val acc = _account.value ?: return
        viewModelScope.launch {
            _busy.value = true
            try {
                val list = withContext(Dispatchers.IO) { driveManager.listBackups(acc) }
                _backups.value = list
            } catch (e: Exception) {
                _status.value = "তালিকা আনতে ব্যর্থ: ${e.message}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun backupNow() {
        val acc = _account.value ?: return
        viewModelScope.launch {
            _busy.value = true
            _status.value = null
            try {
                val bundle = exportImport.exportAll()
                withContext(Dispatchers.IO) { driveManager.uploadBackup(acc, bundle) }
                _status.value = "✓ Backup সফল হয়েছে (${bundle.manifest.tableRowCounts.values.sum()} টা row)"
                refreshBackupList()
            } catch (e: Exception) {
                _status.value = "Backup ব্যর্থ: ${e.message}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun restore(fileId: String) {
        val acc = _account.value ?: return
        viewModelScope.launch {
            _busy.value = true
            _status.value = null
            try {
                val bundle: BackupBundle = withContext(Dispatchers.IO) { driveManager.downloadBackup(acc, fileId) }
                exportImport.importAll(bundle)
                _status.value = "✓ Restore সম্পূর্ণ হয়েছে"
            } catch (e: Exception) {
                _status.value = "Restore ব্যর্থ: ${e.message}"
            } finally {
                _busy.value = false
            }
        }
    }
}

class BackupViewModelFactory(
    private val exportImport: LocalExportImport,
    private val driveManager: GoogleDriveBackupManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = BackupViewModel(exportImport, driveManager) as T
}

@Composable
fun BackupScreen(vm: BackupViewModel, driveManager: GoogleDriveBackupManager) {
    val context = LocalContext.current
    val account by vm.account.collectAsState()
    val backups by vm.backups.collectAsState()
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()
    var confirmRestoreId by remember { mutableStateOf<String?>(null) }

    val signInLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(result.data)
        task.addOnSuccessListener { account -> vm.onSignedIn(account) }
    }

    LaunchedEffect(Unit) { vm.checkSignIn() }

    Scaffold(topBar = { TopAppBar(title = { Text("Backup / Restore (Google Drive)") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            if (account == null) {
                Text("Backup নেওয়ার জন্য প্রথমে Google দিয়ে sign in করুন।")
                Spacer(Modifier.height(8.dp))
                Button(onClick = { signInLauncher.launch(driveManager.signInClient().signInIntent) }) {
                    Text("Google দিয়ে Sign In করুন")
                }
            } else {
                Text("Signed in: ${account?.email}")
                Spacer(Modifier.height(12.dp))
                Button(onClick = { vm.backupNow() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "কাজ চলছে…" else "এখনই Backup নিন")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { vm.refreshBackupList() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text("Backup তালিকা রিফ্রেশ করুন")
                }
                status?.let { Text(it, modifier = Modifier.padding(top = 8.dp)) }

                Spacer(Modifier.height(16.dp))
                Text("পূর্ববর্তী Backup সমূহ:", style = MaterialTheme.typography.titleSmall)
                LazyColumn {
                    items(backups) { (id, name) ->
                        ListItem(
                            headlineContent = { Text(name) },
                            trailingContent = {
                                TextButton(onClick = { confirmRestoreId = id }) { Text("Restore") }
                            }
                        )
                        Divider()
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                "নোট: মূল Excel ফাইল এই অ্যাপ কখনো স্পর্শ করে না -- Backup শুধু এই অ্যাপের নিজস্ব ডেটাবেসের " +
                "(Sales, Expense, Setup, Ledger, Settings) একটা JSON কপি তৈরি করে আপনার নিজের Google Drive-এ রাখে।",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }

    confirmRestoreId?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmRestoreId = null },
            title = { Text("আসলেই Restore করবেন?") },
            text = { Text("এটা বর্তমান ডিভাইসের ডেটার সাথে merge হবে (id অনুযায়ী replace) -- এটা করার আগে নিশ্চিত হয়ে নিন।") },
            confirmButton = {
                TextButton(onClick = { vm.restore(id); confirmRestoreId = null }) { Text("হ্যাঁ, Restore করুন") }
            },
            dismissButton = { TextButton(onClick = { confirmRestoreId = null }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}
