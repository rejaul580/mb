package com.mbcerp.ui.expense

import androidx.compose.ui.res.stringResource

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.EquipmentEntity
import com.mbcerp.data.entity.ExpenseCategoryEntity
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.repository.ExpenseRepository
import com.mbcerp.repository.SetupRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * Covers Entry Guide rules #6 (customer discount/rounding — a small negative
 * adjustment on a sale, entered as an Expense Register row with a category like
 * "Discount/Rounding") and #7 (general expense — majhi/diesel/material/etc.), per
 * AUDIT §6.1. Both are just a normal Expense Register row with a category selected
 * from Setup — there is no separate "mode" needed, unlike the Sales side, because
 * Excel itself treats them identically (only the chosen Category differs).
 */
class ExpenseEntryViewModel(
    private val expenseRepository: ExpenseRepository,
    private val setupRepository: SetupRepository
) : ViewModel() {

    val categories: StateFlow<List<ExpenseCategoryEntity>> =
        setupRepository.observeExpenseCategories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val equipment: StateFlow<List<EquipmentEntity>> =
        setupRepository.observeEquipment().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved

    fun submit(expense: ExpenseEntity) {
        viewModelScope.launch {
            expenseRepository.addExpense(expense)
            _saved.value = true
        }
    }

    fun resetSaved() { _saved.value = false }
}

class ExpenseEntryViewModelFactory(
    private val expenseRepository: ExpenseRepository,
    private val setupRepository: SetupRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        ExpenseEntryViewModel(expenseRepository, setupRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseEntryScreen(vm: ExpenseEntryViewModel, onSaved: () -> Unit) {
    val categories by vm.categories.collectAsState()
    val equipment by vm.equipment.collectAsState()
    val saved by vm.saved.collectAsState()

    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var voucherNo by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var partyPaidTo by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var paidCash by remember { mutableStateOf("") }
    var paymentMethod by remember { mutableStateOf("Cash") }
    var remarks by remember { mutableStateOf("") }

    val isEquipmentCategory = category == "Excavator" || category == "Drum Truck"

    LaunchedEffect(saved) { if (saved) { onSaved(); vm.resetSaved() } }

    Scaffold(topBar = { TopAppBar(title = { Text("নতুন খরচ এন্ট্রি") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(voucherNo, { voucherNo = it }, label = { Text("Voucher No") }, modifier = Modifier.fillMaxWidth())

            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = category, onValueChange = {}, readOnly = true, label = { Text("Category") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    categories.forEach { c ->
                        DropdownMenuItem(text = { Text(c.category) }, onClick = { category = c.category; expanded = false })
                    }
                }
            }

            if (isEquipmentCategory) {
                var eqExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = eqExpanded, onExpandedChange = { eqExpanded = it }) {
                    OutlinedTextField(
                        value = partyPaidTo, onValueChange = {}, readOnly = true, label = { Text("Equipment") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = eqExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = eqExpanded, onDismissRequest = { eqExpanded = false }) {
                        equipment.filter { it.type == category }.forEach { e ->
                            DropdownMenuItem(text = { Text(e.name) }, onClick = { partyPaidTo = e.name; eqExpanded = false })
                        }
                    }
                }
            } else {
                OutlinedTextField(partyPaidTo, { partyPaidTo = it }, label = { Text("Party / Paid To") }, modifier = Modifier.fillMaxWidth())
            }

            OutlinedTextField(quantity, { quantity = it }, label = { Text("Quantity") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(unit, { unit = it }, label = { Text("Unit") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(rate, { rate = it }, label = { Text("Rate") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(paidCash, { paidCash = it }, label = { Text("Paid (Cash)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())

            Row {
                listOf("Cash", "Bank", "Others").forEach { m ->
                    FilterChip(selected = paymentMethod == m, onClick = { paymentMethod = m }, label = { Text(m) }, modifier = Modifier.padding(end = 8.dp))
                }
            }
            OutlinedTextField(remarks, { remarks = it }, label = { Text("Remarks") }, modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = {
                    vm.submit(
                        ExpenseEntity(
                            date = date, voucherNo = voucherNo.ifBlank { null }, category = category,
                            partyPaidTo = partyPaidTo.ifBlank { null },
                            quantity = quantity.toDoubleOrNull() ?: 0.0, unit = unit.ifBlank { null },
                            rate = rate.toDoubleOrNull() ?: 0.0, amount = amount.toDoubleOrNull() ?: 0.0,
                            paidCash = paidCash.toDoubleOrNull() ?: 0.0, remarks = remarks.ifBlank { null },
                            paymentMethod = paymentMethod
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(com.mbcerp.R.string.action_save)) }
        }
    }
}
