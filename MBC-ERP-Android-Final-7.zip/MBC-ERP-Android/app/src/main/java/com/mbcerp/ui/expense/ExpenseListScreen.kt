package com.mbcerp.ui.expense

import androidx.compose.ui.res.stringResource

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.domain.calc.FormulaPatterns
import com.mbcerp.repository.ExpenseRepository
import com.mbcerp.ui.common.EmptyState
import kotlinx.coroutines.flow.*

data class ExpenseRow(val expense: ExpenseEntity, val duePayable: Double)

data class ExpenseListFilter(val query: String = "", val category: String? = null)

class ExpenseListViewModel(private val expenseRepository: ExpenseRepository) : ViewModel() {

    private val _filter = MutableStateFlow(ExpenseListFilter())
    val filter: StateFlow<ExpenseListFilter> = _filter

    private val allExpenses: StateFlow<List<ExpenseEntity>> =
        expenseRepository.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val visibleRows: StateFlow<List<ExpenseRow>> = combine(allExpenses, _filter) { rows, f ->
        rows.asSequence()
            .filter { f.category == null || it.category == f.category }
            .filter {
                f.query.isBlank() ||
                    it.voucherNo?.contains(f.query, ignoreCase = true) == true ||
                    it.category.contains(f.query, ignoreCase = true) ||
                    it.partyPaidTo?.contains(f.query, ignoreCase = true) == true
            }
            .map { ExpenseRow(it, FormulaPatterns.expenseDuePayable(it.amount, it.paidCash)) }
            .toList()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalAmount: StateFlow<Double> = visibleRows.map { rows -> rows.sumOf { it.expense.amount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun updateQuery(q: String) { _filter.value = _filter.value.copy(query = q) }
    fun updateCategory(c: String?) { _filter.value = _filter.value.copy(category = c) }

    fun updateExpense(e: ExpenseEntity) { viewModelScope.launch { expenseRepository.updateExpense(e) } }
    fun deleteExpense(id: Long) { viewModelScope.launch { expenseRepository.removeExpense(id) } }
}

class ExpenseListViewModelFactory(private val expenseRepository: ExpenseRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ExpenseListViewModel(expenseRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseListScreen(vm: ExpenseListViewModel, onAddClick: () -> Unit) {
    val filter by vm.filter.collectAsState()
    val rows by vm.visibleRows.collectAsState()
    val total by vm.totalAmount.collectAsState()
    var editingRow by remember { mutableStateOf<ExpenseRow?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("খরচের তালিকা (${rows.size})") }) },
        floatingActionButton = { FloatingActionButton(onClick = onAddClick) { Icon(Icons.Default.Add, contentDescription = "Add Expense") } }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = filter.query, onValueChange = vm::updateQuery,
                label = { Text("খুঁজুন: Voucher / Category / Party") },
                modifier = Modifier.fillMaxWidth().padding(8.dp)
            )
            Text("মোট Amount (ফিল্টার করা তালিকা): ৳${"%,.2f".format(total)}", modifier = Modifier.padding(8.dp))
            Text("এন্ট্রি tap করলে edit করা যাবে", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 8.dp))
            Divider()
            if (rows.isEmpty()) {
                EmptyState(
                    icon = Icons.Default.Receipt,
                    title = "কোনো খরচ পাওয়া যায়নি",
                    subtitle = if (filter.query.isNotBlank() || filter.category != null) "ফিল্টার পরিবর্তন করে দেখুন" else "নিচের + বাটনে চাপ দিয়ে নতুন খরচ এন্ট্রি দিন"
                )
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(rows, key = { it.expense.id }) { row ->
                    ListItem(
                        headlineContent = { Text("${row.expense.date}  •  ${row.expense.category}") },
                        supportingContent = {
                            Text(
                                "Voucher: ${row.expense.voucherNo ?: "-"}  |  Paid To: ${row.expense.partyPaidTo ?: "-"}  |  " +
                                "Amount: ৳${row.expense.amount}  |  Due: ৳${row.duePayable}"
                            )
                        },
                        modifier = Modifier.clickable { editingRow = row }
                    )
                    Divider()
                }
            }
        }
    }

    editingRow?.let { row ->
        EditExpenseDialog(
            expense = row.expense,
            onDismiss = { editingRow = null },
            onSave = { updated -> vm.updateExpense(updated); editingRow = null },
            onDelete = { vm.deleteExpense(row.expense.id); editingRow = null }
        )
    }
}

@Composable
private fun EditExpenseDialog(expense: ExpenseEntity, onDismiss: () -> Unit, onSave: (ExpenseEntity) -> Unit, onDelete: () -> Unit) {
    var date by remember { mutableStateOf(expense.date) }
    var voucherNo by remember { mutableStateOf(expense.voucherNo ?: "") }
    var category by remember { mutableStateOf(expense.category) }
    var partyPaidTo by remember { mutableStateOf(expense.partyPaidTo ?: "") }
    var quantity by remember { mutableStateOf(expense.quantity.toString()) }
    var amount by remember { mutableStateOf(expense.amount.toString()) }
    var paidCash by remember { mutableStateOf(expense.paidCash.toString()) }
    var remarks by remember { mutableStateOf(expense.remarks ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("খরচ এন্ট্রি Edit করুন") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(date, { date = it }, label = { Text("Date") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(voucherNo, { voucherNo = it }, label = { Text("Voucher No") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(category, { category = it }, label = { Text("Category") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(partyPaidTo, { partyPaidTo = it }, label = { Text("Party / Paid To") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(quantity, { quantity = it }, label = { Text("Quantity") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(paidCash, { paidCash = it }, label = { Text("Paid (Cash)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(remarks, { remarks = it }, label = { Text("Remarks") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                if (!confirmDelete) {
                    TextButton(onClick = { confirmDelete = true }) { Text("Delete This Entry", color = MaterialTheme.colorScheme.error) }
                } else {
                    Text("আসলেই delete করবেন?", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton(onClick = onDelete) { Text("হ্যাঁ, Delete করুন", color = MaterialTheme.colorScheme.error) }
                        TextButton(onClick = { confirmDelete = false }) { Text("না") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    expense.copy(
                        date = date, voucherNo = voucherNo.ifBlank { null }, category = category,
                        partyPaidTo = partyPaidTo.ifBlank { null }, quantity = quantity.toDoubleOrNull() ?: 0.0,
                        amount = amount.toDoubleOrNull() ?: 0.0, paidCash = paidCash.toDoubleOrNull() ?: 0.0,
                        remarks = remarks.ifBlank { null }
                    )
                )
            }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
    )
}
