package com.mbcerp.ui.sales

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.BrickTypeEntity
import com.mbcerp.data.entity.CustomerEntity
import com.mbcerp.data.entity.PartnerEntity
import com.mbcerp.domain.entry.EntryGuideEngine
import com.mbcerp.domain.entry.EntryMode
import com.mbcerp.domain.entry.SalesEntryInput
import com.mbcerp.repository.SalesRepository
import com.mbcerp.repository.SetupRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class SalesEntryResult {
    object Idle : SalesEntryResult()
    object Saving : SalesEntryResult()
    data class Success(val rowsWritten: Int) : SalesEntryResult()
    data class Error(val message: String) : SalesEntryResult()
}

class SalesEntryViewModel(
    private val salesRepository: SalesRepository,
    private val setupRepository: SetupRepository
) : ViewModel() {

    val customers: StateFlow<List<CustomerEntity>> =
        setupRepository.observeCustomers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val partners: StateFlow<List<PartnerEntity>> =
        setupRepository.observePartners().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val brickTypes: StateFlow<List<BrickTypeEntity>> =
        setupRepository.observeBrickTypes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _result = MutableStateFlow<SalesEntryResult>(SalesEntryResult.Idle)
    val result: StateFlow<SalesEntryResult> = _result

    /** Pattern 1 (Rate Auto-Lookup) applied live as the user picks a brick category. */
    suspend fun rateFor(category: String): Double = setupRepository.rateFor(category)

    fun submit(input: SalesEntryInput, counterpartyName: String? = null) {
        _result.value = SalesEntryResult.Saving
        viewModelScope.launch {
            try {
                // Duplicate-voucher guard, mirrors the Audit Sheet's reconciliation intent.
                if (!input.voucherNo.isNullOrBlank()) {
                    val existing = salesRepository.findByVoucher(input.voucherNo)
                    if (existing != null) {
                        _result.value = SalesEntryResult.Error("Voucher '${input.voucherNo}' আগে থেকেই আছে (id=${existing.id})")
                        return@launch
                    }
                }
                val rows = EntryGuideEngine.buildSaleEntities(input, counterpartyName)
                rows.forEach { salesRepository.addSale(it) }
                _result.value = SalesEntryResult.Success(rows.size)
            } catch (e: Exception) {
                _result.value = SalesEntryResult.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun resetResult() { _result.value = SalesEntryResult.Idle }
}

class SalesEntryViewModelFactory(
    private val salesRepository: SalesRepository,
    private val setupRepository: SetupRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        SalesEntryViewModel(salesRepository, setupRepository) as T
}
