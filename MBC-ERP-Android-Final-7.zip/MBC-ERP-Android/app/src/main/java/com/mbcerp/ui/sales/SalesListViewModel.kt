package com.mbcerp.ui.sales

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.SaleEntity
import com.mbcerp.domain.calc.FormulaPatterns
import com.mbcerp.repository.SalesRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SalesListFilter(
    val query: String = "",       // matches voucherNo, partyName, truckNo
    val partyType: String? = null // null = all, else "Customer"/"Partner"
)

class SalesListViewModel(private val salesRepository: SalesRepository) : ViewModel() {

    private val _filter = MutableStateFlow(SalesListFilter())
    val filter: StateFlow<SalesListFilter> = _filter

    private val allSales: StateFlow<List<SaleEntity>> =
        salesRepository.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Filtered + search list, with the live "Due" computed on read (Pattern: never stored). */
    val visibleRows: StateFlow<List<SaleRow>> = combine(allSales, _filter) { rows, f ->
        rows.asSequence()
            .filter { f.partyType == null || it.partyType == f.partyType }
            .filter {
                f.query.isBlank() ||
                    it.voucherNo?.contains(f.query, ignoreCase = true) == true ||
                    it.partyName.contains(f.query, ignoreCase = true) ||
                    it.truckNo?.contains(f.query, ignoreCase = true) == true
            }
            .map { SaleRow(it, FormulaPatterns.salesDue(it.amount, it.advancePayment, it.cashReceived)) }
            .toList()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalAmount: StateFlow<Double> = visibleRows.map { rows -> rows.sumOf { it.sale.amount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun updateQuery(q: String) { _filter.value = _filter.value.copy(query = q) }
    fun updatePartyType(t: String?) { _filter.value = _filter.value.copy(partyType = t) }

    fun deleteSale(id: Long) { viewModelScope.launch { salesRepository.removeSale(id) } }

    /** Full edit flow (Phase-4 item 4, supersedes the Phase-1/2 add-only + soft-delete UI). */
    fun updateSale(sale: SaleEntity) { viewModelScope.launch { salesRepository.updateSale(sale) } }
}

data class SaleRow(val sale: SaleEntity, val due: Double)

class SalesListViewModelFactory(private val salesRepository: SalesRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = SalesListViewModel(salesRepository) as T
}
