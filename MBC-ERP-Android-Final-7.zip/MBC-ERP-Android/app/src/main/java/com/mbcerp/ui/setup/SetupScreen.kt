package com.mbcerp.ui.setup

import androidx.compose.ui.res.stringResource

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mbcerp.data.entity.*
import java.time.LocalDate

/**
 * SETUP SCREEN (Phase 1 item 3) — the Android equivalent of the Excel "Setup" sheet.
 * Tabs mirror the Setup sheet's blocks exactly (AUDIT §2.1): Company/Baseline, Partners,
 * Majhis, Brick Types & Rates, Equipment, Expense Categories, Customers.
 *
 * Each master-data tab reuses the same generic list+add-dialog pattern rather than a
 * bespoke screen per entity — six near-identical screens in the source spreadsheet
 * become one reusable Compose pattern here.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupScreen(vm: SetupViewModel) {
    val tabs = listOf("Company", "Partners", "Majhis", "Brick Types", "Equipment", "Expense Categories", "Customers")
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(topBar = { TopAppBar(title = { Text("Setup") }) }) { padding ->
        Column(Modifier.padding(padding)) {
            ScrollableTabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { i, title ->
                    Tab(selected = selectedTab == i, onClick = { selectedTab = i }, text = { Text(title) })
                }
            }
            when (selectedTab) {
                0 -> CompanyProfileTab(vm)
                1 -> PartnersTab(vm)
                2 -> MajhisTab(vm)
                3 -> BrickTypesTab(vm)
                4 -> EquipmentTab(vm)
                5 -> ExpenseCategoriesTab(vm)
                6 -> CustomersTab(vm)
            }
        }
    }
}

@Composable
fun CompanyProfileTab(vm: SetupViewModel) {
    val profile by vm.companyProfile.collectAsState()
    var baselineInput by remember(profile) { mutableStateOf(profile?.dueBaselineDate ?: "") }

    Column(Modifier.padding(16.dp).fillMaxWidth()) {
        Text("Company", style = MaterialTheme.typography.titleMedium)
        Text(profile?.name ?: "—")
        Text(profile?.season ?: "—")
        Spacer(Modifier.height(16.dp))

        Text("Due Baseline Date", style = MaterialTheme.typography.titleMedium)
        Text(
            "Only sales entered AFTER this date are counted on top of each customer/partner's " +
            "Opening Due. Everything up to and including this date is assumed already folded " +
            "into the Opening Due figure (mirrors Setup!B8 in the original workbook).",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = baselineInput,
                onValueChange = { baselineInput = it },
                label = { Text("YYYY-MM-DD") },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                runCatching { LocalDate.parse(baselineInput) }.onSuccess { vm.updateBaselineDate(it) }
            }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
        }

        Spacer(Modifier.height(16.dp))
        Text("Opening Capital: ${profile?.openingCapital ?: 0.0}")
        Text("Customer Opening Due Total: ${profile?.customerOpeningDueTotal ?: 0.0}")
    }
}

@Composable
fun PartnersTab(vm: SetupViewModel) {
    val list by vm.partners.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editingPartner by remember { mutableStateOf<PartnerEntity?>(null) }

    MasterListScaffold(
        title = "Partners (${list.size})",
        onAddClick = { showDialog = true }
    ) {
        items(list) { p ->
            ListItem(
                headlineContent = { Text(p.name) },
                supportingContent = { Text("Capital: ${p.capital}  |  Share: ${p.shareAnna}/16 Ana  |  Opening Due: ${p.openingDue}") },
                modifier = Modifier.clickable { editingPartner = p }
            )
            Divider()
        }
    }

    editingPartner?.let { p ->
        var name by remember(p) { mutableStateOf(p.name) }
        var capital by remember(p) { mutableStateOf(p.capital.toString()) }
        var anna by remember(p) { mutableStateOf(p.shareAnna.toString()) }
        var opening by remember(p) { mutableStateOf(p.openingDue.toString()) }
        var mobile by remember(p) { mutableStateOf(p.mobile ?: "") }
        AlertDialog(
            onDismissRequest = { editingPartner = null },
            title = { Text("Partner Edit করুন") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") })
                    OutlinedTextField(capital, { capital = it }, label = { Text("Capital") })
                    OutlinedTextField(anna, { anna = it }, label = { Text("Share (Anna, out of 16)") })
                    OutlinedTextField(opening, { opening = it }, label = { Text("Opening Due") })
                    OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updatePartner(p.copy(name = name, capital = capital.toDoubleOrNull() ?: 0.0, shareAnna = anna.toDoubleOrNull() ?: 0.0, openingDue = opening.toDoubleOrNull() ?: 0.0, mobile = mobile.ifBlank { null }))
                    editingPartner = null
                }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { editingPartner = null }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }

    if (showDialog) {
        var name by remember { mutableStateOf("") }
        var capital by remember { mutableStateOf("0") }
        var anna by remember { mutableStateOf("0") }
        var opening by remember { mutableStateOf("0") }
        var mobile by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Add Partner") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") })
                    OutlinedTextField(capital, { capital = it }, label = { Text("Capital") })
                    OutlinedTextField(anna, { anna = it }, label = { Text("Share (Anna, out of 16)") })
                    OutlinedTextField(opening, { opening = it }, label = { Text("Opening Due") })
                    OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addPartner(name, capital.toDoubleOrNull() ?: 0.0, anna.toDoubleOrNull() ?: 0.0, opening.toDoubleOrNull() ?: 0.0, mobile.ifBlank { null })
                    showDialog = false
                }) { Text(stringResource(com.mbcerp.R.string.action_add)) }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}

@Composable
fun MajhisTab(vm: SetupViewModel) {
    val list by vm.majhis.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editingMajhi by remember { mutableStateOf<MajhiEntity?>(null) }
    MasterListScaffold(title = "Majhis (${list.size})", onAddClick = { showDialog = true }) {
        items(list) { m ->
            ListItem(headlineContent = { Text(m.name) }, modifier = Modifier.clickable { editingMajhi = m })
            Divider()
        }
    }
    editingMajhi?.let { m ->
        var name by remember(m) { mutableStateOf(m.name) }
        AlertDialog(
            onDismissRequest = { editingMajhi = null },
            title = { Text("Majhi Edit করুন") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Name") }) },
            confirmButton = { TextButton(onClick = { vm.updateMajhi(m.copy(name = name)); editingMajhi = null }) { Text(stringResource(com.mbcerp.R.string.action_save)) } },
            dismissButton = { TextButton(onClick = { editingMajhi = null }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
    if (showDialog) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Add Majhi") },
            text = { OutlinedTextField(name, { name = it }, label = { Text("Name") }) },
            confirmButton = { TextButton(onClick = { vm.addMajhi(name); showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_add)) } },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}

@Composable
fun BrickTypesTab(vm: SetupViewModel) {
    val list by vm.brickTypes.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editingBrickType by remember { mutableStateOf<BrickTypeEntity?>(null) }
    MasterListScaffold(title = "Brick Types & Rates (${list.size})", onAddClick = { showDialog = true }) {
        items(list) { b ->
            ListItem(
                headlineContent = { Text(b.category) },
                supportingContent = { Text("Rate: ${b.rate}  Unit: ${b.unitDescription ?: "-"}") },
                modifier = Modifier.clickable { editingBrickType = b }
            )
            Divider()
        }
    }
    editingBrickType?.let { b ->
        var category by remember(b) { mutableStateOf(b.category) }
        var rate by remember(b) { mutableStateOf(b.rate.toString()) }
        var unitDesc by remember(b) { mutableStateOf(b.unitDescription ?: "") }
        AlertDialog(
            onDismissRequest = { editingBrickType = null },
            title = { Text("Brick Type Edit করুন") },
            text = {
                Column {
                    Text(
                        "নোট: এই Rate পরিবর্তন করলে ভবিষ্যতের নতুন বিক্রয় এন্ট্রিতে auto-lookup হবে (Pattern 1) — " +
                        "আগে যোগ হওয়া পুরনো বিক্রয়ের rate বদলাবে না।",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(category, { category = it }, label = { Text("Category") })
                    OutlinedTextField(rate, { rate = it }, label = { Text("Rate") })
                    OutlinedTextField(unitDesc, { unitDesc = it }, label = { Text("Unit Description") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updateBrickType(b.copy(category = category, rate = rate.toDoubleOrNull() ?: 0.0, unitDescription = unitDesc.ifBlank { null }))
                    editingBrickType = null
                }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { editingBrickType = null }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
    if (showDialog) {
        var category by remember { mutableStateOf("") }
        var rate by remember { mutableStateOf("0") }
        var unitDesc by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Add Brick Type") },
            text = {
                Column {
                    OutlinedTextField(category, { category = it }, label = { Text("Category") })
                    OutlinedTextField(rate, { rate = it }, label = { Text("Rate") })
                    OutlinedTextField(unitDesc, { unitDesc = it }, label = { Text("Unit Description") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addBrickType(category, rate.toDoubleOrNull() ?: 0.0, null, unitDesc.ifBlank { null })
                    showDialog = false
                }) { Text(stringResource(com.mbcerp.R.string.action_add)) }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}

@Composable
fun EquipmentTab(vm: SetupViewModel) {
    val list by vm.equipment.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editingEquipment by remember { mutableStateOf<EquipmentEntity?>(null) }
    MasterListScaffold(title = "Equipment (${list.size})", onAddClick = { showDialog = true }) {
        items(list) { e ->
            ListItem(
                headlineContent = { Text(e.name) },
                supportingContent = { Text("${e.type}  |  Rate/hr: ${e.hourlyRate}  |  Driver: ${e.driverName ?: "-"}") },
                modifier = Modifier.clickable { editingEquipment = e }
            )
            Divider()
        }
    }
    editingEquipment?.let { e ->
        var name by remember(e) { mutableStateOf(e.name) }
        var type by remember(e) { mutableStateOf(e.type) }
        var rate by remember(e) { mutableStateOf(e.hourlyRate.toString()) }
        var driver by remember(e) { mutableStateOf(e.driverName ?: "") }
        AlertDialog(
            onDismissRequest = { editingEquipment = null },
            title = { Text("Equipment Edit করুন") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") })
                    OutlinedTextField(type, { type = it }, label = { Text("Type (Excavator / Drum Truck)") })
                    OutlinedTextField(rate, { rate = it }, label = { Text("Hourly Rate") })
                    OutlinedTextField(driver, { driver = it }, label = { Text("Driver") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updateEquipment(e.copy(name = name, type = type, hourlyRate = rate.toDoubleOrNull() ?: 0.0, driverName = driver.ifBlank { null }))
                    editingEquipment = null
                }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { editingEquipment = null }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
    if (showDialog) {
        var name by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("Excavator") }
        var rate by remember { mutableStateOf("0") }
        var driver by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Add Equipment") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") })
                    OutlinedTextField(type, { type = it }, label = { Text("Type (Excavator / Drum Truck)") })
                    OutlinedTextField(rate, { rate = it }, label = { Text("Hourly Rate") })
                    OutlinedTextField(driver, { driver = it }, label = { Text("Driver") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addEquipment(name, type, rate.toDoubleOrNull() ?: 0.0, driver.ifBlank { null })
                    showDialog = false
                }) { Text(stringResource(com.mbcerp.R.string.action_add)) }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}

@Composable
fun ExpenseCategoriesTab(vm: SetupViewModel) {
    val list by vm.expenseCategories.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editingCategory by remember { mutableStateOf<ExpenseCategoryEntity?>(null) }
    MasterListScaffold(title = "Expense Categories (${list.size})", onAddClick = { showDialog = true }) {
        items(list) { c ->
            ListItem(headlineContent = { Text(c.category) }, modifier = Modifier.clickable { editingCategory = c })
            Divider()
        }
    }
    editingCategory?.let { c ->
        var category by remember(c) { mutableStateOf(c.category) }
        AlertDialog(
            onDismissRequest = { editingCategory = null },
            title = { Text("Category Edit করুন") },
            text = {
                Column {
                    Text(
                        "নোট: নাম পরিবর্তন করলে পুরনো Expense Register এন্ট্রি এই নতুন নামের সাথে মেলে না " +
                        "(ওগুলো পুরনো নাম ধরেই থাকবে, category-filter screen-এ আলাদা দেখাবে)।",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(category, { category = it }, label = { Text("Category") })
                }
            },
            confirmButton = { TextButton(onClick = { vm.updateExpenseCategory(c.copy(category = category)); editingCategory = null }) { Text(stringResource(com.mbcerp.R.string.action_save)) } },
            dismissButton = { TextButton(onClick = { editingCategory = null }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
    if (showDialog) {
        var category by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Add Expense Category") },
            text = { OutlinedTextField(category, { category = it }, label = { Text("Category") }) },
            confirmButton = { TextButton(onClick = { vm.addExpenseCategory(category); showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_add)) } },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}

@Composable
fun CustomersTab(vm: SetupViewModel) {
    val list by vm.customers.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editingCustomer by remember { mutableStateOf<CustomerEntity?>(null) }
    MasterListScaffold(title = "Customers (${list.size})", onAddClick = { showDialog = true }) {
        items(list) { c ->
            ListItem(
                headlineContent = { Text(c.name) },
                supportingContent = { Text("Opening Due: ${c.openingDue}  |  Mobile: ${c.mobile ?: "-"}") },
                modifier = Modifier.clickable { editingCustomer = c }
            )
            Divider()
        }
    }
    editingCustomer?.let { c ->
        var name by remember(c) { mutableStateOf(c.name) }
        var opening by remember(c) { mutableStateOf(c.openingDue.toString()) }
        var mobile by remember(c) { mutableStateOf(c.mobile ?: "") }
        AlertDialog(
            onDismissRequest = { editingCustomer = null },
            title = { Text("Customer Edit করুন") },
            text = {
                Column {
                    Text(
                        "নোট: এই Opening Due-ই 'All-Customer-List' পর্দার বকেয়া নির্ধারণ করে (D-quirk-1 " +
                        "দেখুন DECISIONS.md-এ) -- ভুল থাকলে এখানে ঠিক করুন।",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(name, { name = it }, label = { Text("Name") })
                    OutlinedTextField(opening, { opening = it }, label = { Text("Opening Due") })
                    OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updateCustomer(c.copy(name = name, openingDue = opening.toDoubleOrNull() ?: 0.0, mobile = mobile.ifBlank { null }))
                    editingCustomer = null
                }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { editingCustomer = null }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
    if (showDialog) {
        var name by remember { mutableStateOf("") }
        var opening by remember { mutableStateOf("0") }
        var mobile by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Add Customer") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") })
                    OutlinedTextField(opening, { opening = it }, label = { Text("Opening Due") })
                    OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addCustomer(name, opening.toDoubleOrNull() ?: 0.0, mobile.ifBlank { null })
                    showDialog = false
                }) { Text(stringResource(com.mbcerp.R.string.action_add)) }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}

@Composable
private fun MasterListScaffold(
    title: String,
    onAddClick: () -> Unit,
    content: LazyColumnScopeContent
) {
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(8.dp))
            IconButton(onClick = onAddClick) { Icon(Icons.Default.Add, contentDescription = "Add") }
        }
        LazyColumn(Modifier.fillMaxSize()) { content() }
    }
}

private typealias LazyColumnScopeContent = androidx.compose.foundation.lazy.LazyListScope.() -> Unit
