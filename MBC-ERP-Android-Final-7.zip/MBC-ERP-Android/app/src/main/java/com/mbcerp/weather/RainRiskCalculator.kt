package com.mbcerp.weather

/**
 * WEATHER ALERT (item 5) -- pure, framework-free rain-risk calculation. This is the
 * one part of the Weather Alert feature that is genuinely unit-testable in this
 * sandbox (no network/Android runtime needed) -- see WeatherTest.kt.
 *
 * Business purpose: an open-air brickfield's raw brick stock and drying bricks are
 * destroyed by unexpected rain. This calculator turns a raw hourly forecast into a
 * single actionable risk level + lead time, so the app can notify the manager with
 * enough advance warning to cover stock / stop kiln loading.
 */
object RainRiskCalculator {

    enum class RiskLevel { NONE, LOW, MODERATE, HIGH, SEVERE }

    data class HourlyForecastPoint(
        val hoursFromNow: Int,
        val precipitationProbabilityPercent: Int, // 0-100
        val precipitationMm: Double                // expected mm in that hour
    )

    data class Thresholds(
        /** Minimum probability% to count an hour as "rain expected" at all. */
        val probabilityThresholdPercent: Int = 40,
        /** mm/hour at or above which a rain hour is escalated to HIGH regardless of probability. */
        val heavyRainMm: Double = 7.5,
        /** How many hours ahead to scan (the "lead time" window the user cares about). */
        val leadTimeHours: Int = 12
    )

    data class RiskAssessment(
        val level: RiskLevel,
        val firstRiskyHourFromNow: Int?, // null if no risk found within the lead-time window
        val maxProbabilityPercent: Int,
        val maxPrecipitationMm: Double,
        val reason: String
    )

    /**
     * Scans the forecast within [Thresholds.leadTimeHours] and returns the worst risk found.
     * Deterministic pure function -- given the same forecast + thresholds it always returns
     * the same assessment, which is what makes it unit-testable without a live API call.
     */
    fun assess(forecast: List<HourlyForecastPoint>, thresholds: Thresholds = Thresholds()): RiskAssessment {
        val withinWindow = forecast.filter { it.hoursFromNow in 0..thresholds.leadTimeHours }
        if (withinWindow.isEmpty()) {
            return RiskAssessment(RiskLevel.NONE, null, 0, 0.0, "কোনো forecast ডেটা পাওয়া যায়নি")
        }

        val risky = withinWindow.filter { it.precipitationProbabilityPercent >= thresholds.probabilityThresholdPercent }
        if (risky.isEmpty()) {
            return RiskAssessment(
                RiskLevel.NONE, null,
                withinWindow.maxOf { it.precipitationProbabilityPercent },
                withinWindow.maxOf { it.precipitationMm },
                "আগামী ${thresholds.leadTimeHours} ঘণ্টায় উল্লেখযোগ্য বৃষ্টির সম্ভাবনা নেই"
            )
        }

        val firstRisky = risky.minBy { it.hoursFromNow }
        val maxProb = risky.maxOf { it.precipitationProbabilityPercent }
        val maxMm = risky.maxOf { it.precipitationMm }
        val hasHeavy = risky.any { it.precipitationMm >= thresholds.heavyRainMm }

        val level = when {
            hasHeavy -> RiskLevel.SEVERE
            maxProb >= 80 -> RiskLevel.HIGH
            maxProb >= 60 -> RiskLevel.MODERATE
            else -> RiskLevel.LOW
        }

        val reason = when (level) {
            RiskLevel.SEVERE -> "প্রবল বৃষ্টির পূর্বাভাস (${"%.1f".format(maxMm)}mm/ঘণ্টা) — এখনই কাঁচা ইট/মাল ঢেকে রাখুন"
            RiskLevel.HIGH -> "বৃষ্টির সম্ভাবনা খুব বেশি ($maxProb%) — ${firstRisky.hoursFromNow} ঘণ্টার মধ্যে"
            RiskLevel.MODERATE -> "বৃষ্টির মাঝারি সম্ভাবনা ($maxProb%) — ${firstRisky.hoursFromNow} ঘণ্টার মধ্যে"
            else -> "সামান্য বৃষ্টির সম্ভাবনা ($maxProb%)"
        }

        return RiskAssessment(level, firstRisky.hoursFromNow, maxProb, maxMm, reason)
    }

    /** Whether this risk level is worth waking someone up with a notification for. */
    fun shouldNotify(level: RiskLevel): Boolean = level == RiskLevel.MODERATE || level == RiskLevel.HIGH || level == RiskLevel.SEVERE
}
