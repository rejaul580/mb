package com.mbcerp.weather

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WeatherDao {
    @Query("SELECT * FROM weather_cache WHERE id = 1")
    suspend fun getCache(): WeatherCacheEntity?

    @Query("SELECT * FROM weather_cache WHERE id = 1")
    fun observeCache(): Flow<WeatherCacheEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCache(cache: WeatherCacheEntity)

    @Query("SELECT * FROM weather_alert_settings WHERE id = 1")
    suspend fun getSettings(): WeatherAlertSettingsEntity?

    @Query("SELECT * FROM weather_alert_settings WHERE id = 1")
    fun observeSettings(): Flow<WeatherAlertSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: WeatherAlertSettingsEntity)
}
