package com.mbcerp.weather

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Offline cache of the last successful forecast fetch, so the app has *something*
 *  to show (with a staleness warning) when the device has no signal. */
@Entity(tableName = "weather_cache")
data class WeatherCacheEntity(
    @PrimaryKey val id: Int = 1, // singleton row
    val fetchedAtMillis: Long,
    val latitude: Double,
    val longitude: Double,
    /** JSON-encoded List<HourlyForecastPoint>, kept as raw JSON to avoid a second table. */
    val forecastJson: String
)

@Entity(tableName = "weather_alert_settings")
data class WeatherAlertSettingsEntity(
    @PrimaryKey val id: Int = 1, // singleton row
    val enabled: Boolean = false,
    val latitude: Double = 22.3569,  // default: Chattogram, Bangladesh (brickfields commonly there)
    val longitude: Double = 91.7832,
    val probabilityThresholdPercent: Int = 40,
    val heavyRainMm: Double = 7.5,
    val leadTimeHours: Int = 12,
    val checkIntervalMinutes: Int = 60,
    /** Duplicate-alert prevention: don't re-notify for the same risk window within this many minutes. */
    val minMinutesBetweenAlerts: Int = 180,
    val lastAlertAtMillis: Long = 0L,
    val lastAlertedHourBucket: Int = -1 // the firstRiskyHourFromNow value last alerted on, rounded to a bucket
)
