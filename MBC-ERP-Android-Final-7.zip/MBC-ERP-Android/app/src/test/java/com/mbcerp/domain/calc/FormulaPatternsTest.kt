package com.mbcerp.domain.calc

import com.mbcerp.data.entity.SaleEntity
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

/**
 * These tests mirror /validation/src/Validate.java, which was run against the FULL
 * 3,802-row Sales Register and 1,547-row Expense Register (plus ALL 393 customers and
 * all 13 partners individually, not just a sample) extracted from the source Excel
 * file, and matched its cached formula results exactly (458/458 checks passed after
 * the D-quirk-1 fix -- see VALIDATION_REPORT.md).
 */
class FormulaPatternsTest {

    private fun sale(
        date: String, partyType: String, partyName: String,
        amount: Double, advance: Double = 0.0, cash: Double = 0.0,
        saleType: String? = null
    ) = SaleEntity(
        date = date, partyType = partyType, partyName = partyName,
        brickCategory = "1 No", amount = amount, advancePayment = advance, cashReceived = cash,
        saleType = saleType
    )

    @Test
    fun `salesDue equals amount minus advance minus cash - Sales Register column N`() {
        assertEquals(500.0, FormulaPatterns.salesDue(amount = 1000.0, advance = 300.0, cashReceived = 200.0), 0.001)
    }

    @Test
    fun `lookupRate returns 0 for unknown brick category - mirrors IFERROR fallback`() {
        assertEquals(0.0, FormulaPatterns.lookupRate("Unknown Category", mapOf("1 No" to 9.5)), 0.001)
    }

    @Test
    fun `lookupRate returns configured rate for known brick category`() {
        assertEquals(9.5, FormulaPatterns.lookupRate("1 No", mapOf("1 No" to 9.5)), 0.001)
    }

    @Test
    fun `calcDue excludes sales on or before the baseline date - Partner formula`() {
        val baseline = LocalDate.parse("2026-07-14")
        val sales = listOf(
            sale("2026-07-14", "Partner", "Karim", amount = 10000.0), // ON baseline -> excluded
            sale("2026-07-15", "Partner", "Karim", amount = 5000.0),  // AFTER baseline -> included
        )
        val due = FormulaPatterns.calcDue(sales, "Partner", "Karim", openingDue = 1000.0, baselineDate = baseline, extraPaymentTotal = 0.0)
        assertEquals(6000.0, due, 0.001)
    }

    @Test
    fun `calcDue subtracts advance, cash and extra payments`() {
        val baseline = LocalDate.parse("2026-07-14")
        val sales = listOf(
            sale("2026-08-01", "Partner", "Karim", amount = 20000.0, advance = 5000.0, cash = 3000.0)
        )
        val due = FormulaPatterns.calcDue(sales, "Partner", "Karim", openingDue = 0.0, baselineDate = baseline, extraPaymentTotal = 2000.0)
        assertEquals(10000.0, due, 0.001)
    }

    @Test
    fun `runningBalances accumulates advance+cash-amount per row - Ledger column P`() {
        val rows = listOf(
            sale("2026-08-01", "Customer", "X", amount = 1000.0, cash = 400.0),
            sale("2026-08-02", "Customer", "X", amount = 500.0, advance = 200.0)
        )
        val balances = FormulaPatterns.runningBalances(rows)
        assertEquals(-600.0, balances[0], 0.001)
        assertEquals(-900.0, balances[1], 0.001)
    }

    @Test
    fun `validateSalesRow flags missing voucher number`() {
        val row = sale("2026-08-01", "Customer", "X", amount = 100.0).copy(voucherNo = null)
        assertEquals("Voucher Number Missing", FormulaPatterns.validateSalesRow(row))
    }

    @Test
    fun `validateSalesRow returns null for a clean row`() {
        val row = sale("2026-08-01", "Customer", "X", amount = 100.0).copy(voucherNo = "V-1", quantity = 100.0, rate = 9.5)
        assertEquals(null, FormulaPatterns.validateSalesRow(row))
    }

    @Test
    fun `filterSalesByParty matches case-insensitively - mirrors Excel SUMIFS text comparison`() {
        // Real finding from the source file: Customer Ledger!B3 was saved as "faici driver"
        // (lowercase) and correctly matched "FAICI DRIVER" rows in Sales Register -- Excel's
        // SUMIFS/MATCH text comparison is case-insensitive. Kotlin String equality and
        // SQLite's default TEXT comparison are both case-SENSITIVE, so this had to be fixed
        // explicitly (see also COLLATE NOCASE added to the Room @Query definitions).
        val rows = listOf(sale("2026-08-01", "Customer", "FAICI DRIVER", amount = 1000.0))
        val matched = FormulaPatterns.filterSalesByParty(rows, "customer", "faici driver")
        assertEquals(1, matched.size)
    }

    @Test
    fun `filterExpensesByCategory matches case-insensitively`() {
        val rows = listOf(
            com.mbcerp.data.entity.ExpenseEntity(date = "2026-08-01", category = "Diesel", amount = 500.0)
        )
        val matched = FormulaPatterns.filterExpensesByCategory(rows, "DIESEL")
        assertEquals(1, matched.size)
    }
}

class DueCalculatorTest {

    private fun sale(date: String, partyType: String, partyName: String, amount: Double, advance: Double = 0.0, cash: Double = 0.0) =
        SaleEntity(date = date, partyType = partyType, partyName = partyName, brickCategory = "1 No", amount = amount, advancePayment = advance, cashReceived = cash)

    @Test
    fun `partnerDue uses one consistent baseline-aware formula`() {
        val baseline = LocalDate.parse("2026-07-14")
        val sales = listOf(sale("2026-08-01", "Partner", "Karim", amount = 5000.0, cash = 1000.0))
        val summary = DueCalculator.partnerDue(sales, "Karim", openingDue = 500.0, baselineDate = baseline, extraPaymentTotal = 0.0)
        assertEquals(4500.0, summary.totalDue, 0.001) // 500 + 5000 - 0 - 1000 - 0
        assertEquals(5000.0, summary.totalSales, 0.001)
        assertEquals(1000.0, summary.receivedAtSaleAllTime, 0.001)
    }

    @Test
    fun `customerDue detail-screen formula ignores opening due and baseline date entirely`() {
        // D-quirk-1: detail screen = totalSales - receivedAtSale(all-time) - extraPayment.
        // Verified against real source data (MOHAMMAD ALI): 2 post-baseline sales rows,
        // amount 169200 total, cash received 169100 total -> due 100, no opening-due term.
        val sales = listOf(
            sale("2026-08-01", "Customer", "Test", amount = 84600.0, cash = 84600.0),
            sale("2026-08-02", "Customer", "Test", amount = 84600.0, cash = 84500.0)
        )
        val summary = DueCalculator.customerDue(sales, "Test", openingDue = 100.0, extraPaymentTotal = 0.0)
        assertEquals(169200.0, summary.totalSalesAllTime, 0.001)
        assertEquals(169100.0, summary.receivedAtSaleAllTime, 0.001)
        assertEquals(100.0, summary.totalDueDetailScreen, 0.001) // 169200 - 169100 - 0
    }

    @Test
    fun `customerDue all-list formula ignores Sales Register activity entirely`() {
        // D-quirk-1: all-list screen = openingDue - extraPayment ONLY -- even large unpaid
        // sales activity does not change this figure. This is a genuine source-file quirk,
        // reproduced verbatim (not "fixed").
        val sales = listOf(
            sale("2026-08-01", "Customer", "Test", amount = 500000.0, cash = 0.0) // huge unpaid sale
        )
        val summary = DueCalculator.customerDue(sales, "Test", openingDue = 3000.0, extraPaymentTotal = 500.0)
        assertEquals(2500.0, summary.totalDueAllListScreen, 0.001) // 3000 - 500, sale ignored
        assertEquals(true, summary.formulasDisagree) // detail screen would show a much larger due
    }

    @Test
    fun `formulasDisagree is false when the two customer formulas happen to agree`() {
        // Typical case (389 of 393 real customers): customer fully settled at sale time,
        // so post-sale unpaid balance is ~0 and both formulas coincide.
        val sales = listOf(sale("2026-08-01", "Customer", "Test", amount = 1000.0, cash = 1000.0))
        val summary = DueCalculator.customerDue(sales, "Test", openingDue = 0.0, extraPaymentTotal = 0.0)
        assertEquals(0.0, summary.totalDueDetailScreen, 0.001)
        assertEquals(0.0, summary.totalDueAllListScreen, 0.001)
        assertEquals(false, summary.formulasDisagree)
    }
}
