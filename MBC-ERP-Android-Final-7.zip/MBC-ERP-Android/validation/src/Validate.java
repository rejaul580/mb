import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.*;

/**
 * Standalone validation harness (pure Java, no external libs).
 * Re-implements the core calculation-engine formulas (mirrors the Kotlin
 * domain layer shipped in the Android app) and checks results against
 * expected_ground_truth.json (values read directly from the Excel file's
 * cached formula results via openpyxl/data_only=True).
 *
 * This proves the reimplemented business logic produces numbers that match
 * the original spreadsheet, independent of the Android/Gradle toolchain
 * (which cannot be executed in this sandbox - no network for Gradle/AGP).
 */
public class Validate {

    // ---------- tiny hand-rolled JSON reader (no external deps) ----------
    static Object parseJson(String s) { return new JsonParser(s).parseValue(); }

    static class JsonParser {
        String s; int i = 0;
        JsonParser(String s) { this.s = s; }
        void skipWs() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        Object parseValue() {
            skipWs();
            char c = s.charAt(i);
            if (c == '{') return parseObj();
            if (c == '[') return parseArr();
            if (c == '"') return parseStr();
            if (s.startsWith("null", i)) { i += 4; return null; }
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            return parseNum();
        }
        Map<String,Object> parseObj() {
            LinkedHashMap<String,Object> m = new LinkedHashMap<>();
            i++; skipWs();
            if (s.charAt(i) == '}') { i++; return m; }
            while (true) {
                skipWs();
                String k = parseStr();
                skipWs(); i++; // ':'
                Object v = parseValue();
                m.put(k, v);
                skipWs();
                if (s.charAt(i) == ',') { i++; continue; }
                if (s.charAt(i) == '}') { i++; break; }
            }
            return m;
        }
        List<Object> parseArr() {
            List<Object> l = new ArrayList<>();
            i++; skipWs();
            if (s.charAt(i) == ']') { i++; return l; }
            while (true) {
                l.add(parseValue());
                skipWs();
                if (s.charAt(i) == ',') { i++; continue; }
                if (s.charAt(i) == ']') { i++; break; }
            }
            return l;
        }
        String parseStr() {
            StringBuilder sb = new StringBuilder();
            i++; // opening quote
            while (s.charAt(i) != '"') {
                char c = s.charAt(i);
                if (c == '\\') {
                    i++;
                    char e = s.charAt(i);
                    switch (e) {
                        case 'n': sb.append('\n'); break;
                        case 't': sb.append('\t'); break;
                        case 'r': sb.append('\r'); break;
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        case '/': sb.append('/'); break;
                        case 'u':
                            String hex = s.substring(i+1, i+5);
                            sb.append((char) Integer.parseInt(hex, 16));
                            i += 4;
                            break;
                        default: sb.append(e);
                    }
                    i++;
                } else {
                    sb.append(c); i++;
                }
            }
            i++; // closing quote
            return sb.toString();
        }
        Double parseNum() {
            int start = i;
            while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i)=='-' || s.charAt(i)=='+' || s.charAt(i)=='.' || s.charAt(i)=='e' || s.charAt(i)=='E')) i++;
            return Double.parseDouble(s.substring(start, i));
        }
    }

    @SuppressWarnings("unchecked")
    static List<Map<String,Object>> asListOfMaps(Object o) { return (List<Map<String,Object>>)(List<?>) o; }
    @SuppressWarnings("unchecked")
    static Map<String,Object> asMap(Object o) { return (Map<String,Object>) o; }

    static double num(Object o) {
        if (o == null) return 0.0;
        if (o instanceof Double) return (Double) o;
        if (o instanceof String) {
            String s = ((String) o).trim();
            if (s.isEmpty()) return 0.0;
            try { return Double.parseDouble(s); } catch (Exception e) { return 0.0; }
        }
        return 0.0;
    }
    static String str(Object o) { return o == null ? "" : o.toString(); }

    static LocalDate dateOf(Object o) {
        String s = str(o);
        if (s.isEmpty()) return null;
        try { return LocalDate.parse(s, DateTimeFormatter.ISO_LOCAL_DATE); }
        catch (Exception e) { return null; }
    }

    // ================= DOMAIN CALCULATION ENGINE (mirrors Kotlin) =================

    /** Pattern 5: baseline-date-aware Due calculation, used for both Customer & Partner. */
    static double calcDue(List<Map<String,Object>> sales, String partyType, String partyName,
                           double openingDue, LocalDate baseline, double extraPayment) {
        double sumAmount = 0, sumAdvance = 0, sumCash = 0;
        for (Map<String,Object> row : sales) {
            if (!partyType.equals(str(row.get("party_type")))) continue;
            if (!partyName.equals(str(row.get("party_name")))) continue;
            LocalDate d = dateOf(row.get("date"));
            if (d == null || !d.isAfter(baseline)) continue; // Excel: Date > BaselineDate (strict)
            sumAmount += num(row.get("amount"));
            sumAdvance += num(row.get("advance_payment"));
            sumCash += num(row.get("cash_received"));
        }
        return openingDue + sumAmount - sumAdvance - sumCash - extraPayment;
    }

    static double totalSalesFor(List<Map<String,Object>> sales, String partyType, String partyName) {
        double sum = 0;
        for (Map<String,Object> row : sales) {
            if (!partyType.equals(str(row.get("party_type")))) continue;
            if (!partyName.equals(str(row.get("party_name")))) continue;
            sum += num(row.get("amount"));
        }
        return sum;
    }

    static double receivedAtSaleFor(List<Map<String,Object>> sales, String partyType, String partyName) {
        double sum = 0;
        for (Map<String,Object> row : sales) {
            if (!partyType.equals(str(row.get("party_type")))) continue;
            if (!partyName.equals(str(row.get("party_name")))) continue;
            sum += num(row.get("advance_payment")) + num(row.get("cash_received"));
        }
        return sum;
    }

    static double sumField(List<Map<String,Object>> rows, String field) {
        double s = 0; for (Map<String,Object> r : rows) s += num(r.get(field)); return s;
    }

    static double sumIfCategory(List<Map<String,Object>> expenses, String field, Set<String> categories) {
        double s = 0;
        for (Map<String,Object> r : expenses) if (categories.contains(str(r.get("category")))) s += num(r.get(field));
        return s;
    }

    // ================= TEST RUNNER =================
    static int pass = 0, fail = 0;
    static List<String> failures = new ArrayList<>();

    static void check(String label, double actual, double expected, double tolerance) {
        double diff = Math.abs(actual - expected);
        if (diff <= tolerance) {
            pass++;
            System.out.printf("  PASS  %-55s actual=%,.2f expected=%,.2f%n", label, actual, expected);
        } else {
            fail++;
            String msg = String.format("  FAIL  %-55s actual=%,.2f expected=%,.2f diff=%,.2f", label, actual, expected, diff);
            System.out.println(msg);
            failures.add(label + " -> " + msg.trim());
        }
    }

    public static void main(String[] args) throws Exception {
        String base = "data/";
        List<Map<String,Object>> sales = asListOfMaps(parseJson(readFile(base + "sales_register.json")));
        List<Map<String,Object>> expenses = asListOfMaps(parseJson(readFile(base + "expense_register.json")));
        Map<String,Object> setup = asMap(parseJson(readFile(base + "setup_master.json")));
        Map<String,Object> expected = asMap(parseJson(readFile(base + "expected_ground_truth.json")));

        System.out.println("Loaded: sales=" + sales.size() + " expenses=" + expenses.size());

        LocalDate baseline = LocalDate.parse("2026-07-14");

        // ---------- 1. TOTAL SALES / TOTAL EXPENSE ----------
        System.out.println("\n== Section A: Grand totals ==");
        double totalSales = sumField(sales, "amount");
        double totalExpense = sumField(expenses, "amount");
        Map<String,Object> dash = asMap(expected.get("dashboard"));
        check("Total Sales (SUM Sales.Amount)", totalSales, num(dash.get("total_sales_amount")), 0.01);
        check("Total Expense (SUM Expense.Amount)", totalExpense, num(dash.get("total_expense_amount")), 0.01);
        double totalBricksSold = sumField(sales, "quantity");
        check("Total Bricks Sold (Qty)", totalBricksSold, num(dash.get("total_bricks_sold_qty")), 0.01);

        double totalAdvanceSale = 0, totalRegularSale;
        for (Map<String,Object> r : sales) if ("Advance Sale".equals(str(r.get("sale_type")))) totalAdvanceSale += num(r.get("amount"));
        totalRegularSale = totalSales - totalAdvanceSale;
        check("Total Advance Sale (Forward)", totalAdvanceSale, num(dash.get("total_advance_sale")), 0.01);
        check("Total Regular Sale", totalRegularSale, num(dash.get("total_regular_sale")), 0.01);

        // ---------- 2. PARTNER DUE (Pattern 5, baseline-date aware) ----------
        System.out.println("\n== Section B: Partner Due (per partner, baseline-date-aware formula) ==");
        List<Map<String,Object>> partners = asListOfMaps(setup.get("partners"));
        List<Map<String,Object>> expectedPartnerDue = asListOfMaps(expected.get("partner_due_summary"));
        Map<String,Double> expectedDueByPartner = new HashMap<>();
        for (Map<String,Object> p : expectedPartnerDue) expectedDueByPartner.put(str(p.get("partner")), num(p.get("total_due")));

        double totalPartnerDue = 0;
        for (Map<String,Object> p : partners) {
            String name = str(p.get("name"));
            double openingDue = num(p.get("opening_due"));
            double due = calcDue(sales, "Partner", name, openingDue, baseline, 0.0);
            totalPartnerDue += due;
            if (expectedDueByPartner.containsKey(name)) {
                check("Partner Due: " + name, due, expectedDueByPartner.get(name), 0.01);
            }
        }
        check("Total Partner Due (sum of all partner dues)", totalPartnerDue, num(dash.get("total_partner_due")), 0.5);

        // ---------- 3. CASH WATERFALL (Cash Summary engine) ----------
        System.out.println("\n== Section C: Cash Waterfall (Cash Summary sheet) ==");
        Map<String,Object> csExpected = asMap(expected.get("cash_summary"));
        double openingCapital = num(dash.get("total_capital"));
        double seasonFixedAdjustment = 10500.0; // migrated as configurable value, see DECISIONS.md
        double totalSalesAndCapital = totalSales + openingCapital + seasonFixedAdjustment;
        check("Cash Summary B5 (Sales+Capital+Adj)", totalSalesAndCapital, num(csExpected.get("total_sales_and_capital_B5")), 0.5);

        double advanceExpenseNextYear = num(csExpected.get("advance_expense_next_year_B7")); // manual input, carried over
        double coalDeposit = num(csExpected.get("coal_deposit_B8"));                          // manual input
        double priorYearDueReturn = num(csExpected.get("prior_year_due_return_B9"));          // manual input
        double currentCash = totalSalesAndCapital - totalExpense - advanceExpenseNextYear - coalDeposit + priorYearDueReturn;
        check("Cash Summary B10 (Current Cash before due)", currentCash, num(csExpected.get("current_cash_B10")), 0.5);

        // Customer due (whole-company total, baseline-aware, Setup opening due total used directly)
        double customerOpeningDueTotal = num(setup.get("company_profile") == null ? 0 :
                asMap(setup.get("company_profile")).get("customer_opening_due_total"));
        double custSum = 0, custAdv = 0, custCash = 0;
        for (Map<String,Object> r : sales) {
            if (!"Customer".equals(str(r.get("party_type")))) continue;
            LocalDate d = dateOf(r.get("date"));
            if (d == null || !d.isAfter(baseline)) continue;
            custSum += num(r.get("amount"));
            custAdv += num(r.get("advance_payment"));
            custCash += num(r.get("cash_received"));
        }
        double customerDueTotal = customerOpeningDueTotal + custSum - custAdv - custCash;
        check("Cash Summary B12 (Total Customer Due)", customerDueTotal, num(csExpected.get("customer_due_B12")), 0.5);

        double oldDueStartPool = num(csExpected.get("old_due_starting_pool_B61"));      // manual constant
        double oldDueCollected = num(csExpected.get("old_due_total_collected_C124"));   // sum of log
        double oldPartyDue = oldDueStartPool - oldDueCollected;
        check("Cash Summary B13 (2024-25 Old Party Due)", oldPartyDue, num(csExpected.get("old_party_due_B13")), 0.5);

        double forwardDue = num(csExpected.get("forward_due_B14"));         // manual (kept 0)
        double otherAdjustments = num(csExpected.get("other_adjustments_B15")); // manual input
        double finalCash = currentCash - totalPartnerDue - customerDueTotal - oldPartyDue - forwardDue - otherAdjustments;
        check("Cash Summary B16 (FINAL CASH in hand)", finalCash, num(csExpected.get("final_cash_B16")), 1.0);

        // ---------- 4. SEASON P&L + PROFIT DISTRIBUTION ----------
        System.out.println("\n== Section D: Season P&L + 16-Anna Profit Distribution ==");
        double netProfit = totalSales - totalExpense;
        check("Net Profit/Loss (B23)", netProfit, num(csExpected.get("net_profit_loss_B23")), 0.5);

        List<Map<String,Object>> expectedShares = asListOfMaps(expected.get("profit_distribution"));
        double totalShare = 0;
        for (Map<String,Object> p : partners) {
            String name = str(p.get("name"));
            double annaShare = num(p.get("share_anna"));
            double share = annaShare / 16.0 * netProfit;
            totalShare += share;
            for (Map<String,Object> es : expectedShares) {
                if (str(es.get("partner")).equals(name)) {
                    check("Profit Share: " + name, share, num(es.get("profit_share")), 0.5);
                }
            }
        }
        check("Total Profit Share (C57)", totalShare, num(csExpected.get("profit_share_total_C57")), 1.0);

        // ---------- 5. DIESEL / COAL STOCK ----------
        System.out.println("\n== Section E: Diesel / Coal Stock ==");
        Set<String> dieselCats = new HashSet<>(Arrays.asList("Diesel", "Diesel Transport"));
        Set<String> coalCats = new HashSet<>(Arrays.asList("Coal Purchase", "Coal Transport", "Coal Breaking"));
        double dieselPurchasedQty = sumIfCategory(expenses, "quantity", Collections.singleton("Diesel"));
        double dieselCost = sumIfCategory(expenses, "amount", dieselCats);
        double dieselIssued = 0.0; // diesel_issues.json is empty in current data
        double dieselStock = dieselPurchasedQty - dieselIssued;
        Map<String,Object> dieselExpected = asMap(expected.get("diesel_summary"));
        check("Diesel Total Purchased (Liter)", dieselPurchasedQty, num(dieselExpected.get("total_purchased_liter")), 0.01);
        check("Diesel Total Cost", dieselCost, num(dieselExpected.get("total_cost")), 0.01);
        check("Diesel Current Stock", dieselStock, num(dieselExpected.get("current_stock_liter")), 0.01);

        double coalPurchasedQty = sumIfCategory(expenses, "quantity", Collections.singleton("Coal Purchase"));
        double coalCost = sumIfCategory(expenses, "amount", coalCats);
        double coalUsed = 0.0; // coal_usages.json is empty in current data
        double coalStock = coalPurchasedQty - coalUsed;
        Map<String,Object> coalExpected = asMap(expected.get("coal_summary"));
        check("Coal Total Purchased", coalPurchasedQty, num(coalExpected.get("total_purchased")), 0.01);
        check("Coal Total Cost", coalCost, num(coalExpected.get("total_cost")), 0.01);
        check("Coal Current Stock", coalStock, num(coalExpected.get("current_stock")), 0.01);

        // ---------- 5b. FULL CUSTOMER DUE COVERAGE (all 393 customers, not just a sample) ----------
        System.out.println("\n== Section E2: Customer Due -- FULL coverage (all customers) ==");
        List<Map<String,Object>> customers = asListOfMaps(setup.get("customers"));
        Map<String,Double> customerOpeningDue = new HashMap<>();
        for (Map<String,Object> c : customers) customerOpeningDue.put(str(c.get("name")), num(c.get("opening_due")));

        String fullPath = base + "customer_due_full.json";
        List<Map<String,Object>> customerDueFull = asListOfMaps(parseJson(readFile(fullPath)));
        int customerPass = 0, customerFail = 0;
        List<String> customerFailures = new ArrayList<>();
        for (Map<String,Object> row : customerDueFull) {
            String name = str(row.get("customer"));
            double expectedDue = num(row.get("total_due"));
            double openingDue = customerOpeningDue.getOrDefault(name, 0.0);
            // D-quirk-1 (fully resolved): the all-customer-list screen (which is what
            // customer_due_full.json's expected values come from, Customer Ledger row
            // 670+) uses openingDue - extraPayment ONLY -- it does NOT touch Sales
            // Register activity at all. extraPayment is 0 in the current dataset.
            double actualDue = openingDue - 0.0;
            if (Math.abs(actualDue - expectedDue) <= 0.5) {
                customerPass++;
            } else {
                customerFail++;
                customerFailures.add(name + " actual=" + actualDue + " expected=" + expectedDue);
            }
        }
        System.out.printf("  Customer ALL-LIST-screen due check (openingDue - extraPayment): %d/%d matched%n",
                customerPass, customerDueFull.size());
        if (customerFail > 0) {
            System.out.println("  Mismatches (" + customerFail + "):");
            for (String f : customerFailures) System.out.println("   - " + f);
        }
        pass += customerPass; fail += customerFail;
        failures.addAll(customerFailures.stream().map(s -> "CustomerDue(all-list): " + s).collect(Collectors.toList()));

        // Also verify the DETAIL-SCREEN formula independently, against a live cached
        // snapshot found in the source file itself: Customer Ledger!B3 was saved with
        // "faici driver" selected (lowercase -- proving Excel's SUMIFS/MATCH name
        // comparison is CASE-INSENSITIVE, matched against "FAICI DRIVER" rows in Sales
        // Register). Cached D8 (Total Due, detail formula) = 32600 at save time.
        double faiciTotalSales = 0, faiciReceived = 0;
        for (Map<String,Object> row : sales) {
            if (!"Customer".equals(str(row.get("party_type")))) continue;
            if (!"FAICI DRIVER".equalsIgnoreCase(str(row.get("party_name")))) continue;
            faiciTotalSales += num(row.get("amount"));
            faiciReceived += num(row.get("advance_payment")) + num(row.get("cash_received"));
        }
        check("Customer Ledger detail-screen A8 (Total Sales, FAICI DRIVER)", faiciTotalSales, 334320.0, 0.01);
        check("Customer Ledger detail-screen B8 (Received at Sale, FAICI DRIVER)", faiciReceived, 301720.0, 0.01);
        check("Customer Ledger detail-screen D8 (Total Due = A8-B8-C8, FAICI DRIVER)",
                faiciTotalSales - faiciReceived - 0.0, 32600.0, 0.01);

        // Partner Ledger!B3 was saved with "Saeed" selected; cached D8 = 1,011,000.
        // Cross-check against the SAME baseline-aware partnerDue() formula used for
        // the all-partner list (proving Partner Ledger's two screens really do agree,
        // unlike Customer Ledger's two screens).
        for (Map<String,Object> p : partners) {
            if (!"Saeed".equalsIgnoreCase(str(p.get("name")))) continue;
            double due = calcDue(sales, "Partner", "Saeed", num(p.get("opening_due")), baseline, 0.0);
            check("Partner Ledger detail-screen D8 (Total Due, Saeed)", due, 1011000.0, 0.5);
        }

        // ---------- 6. EXPENSE SUMMARY BY CATEGORY (spot check first 8) ----------
        System.out.println("\n== Section F: Expense Summary by Category (spot check) ==");
        List<Map<String,Object>> expCatExpected = asListOfMaps(expected.get("expense_summary_by_category"));
        int spot = 0;
        for (Map<String,Object> ec : expCatExpected) {
            if (spot++ >= 10) break;
            String cat = str(ec.get("category"));
            double actualTotal = sumIfCategory(expenses, "amount", Collections.singleton(cat));
            double actualPaid = sumIfCategory(expenses, "paid_cash", Collections.singleton(cat));
            check("Expense[" + cat + "].total", actualTotal, num(ec.get("total_expense")), 0.01);
            check("Expense[" + cat + "].paid", actualPaid, num(ec.get("total_paid")), 0.01);
        }

        // ---------- SUMMARY ----------
        System.out.println("\n================ VALIDATION SUMMARY ================");
        System.out.println("PASS: " + pass + "   FAIL: " + fail);
        if (!failures.isEmpty()) {
            System.out.println("\nFailures:");
            for (String f : failures) System.out.println(" - " + f);
        }
        Files.write(Paths.get("RESULT.txt"),
                (("PASS=" + pass + " FAIL=" + fail + "\n") + String.join("\n", failures)).getBytes());
        System.exit(fail == 0 ? 0 : 1);
    }

    static String readFile(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)), "UTF-8");
    }
}
