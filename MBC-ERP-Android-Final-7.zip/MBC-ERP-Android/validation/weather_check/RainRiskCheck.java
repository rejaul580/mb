import java.util.*;

// Java mirror of RainRiskCalculator.kt, used ONLY to actually execute and verify the
// logic (this sandbox has no kotlinc). If this passes, the Kotlin translation (1:1,
// same branching, same thresholds) is logically sound.
public class RainRiskCheck {
    enum RiskLevel { NONE, LOW, MODERATE, HIGH, SEVERE }

    static class Point {
        int hoursFromNow; int prob; double mm;
        Point(int h, int p, double m) { hoursFromNow = h; prob = p; mm = m; }
    }

    static class Thresholds {
        int probabilityThresholdPercent = 40;
        double heavyRainMm = 7.5;
        int leadTimeHours = 12;
    }

    static class Assessment {
        RiskLevel level; Integer firstRiskyHour; int maxProb; double maxMm; String reason;
        Assessment(RiskLevel l, Integer h, int p, double m, String r) { level=l; firstRiskyHour=h; maxProb=p; maxMm=m; reason=r; }
    }

    static Assessment assess(List<Point> forecast, Thresholds t) {
        List<Point> within = new ArrayList<>();
        for (Point p : forecast) if (p.hoursFromNow >= 0 && p.hoursFromNow <= t.leadTimeHours) within.add(p);
        if (within.isEmpty()) return new Assessment(RiskLevel.NONE, null, 0, 0.0, "no data");

        List<Point> risky = new ArrayList<>();
        for (Point p : within) if (p.prob >= t.probabilityThresholdPercent) risky.add(p);
        if (risky.isEmpty()) {
            int maxP = 0; double maxM = 0;
            for (Point p : within) { maxP = Math.max(maxP, p.prob); maxM = Math.max(maxM, p.mm); }
            return new Assessment(RiskLevel.NONE, null, maxP, maxM, "no significant rain");
        }
        Point first = risky.get(0);
        for (Point p : risky) if (p.hoursFromNow < first.hoursFromNow) first = p;
        int maxProb = 0; double maxMm = 0; boolean heavy = false;
        for (Point p : risky) { maxProb = Math.max(maxProb, p.prob); maxMm = Math.max(maxMm, p.mm); if (p.mm >= t.heavyRainMm) heavy = true; }

        RiskLevel level;
        if (heavy) level = RiskLevel.SEVERE;
        else if (maxProb >= 80) level = RiskLevel.HIGH;
        else if (maxProb >= 60) level = RiskLevel.MODERATE;
        else level = RiskLevel.LOW;

        return new Assessment(level, first.hoursFromNow, maxProb, maxMm, level.toString());
    }

    static int pass=0, fail=0;
    static void check(String label, Object actual, Object expected) {
        boolean ok = Objects.equals(actual, expected);
        if (ok) { pass++; System.out.println("PASS  " + label); }
        else { fail++; System.out.println("FAIL  " + label + " actual=" + actual + " expected=" + expected); }
    }

    public static void main(String[] args) {
        Thresholds t = new Thresholds();

        // Test 1: no risk below threshold
        Assessment r1 = assess(Arrays.asList(new Point(1,10,0.0), new Point(5,20,0.5), new Point(10,30,0.2)), t);
        check("T1 no-risk level", r1.level, RiskLevel.NONE);
        check("T1 no-risk hour", r1.firstRiskyHour, null);

        // Test 2: low risk
        Assessment r2 = assess(Arrays.asList(new Point(3,45,1.0)), t);
        check("T2 low level", r2.level, RiskLevel.LOW);
        check("T2 low hour", r2.firstRiskyHour, 3);

        // Test 3: moderate at 60
        Assessment r3 = assess(Arrays.asList(new Point(4,65,2.0)), t);
        check("T3 moderate level", r3.level, RiskLevel.MODERATE);

        // Test 4: high at 80
        Assessment r4 = assess(Arrays.asList(new Point(2,85,3.0)), t);
        check("T4 high level", r4.level, RiskLevel.HIGH);

        // Test 5: severe via heavy mm regardless of prob
        Assessment r5 = assess(Arrays.asList(new Point(6,45,9.0)), t);
        check("T5 severe level", r5.level, RiskLevel.SEVERE);

        // Test 6: outside lead-time window
        Thresholds t6 = new Thresholds(); t6.leadTimeHours = 6;
        Assessment r6 = assess(Arrays.asList(new Point(20,95,10.0)), t6);
        check("T6 outside-window level", r6.level, RiskLevel.NONE);

        // Test 7: earliest risky hour picked, not worst
        Assessment r7 = assess(Arrays.asList(new Point(8,90,8.0), new Point(2,45,0.5)), t);
        check("T7 earliest hour", r7.firstRiskyHour, 2);

        // Test 8: empty forecast
        Assessment r8 = assess(new ArrayList<>(), t);
        check("T8 empty level", r8.level, RiskLevel.NONE);

        // Test 9: custom thresholds
        Thresholds t9 = new Thresholds(); t9.probabilityThresholdPercent = 10; t9.heavyRainMm = 2.0;
        Assessment r9 = assess(Arrays.asList(new Point(1,15,3.0)), t9);
        check("T9 custom-threshold severe", r9.level, RiskLevel.SEVERE);

        System.out.println("\nPASS=" + pass + " FAIL=" + fail);
        System.exit(fail == 0 ? 0 : 1);
    }
}
