# Google Sheets migration status

This package removes the previous cloud database implementation and replaces it with Google Sheets + Google Apps Script.

## Shared now
- Customers
- Sales
- Expenses
- Push on create/update/delete
- Pull on app startup/background sync
- Manual Dashboard sync button
- Offline Room cache remains active
- Stable `syncId` values prevent cross-device ID collisions for these shared modules

## Still local
- Partners / Majhis / Brick Types / Equipment / Expense Categories
- Production
- Assets
- Extra payments / old due collections
- Cash-summary manual adjustments
- Local PIN users

These modules are deliberately not auto-merged yet because financial records need the same stable-key and conflict policy before being shared across devices.

## Required before APK build
1. Deploy `cloud/google-apps-script/Code.gs` as a Google Apps Script Web App.
2. Put its `/exec` URL into `GoogleSheetsConfig.WEB_APP_URL`.
3. Optionally configure `API_TOKEN` on both sides.
4. Build with the included GitHub Actions workflow.
