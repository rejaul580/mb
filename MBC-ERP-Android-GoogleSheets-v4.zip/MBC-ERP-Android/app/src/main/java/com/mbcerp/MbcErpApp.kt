package com.mbcerp

import android.app.Application
import com.mbcerp.auth.AuthManager
import com.mbcerp.data.db.AppDatabase
import com.mbcerp.data.migration.ExcelDataImporter
import com.mbcerp.repository.*
import com.mbcerp.cloud.GoogleSheetsGateway
import com.mbcerp.cloud.GoogleSheetsSyncManager
import com.mbcerp.cloud.GoogleSheetsSyncWorker
import com.mbcerp.cloud.GoogleSheetsConfig
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * Manual dependency wiring (Decision: keep the app free of a DI framework like Hilt to
 * minimize moving parts while the schema is still settling; revisit if it grows further).
 */
class MbcErpApp : Application() {

    lateinit var database: AppDatabase
        private set
    lateinit var importer: ExcelDataImporter
        private set
    lateinit var authManager: AuthManager
        private set

    lateinit var setupRepository: SetupRepository
        private set
    lateinit var salesRepository: SalesRepository
        private set
    lateinit var expenseRepository: ExpenseRepository
        private set
    lateinit var ledgerRepository: LedgerRepository
        private set
    lateinit var cashSummaryRepository: CashSummaryRepository
        private set
    lateinit var registerRepository: RegisterRepository
        private set
    lateinit var dashboardRepository: DashboardRepository
        private set
    lateinit var productionRepository: ProductionRepository
        private set
    lateinit var assetRegisterRepository: AssetRegisterRepository
        private set
    lateinit var auditRepository: AuditRepository
        private set
    lateinit var printRepository: PrintRepository
        private set
    lateinit var googleSheetsGateway: GoogleSheetsGateway
        private set
    lateinit var googleSheetsSyncManager: GoogleSheetsSyncManager
        private set

    override fun onCreate() {
        super.onCreate()

        database = AppDatabase.getInstance(this)
        importer = ExcelDataImporter(this, database)
        authManager = AuthManager(this, database.appUserDao())
        googleSheetsGateway = GoogleSheetsGateway()
        googleSheetsSyncManager = GoogleSheetsSyncManager(database, googleSheetsGateway)

        setupRepository = SetupRepository(
            database.companyProfileDao(), database.partnerDao(), database.majhiDao(),
            database.brickTypeDao(), database.equipmentDao(), database.expenseCategoryDao(),
            database.customerDao(), googleSheetsGateway
        )
        salesRepository = SalesRepository(database.saleDao(), database.brickTypeDao(), googleSheetsGateway)
        expenseRepository = ExpenseRepository(database.expenseDao(), googleSheetsGateway)
        ledgerRepository = LedgerRepository(
            database.saleDao(), database.extraPaymentDao(), database.customerDao(),
            database.partnerDao(), database.companyProfileDao()
        )
        cashSummaryRepository = CashSummaryRepository(
            database.saleDao(), database.expenseDao(), database.companyProfileDao(),
            database.cashSummaryAdjustmentDao(), database.oldDueCollectionDao(),
            ledgerRepository, database.customerDao(), database.extraPaymentDao()
        )
        registerRepository = RegisterRepository(
            database.expenseDao(), database.stockDao(), database.majhiDao(), database.equipmentDao()
        )
        dashboardRepository = DashboardRepository(
            database.saleDao(), database.expenseDao(), database.companyProfileDao(),
            ledgerRepository, cashSummaryRepository, registerRepository
        )
        productionRepository = ProductionRepository(database.productionDao(), database.saleDao(), database.companyProfileDao())
        assetRegisterRepository = AssetRegisterRepository(database.assetRegisterDao())
        auditRepository = AuditRepository(
            database.partnerDao(), database.majhiDao(), database.equipmentDao(),
            database.expenseCategoryDao(), database.customerDao(), database.saleDao(), database.expenseDao()
        )
        printRepository = PrintRepository(database.saleDao(), database.extraPaymentDao())

        if (GoogleSheetsConfig.CONNECTED) {
            WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "mbc-google-sheets-sync",
                ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<GoogleSheetsSyncWorker>(15, TimeUnit.MINUTES).build()
            )
        }
    }
}
