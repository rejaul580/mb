package com.mbcerp.cloud

import com.mbcerp.data.entity.CustomerEntity
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.data.entity.SaleEntity
import org.json.JSONObject

fun SaleEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("voucherNo", voucherNo)
    put("truckNo", truckNo); put("partyType", partyType); put("partyName", partyName)
    put("location", location); put("sideParty", sideParty); put("sidePartyMobile", sidePartyMobile)
    put("brickCategory", brickCategory); put("quantity", quantity); put("rate", rate); put("amount", amount)
    put("advancePayment", advancePayment); put("cashReceived", cashReceived); put("remarks", remarks)
    put("saleType", saleType); put("createdAt", createdAt); put("updatedAt", updatedAt); put("isDeleted", isDeleted)
}

fun ExpenseEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("voucherNo", voucherNo)
    put("category", category); put("partyPaidTo", partyPaidTo); put("quantity", quantity); put("unit", unit)
    put("rate", rate); put("amount", amount); put("paidCash", paidCash); put("remarks", remarks)
    put("paymentMethod", paymentMethod); put("createdAt", createdAt); put("updatedAt", updatedAt); put("isDeleted", isDeleted)
}

fun CustomerEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("name", name); put("openingDue", openingDue); put("mobile", mobile); put("isActive", isActive)
}

fun JSONObject.toSaleEntity(localId: Long = 0) = SaleEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), voucherNo = optString("voucherNo").ifBlank { null },
    truckNo = optString("truckNo").ifBlank { null }, partyType = getString("partyType"), partyName = getString("partyName"),
    location = optString("location").ifBlank { null }, sideParty = optString("sideParty").ifBlank { null },
    sidePartyMobile = optString("sidePartyMobile").ifBlank { null }, brickCategory = getString("brickCategory"),
    quantity = optDouble("quantity", 0.0), rate = optDouble("rate", 0.0), amount = optDouble("amount", 0.0),
    advancePayment = optDouble("advancePayment", 0.0), cashReceived = optDouble("cashReceived", 0.0),
    remarks = optString("remarks").ifBlank { null }, saleType = optString("saleType").ifBlank { null },
    createdAt = optLong("createdAt", System.currentTimeMillis()), updatedAt = optLong("updatedAt", System.currentTimeMillis()),
    isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toExpenseEntity(localId: Long = 0) = ExpenseEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), voucherNo = optString("voucherNo").ifBlank { null },
    category = getString("category"), partyPaidTo = optString("partyPaidTo").ifBlank { null }, quantity = optDouble("quantity", 0.0),
    unit = optString("unit").ifBlank { null }, rate = optDouble("rate", 0.0), amount = optDouble("amount", 0.0),
    paidCash = optDouble("paidCash", 0.0), remarks = optString("remarks").ifBlank { null },
    paymentMethod = optString("paymentMethod").ifBlank { null }, createdAt = optLong("createdAt", System.currentTimeMillis()),
    updatedAt = optLong("updatedAt", System.currentTimeMillis()), isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toCustomerEntity(localId: Long = 0) = CustomerEntity(
    id = localId, syncId = getString("syncId"), name = getString("name"), openingDue = optDouble("openingDue", 0.0),
    mobile = optString("mobile").ifBlank { null }, isActive = optBoolean("isActive", true)
)
