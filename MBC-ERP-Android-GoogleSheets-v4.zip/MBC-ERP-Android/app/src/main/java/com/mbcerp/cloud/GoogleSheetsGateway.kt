package com.mbcerp.cloud

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Google Sheets transport used for the shared Google Sheets backend.
 * The Apps Script Web App owns the spreadsheet; the Android app never receives
 * a Google service-account key.
 */
class GoogleSheetsGateway(
    private val url: String = GoogleSheetsConfig.WEB_APP_URL,
    private val client: OkHttpClient = OkHttpClient()
) {
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun upsert(entity: String, recordKey: String, payload: JSONObject): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(GoogleSheetsConfig.CONNECTED) { "Google Sheets URL is not configured." }
            val body = JSONObject().apply {
                put("action", "upsert")
                put("entity", entity)
                put("recordKey", recordKey)
                put("payload", payload)
                put("token", GoogleSheetsConfig.API_TOKEN)
            }
            val request = Request.Builder().url(url).post(body.toString().toRequestBody(jsonType)).build()
            client.newCall(request).execute().use { response ->
                check(response.isSuccessful) { "Google Sheets HTTP ${response.code}" }
            }
        }
    }

    suspend fun pull(entity: String): Result<List<JSONObject>> = withContext(Dispatchers.IO) {
        runCatching {
            require(GoogleSheetsConfig.CONNECTED) { "Google Sheets URL is not configured." }
            val request = Request.Builder().url("$url?action=pull&entity=$entity&token=${java.net.URLEncoder.encode(GoogleSheetsConfig.API_TOKEN, "UTF-8")}").get().build()
            client.newCall(request).execute().use { response ->
                check(response.isSuccessful) { "Google Sheets HTTP ${response.code}" }
                val root = JSONObject(response.body?.string().orEmpty())
                val rows = root.optJSONArray("records") ?: JSONArray()
                buildList { for (i in 0 until rows.length()) add(rows.getJSONObject(i)) }
            }
        }
    }
}
