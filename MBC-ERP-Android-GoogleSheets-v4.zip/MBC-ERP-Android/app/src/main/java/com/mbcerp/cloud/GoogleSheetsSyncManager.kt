package com.mbcerp.cloud

import com.mbcerp.data.db.AppDatabase

class GoogleSheetsSyncManager(
    private val database: AppDatabase,
    private val gateway: GoogleSheetsGateway
) {
    suspend fun pullSharedData(): Result<Unit> = runCatching {
        syncCustomers()
        syncSales()
        syncExpenses()
    }

    private suspend fun syncCustomers() {
        gateway.pull("Customers").getOrThrow().forEach { row ->
            val payload = row.getJSONObject("payload")
            val incoming = payload.toCustomerEntity()
            val local = database.customerDao().findBySyncId(incoming.syncId)
            if (local == null) database.customerDao().insert(incoming)
            else database.customerDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncSales() {
        gateway.pull("Sales").getOrThrow().forEach { row ->
            val payload = row.getJSONObject("payload")
            val incoming = payload.toSaleEntity()
            val local = database.saleDao().findBySyncId(incoming.syncId)
            if (local == null) database.saleDao().insert(incoming)
            else database.saleDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncExpenses() {
        gateway.pull("Expenses").getOrThrow().forEach { row ->
            val payload = row.getJSONObject("payload")
            val incoming = payload.toExpenseEntity()
            val local = database.expenseDao().findBySyncId(incoming.syncId)
            if (local == null) database.expenseDao().insert(incoming)
            else database.expenseDao().update(incoming.copy(id = local.id))
        }
    }
}
