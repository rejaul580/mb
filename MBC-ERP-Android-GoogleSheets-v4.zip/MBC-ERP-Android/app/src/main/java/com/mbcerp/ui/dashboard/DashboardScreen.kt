package com.mbcerp.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.data.entity.SaleEntity
import com.mbcerp.repository.DashboardRepository
import com.mbcerp.cloud.GoogleSheetsSyncManager
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

class DashboardViewModel(private val dashboardRepository: DashboardRepository, private val syncManager: GoogleSheetsSyncManager? = null) : ViewModel() {
    private val _kpis = MutableStateFlow<DashboardRepository.DashboardKpis?>(null)
    val kpis: StateFlow<DashboardRepository.DashboardKpis?> = _kpis
    private val _dailySales = MutableStateFlow<List<SaleEntity>>(emptyList())
    val dailySales: StateFlow<List<SaleEntity>> = _dailySales
    private val _dailyExpenses = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val dailyExpenses: StateFlow<List<ExpenseEntity>> = _dailyExpenses
    fun load() = viewModelScope.launch { _kpis.value = dashboardRepository.kpis() }
    fun syncAndReload() = viewModelScope.launch { syncManager?.pullSharedData(); _kpis.value = dashboardRepository.kpis() }
    fun loadDailyReport(date: LocalDate) = viewModelScope.launch { _dailySales.value = dashboardRepository.dailySales(date.toString()); _dailyExpenses.value = dashboardRepository.dailyExpenses(date.toString()) }
}
class DashboardViewModelFactory(private val dashboardRepository: DashboardRepository, private val syncManager: GoogleSheetsSyncManager? = null) : ViewModelProvider.Factory { @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = DashboardViewModel(dashboardRepository, syncManager) as T }
private data class Kpi(val label: String, val value: Double, val icon: ImageVector, val negative: Boolean = false)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(vm: DashboardViewModel, onWeatherClick: () -> Unit = {}) {
    val kpis by vm.kpis.collectAsState()
    var showDaily by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.load() }
    Scaffold(
        containerColor = AppBlack,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("Dashboard", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp); Text("MBC Bricks ERP", color = TextSecondary, fontSize = 8.sp) } },
                navigationIcon = { IconButton(onClick = {}) { Icon(Icons.Default.Menu, null) } },
                actions = { IconButton(onClick = { vm.syncAndReload() }) { Icon(Icons.Default.Sync, contentDescription = "Sync") }; IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null) } },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = AppBlack, titleContentColor = TextPrimary, navigationIconContentColor = TextPrimary, actionIconContentColor = TextPrimary)
            )
        }
    ) { pad ->
        if (kpis == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = BrickOrange) }
            return@Scaffold
        }
        val k = kpis!!
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CashHero(k.cashInHand)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                KpiTile(Kpi("Total Sales", k.totalSalesAmount, Icons.Default.ShoppingCart), Modifier.weight(1f))
                KpiTile(Kpi("Collection", k.totalAdvanceSale, Icons.Default.Payments), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                KpiTile(Kpi("Total Expense", k.totalExpenseAmount, Icons.Default.ReceiptLong, true), Modifier.weight(1f))
                KpiTile(Kpi("Due Amount", k.totalCustomerDue, Icons.Default.AccountBalance, true), Modifier.weight(1f))
            }
            SectionTitle("Production & Weather", null)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                ProductionCard(k, Modifier.weight(1f))
                WeatherCard(onWeatherClick, Modifier.weight(1f))
            }
            SectionTitle("Quick Actions", "View All") { showDaily = true; vm.loadDailyReport(LocalDate.now()) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                ActionCard("Add Sale", Icons.Default.AddShoppingCart, Modifier.weight(1f))
                ActionCard("Expense", Icons.Default.AddCard, Modifier.weight(1f))
                ActionCard("Production", Icons.Default.Factory, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
        }
    }
    if (showDaily) DailyReportDialog(vm) { showDaily = false }
}

@Composable private fun CashHero(amount: Double) {
    Card(Modifier.fillMaxWidth().height(122.dp), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent)) {
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF7A2500), Color(0xFFE84D00), Color(0xFFFF6A0A))), RoundedCornerShape(16.dp)).padding(16.dp)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("CASH IN HAND", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.weight(1f)); Icon(Icons.Default.Visibility, null, tint = Color.White, modifier = Modifier.size(19.dp))
                }
                Spacer(Modifier.height(5.dp))
                Text("৳ ${"%,.0f".format(amount)}", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(2.dp))
                Text("Last Updated: Today, 09:30 AM", color = Color.White.copy(.78f), fontSize = 9.sp)
            }
        }
    }
}

@Composable private fun SectionTitle(title: String, action: String?, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = TextPrimary)
        Spacer(Modifier.weight(1f))
        if (action != null) TextButton(onClick = { onClick?.invoke() }, contentPadding = PaddingValues(0.dp)) { Text(action, color = BrickOrange, fontSize = 10.sp) }
    }
}

@Composable private fun KpiTile(k: Kpi, modifier: Modifier = Modifier) {
    Card(modifier.height(84.dp), shape = RoundedCornerShape(11.dp), colors = CardDefaults.cardColors(containerColor = AppSurface2), border = androidx.compose.foundation.BorderStroke(1.dp, AppStroke)) {
        Column(Modifier.padding(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(k.icon, null, tint = if (k.negative) ErrorRed else BrickOrange, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp)); Text(k.label.uppercase(), color = TextSecondary, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(5.dp)); Text("৳ ${"%,.0f".format(k.value)}", color = if (k.negative) ErrorRed else TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable private fun ProductionCard(k: DashboardRepository.DashboardKpis, modifier: Modifier) {
    Card(modifier.height(152.dp), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = AppSurface2), border = androidx.compose.foundation.BorderStroke(1.dp, AppStroke)) {
        Column(Modifier.padding(12.dp)) {
            Text("PRODUCTION", color = BrickOrange, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp)); Text("${"%,.0f".format(k.totalBricksSoldQty)}", color = TextPrimary, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text("Bricks / Pcs", color = TextSecondary, fontSize = 8.sp)
            Spacer(Modifier.height(9.dp)); Text("Today", color = TextSecondary, fontSize = 8.sp)
            LinearProgressIndicator(progress = { .72f }, modifier = Modifier.fillMaxWidth().padding(top = 5.dp), color = BrickOrange, trackColor = AppSurface3)
        }
    }
}

@Composable private fun WeatherCard(onClick: () -> Unit, modifier: Modifier) {
    Card(modifier.height(152.dp), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF101D25)), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF28404C))) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("WEATHER ALERT", color = EmberGold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.weight(1f)); Icon(Icons.Default.Thunderstorm, null, tint = EmberGold, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.height(7.dp)); Text("Moderate Rain Alert", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            Text("Rain Expected: 60%", color = TextSecondary, fontSize = 8.sp)
            Text("Alert Lead Time: 60 Minutes", color = TextSecondary, fontSize = 8.sp)
            Spacer(Modifier.height(8.dp)); Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(31.dp), contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(7.dp), colors = ButtonDefaults.buttonColors(containerColor = BrickOrange)) { Text("View Forecast", fontSize = 9.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable private fun ActionCard(title: String, icon: ImageVector, modifier: Modifier) {
    Card(modifier.height(70.dp), shape = RoundedCornerShape(10.dp), colors = CardDefaults.cardColors(containerColor = AppSurface2), border = androidx.compose.foundation.BorderStroke(1.dp, AppStroke)) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = BrickOrange, modifier = Modifier.size(19.dp)); Spacer(Modifier.height(3.dp)); Text(title, color = TextSecondary, fontSize = 9.sp)
        }
    }
}

@Composable private fun DailyReportDialog(vm: DashboardViewModel, onDismiss: () -> Unit) {
    val sales by vm.dailySales.collectAsState(); val expenses by vm.dailyExpenses.collectAsState()
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Today's Report") }, text = { Column { Text("Sales: ${sales.size} entries — ৳${"%,.0f".format(sales.sumOf { it.amount })}"); Spacer(Modifier.height(8.dp)); Text("Expense: ${expenses.size} entries — ৳${"%,.0f".format(expenses.sumOf { it.amount })}") } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }, containerColor = AppSurface2, titleContentColor = TextPrimary, textContentColor = TextSecondary)
}
