package com.mbcerp.ui.production

import androidx.compose.ui.res.stringResource

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Factory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.ProductionEntryEntity
import com.mbcerp.repository.ProductionRepository
import com.mbcerp.ui.common.EmptyState
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * PRODUCTION REGISTER (AUDIT §2.9). Decision D6: stock estimate faithfully
 * replicates the source's "1 No"/"2 No" only coverage rather than expanding it --
 * see ProductionRepository.stockEstimate() / StockCalculator.productionStockEstimate().
 */
class ProductionViewModel(private val productionRepository: ProductionRepository) : ViewModel() {
    val entries = productionRepository.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _stockEstimate = MutableStateFlow(0.0)
    val stockEstimate: StateFlow<Double> = _stockEstimate

    fun loadStock() = viewModelScope.launch { _stockEstimate.value = productionRepository.stockEstimate() }
    fun addEntry(e: ProductionEntryEntity) = viewModelScope.launch { productionRepository.addEntry(e); loadStock() }
}

class ProductionViewModelFactory(private val productionRepository: ProductionRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ProductionViewModel(productionRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductionScreen(vm: ProductionViewModel) {
    val entries by vm.entries.collectAsState()
    val stock by vm.stockEstimate.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadStock() }

    Scaffold(
        containerColor = AppBlack,
        topBar = { TopAppBar(title = { Text("Production Register", color = TextPrimary, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBlack, titleContentColor = TextPrimary)) },
        floatingActionButton = { FloatingActionButton(onClick = { showDialog = true }, containerColor = BrickOrange, contentColor = Color.White) { Icon(Icons.Default.Add, contentDescription = "Add") } }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = BrickOrangeDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Estimated Current Stock", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("${"%,.0f".format(stock)} pcs", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("শুধু 1 No / 2 No কভার করা (Decision D6)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Spacer(Modifier.height(16.dp))
            if (entries.isEmpty()) {
                EmptyState(Icons.Default.Factory, "কোনো Production এন্ট্রি নেই", "নিচের + বাটনে চাপ দিয়ে নতুন এন্ট্রি দিন")
            } else {
                LazyColumn {
                    items(entries) { e ->
                        Card(
                            shape = MaterialTheme.shapes.medium,
                            colors = CardDefaults.cardColors(containerColor = AppSurface2),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Text("${e.date}  •  ${e.type ?: ""}", style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "Loaded: ${e.loadedToKiln}  |  Fired Out: ${e.unloadedFiredOut}  |  Majhi: ${e.majhiName ?: "-"}",
                                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var date by remember { mutableStateOf(LocalDate.now().toString()) }
        var majhi by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("Manual") }
        var raw by remember { mutableStateOf("0") }
        var loaded by remember { mutableStateOf("0") }
        var fired by remember { mutableStateOf("0") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("নতুন Production Entry") },
            text = {
                Column {
                    OutlinedTextField(date, { date = it }, label = { Text("Date") })
                    OutlinedTextField(majhi, { majhi = it }, label = { Text("Majhi") })
                    Row { FilterChip(selected = type == "Manual", onClick = { type = "Manual" }, label = { Text("Manual") }); Spacer(Modifier.width(8.dp)); FilterChip(selected = type == "Auto", onClick = { type = "Auto" }, label = { Text("Auto") }) }
                    OutlinedTextField(raw, { raw = it }, label = { Text("Raw Bricks Counted") })
                    OutlinedTextField(loaded, { loaded = it }, label = { Text("Loaded To Kiln") })
                    OutlinedTextField(fired, { fired = it }, label = { Text("Fired Out (Pucca)") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addEntry(
                        ProductionEntryEntity(
                            date = date, majhiName = majhi.ifBlank { null }, type = type,
                            rawBricksCounted = raw.toDoubleOrNull() ?: 0.0,
                            loadedToKiln = loaded.toDoubleOrNull() ?: 0.0,
                            unloadedFiredOut = fired.toDoubleOrNull() ?: 0.0
                        )
                    )
                    showDialog = false
                }) { Text(stringResource(com.mbcerp.R.string.action_add)) }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}
