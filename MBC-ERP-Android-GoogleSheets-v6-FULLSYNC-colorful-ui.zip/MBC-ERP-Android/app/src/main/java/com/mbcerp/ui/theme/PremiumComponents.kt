package com.mbcerp.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PremiumPage(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().background(AppBlack).padding(horizontal = 14.dp, vertical = 8.dp), content = content)
}

@Composable
fun PremiumTopBar(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null, action: ImageVector? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.ArrowBack, null, tint = TextPrimary) }
            Spacer(Modifier.width(2.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            subtitle?.let { Text(it, color = TextSecondary, fontSize = 9.sp) }
        }
        if (action != null) IconButton(onClick = { onAction?.invoke() }, modifier = Modifier.size(40.dp)) { Icon(action, null, tint = TextPrimary) }
    }
}

@Composable
fun PremiumCard(modifier: Modifier = Modifier, accent: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(13.dp),
        colors = CardDefaults.cardColors(containerColor = if (accent) BrickOrangeDark else AppSurface2),
        border = BorderStroke(1.dp, if (accent) BrickOrange.copy(alpha = .55f) else AppStroke),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        content = { Column(Modifier.padding(13.dp), content = content) }
    )
}

@Composable
fun PremiumAmountCard(label: String, amount: String, modifier: Modifier = Modifier, negative: Boolean = false) {
    PremiumCard(modifier) {
        Text(label.uppercase(), color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(amount, color = if (negative) ErrorRed else TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun PremiumDatePill(text: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(9.dp), color = AppSurface3, border = BorderStroke(1.dp, AppStroke)) {
        Text(text, color = TextPrimary, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp))
    }
}

@Composable
fun PremiumPrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(onClick, modifier.height(44.dp), shape = RoundedCornerShape(9.dp), colors = ButtonDefaults.buttonColors(containerColor = BrickOrange)) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}
