package com.mbcerp.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items as lazyRowItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.data.entity.SaleEntity
import com.mbcerp.repository.DashboardRepository
import com.mbcerp.cloud.GoogleSheetsSyncManager
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

class DashboardViewModel(private val dashboardRepository: DashboardRepository, private val syncManager: GoogleSheetsSyncManager? = null) : ViewModel() {
    private val _kpis = MutableStateFlow<DashboardRepository.DashboardKpis?>(null)
    val kpis: StateFlow<DashboardRepository.DashboardKpis?> = _kpis
    private val _dailySales = MutableStateFlow<List<SaleEntity>>(emptyList())
    val dailySales: StateFlow<List<SaleEntity>> = _dailySales
    private val _dailyExpenses = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val dailyExpenses: StateFlow<List<ExpenseEntity>> = _dailyExpenses
    fun load() = viewModelScope.launch { _kpis.value = dashboardRepository.kpis() }
    fun syncAndReload() = viewModelScope.launch { syncManager?.pullSharedData(); _kpis.value = dashboardRepository.kpis() }
    fun loadDailyReport(date: LocalDate) = viewModelScope.launch { _dailySales.value = dashboardRepository.dailySales(date.toString()); _dailyExpenses.value = dashboardRepository.dailyExpenses(date.toString()) }
}
class DashboardViewModelFactory(private val dashboardRepository: DashboardRepository, private val syncManager: GoogleSheetsSyncManager? = null) : ViewModelProvider.Factory { @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = DashboardViewModel(dashboardRepository, syncManager) as T }
private data class Kpi(val label: String, val value: Double, val icon: ImageVector, val accent: Color, val negative: Boolean = false)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    vm: DashboardViewModel,
    onWeatherClick: () -> Unit = {},
    onAddSaleClick: () -> Unit = {},
    onExpenseClick: () -> Unit = {},
    onProductionClick: () -> Unit = {},
    onMoreClick: () -> Unit = {}
) {
    val kpis by vm.kpis.collectAsState()
    var showDaily by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.load() }
    Scaffold(
        containerColor = AppBlack,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("Dashboard", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp); Text("MBC Bricks ERP", color = TextSecondary, fontSize = 8.sp) } },
                actions = {
                    IconButton(onClick = { vm.syncAndReload() }) { Icon(Icons.Default.Sync, contentDescription = "Sync", tint = InfoBlue) }
                    IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, null, tint = EmberGold) }
                    IconButton(onClick = onMoreClick) { Icon(Icons.Default.MoreVert, contentDescription = "More", tint = TextPrimary) }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = AppBlack, titleContentColor = TextPrimary, navigationIconContentColor = TextPrimary, actionIconContentColor = TextPrimary)
            )
        }
    ) { pad ->
        if (kpis == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = BrickOrange) }
            return@Scaffold
        }
        val k = kpis!!
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF241026), Color(0xFF160B22), AppBlack), endY = 900f)
            )
        ) {
            Column(
                Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                CashHero(k.cashInHand)

                SectionTitle("এক নজরে (This Month)", null)
                val chips = listOf(
                    Kpi("Total Sales", k.totalSalesAmount, Icons.Default.ShoppingCart, InfoBlue),
                    Kpi("Collection", k.totalAdvanceSale, Icons.Default.Payments, SuccessGreen),
                    Kpi("Total Expense", k.totalExpenseAmount, Icons.Default.ReceiptLong, ErrorRed, true),
                    Kpi("Customer Due", k.totalCustomerDue, Icons.Default.AccountBalanceWallet, VioletAccent, true),
                    Kpi("Partner Due", k.totalPartnerDue, Icons.Default.Groups, PinkAccent, true),
                    Kpi("Payable Due", k.totalPayableExpenseDue, Icons.Default.RequestQuote, WarningAmber, true)
                )
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    lazyRowItems(chips) { chip -> KpiChip(chip) }
                }

                SalesVsExpenseCard(k.totalSalesAmount, k.totalExpenseAmount)

                SectionTitle("Production & Weather", null)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    ProductionCard(k, Modifier.weight(1f))
                    WeatherCard(onWeatherClick, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    StockPill("Diesel Stock", "${"%,.0f".format(k.dieselStockLiter)} L", Icons.Default.LocalGasStation, WarningAmber, Modifier.weight(1f))
                    StockPill("Coal Stock", "${"%,.0f".format(k.coalStock)}", Icons.Default.LocalFireDepartment, EmberGold, Modifier.weight(1f))
                }

                SectionTitle("Quick Actions", "View All") { showDaily = true; vm.loadDailyReport(LocalDate.now()) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    ActionCard("Add Sale", Icons.Default.AddShoppingCart, SuccessGreen, Modifier.weight(1f), onClick = onAddSaleClick)
                    ActionCard("Expense", Icons.Default.AddCard, ErrorRed, Modifier.weight(1f), onClick = onExpenseClick)
                    ActionCard("Production", Icons.Default.Factory, CyanAccent, Modifier.weight(1f), onClick = onProductionClick)
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
    if (showDaily) DailyReportDialog(vm) { showDaily = false }
}

@Composable private fun CashHero(amount: Double) {
    Card(Modifier.fillMaxWidth().height(126.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF7A0A5C), Color(0xFFE84D00), Color(0xFFFFB23E))), RoundedCornerShape(18.dp))) {
            // decorative glow circles for depth
            Box(Modifier.size(120.dp).offset(x = 250.dp, y = (-40).dp).clip(CircleShape).background(Color.White.copy(alpha = .08f)))
            Box(Modifier.size(70.dp).offset(x = 10.dp, y = 70.dp).clip(CircleShape).background(Color.White.copy(alpha = .06f)))
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(22.dp).clip(CircleShape).background(Color.White.copy(alpha = .22f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AccountBalanceWallet, null, tint = Color.White, modifier = Modifier.size(13.dp))
                    }
                    Spacer(Modifier.width(7.dp))
                    Text("CASH IN HAND", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.weight(1f)); Icon(Icons.Default.Visibility, null, tint = Color.White, modifier = Modifier.size(19.dp))
                }
                Spacer(Modifier.height(5.dp))
                Text("৳ ${"%,.0f".format(amount)}", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, null, tint = Color.White.copy(.78f), modifier = Modifier.size(10.dp))
                    Spacer(Modifier.width(3.dp))
                    Text("Last Updated: Today, 09:30 AM", color = Color.White.copy(.78f), fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable private fun SectionTitle(title: String, action: String?, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(BrickOrangeBright))
        Spacer(Modifier.width(6.dp))
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = TextPrimary)
        Spacer(Modifier.weight(1f))
        if (action != null) TextButton(onClick = { onClick?.invoke() }, contentPadding = PaddingValues(0.dp)) { Text(action, color = BrickOrangeBright, fontSize = 10.sp) }
    }
}

/** A rounded, tinted "chip" background behind an icon — gives every icon its own distinct color identity. */
@Composable private fun IconBadge(icon: ImageVector, color: Color, size: androidx.compose.ui.unit.Dp = 30.dp, iconSize: androidx.compose.ui.unit.Dp = 16.dp) {
    Box(
        modifier = Modifier.size(size).clip(RoundedCornerShape(size / 2.8f)).background(Brush.linearGradient(listOf(color, color.copy(alpha = .68f)))),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(iconSize)) }
}

@Composable private fun KpiChip(k: Kpi) {
    Card(
        Modifier.width(136.dp).height(96.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            Modifier.fillMaxSize()
                .background(Brush.linearGradient(listOf(k.accent.copy(alpha = .28f), AppSurface2, AppSurface2)))
                .border(1.dp, k.accent.copy(alpha = .4f), RoundedCornerShape(16.dp))
        ) {
            Box(Modifier.width(3.dp).fillMaxHeight().background(k.accent, RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)))
            Column(Modifier.padding(start = 14.dp, top = 12.dp, end = 10.dp, bottom = 12.dp)) {
                IconBadge(k.icon, k.accent, size = 26.dp, iconSize = 14.dp)
                Spacer(Modifier.height(8.dp))
                Text(k.label.uppercase(), color = TextSecondary, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Spacer(Modifier.height(3.dp))
                Text("৳ ${"%,.0f".format(k.value)}", color = if (k.negative) ErrorRed else TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Black, maxLines = 1)
            }
        }
    }
}

@Composable private fun SalesVsExpenseCard(sales: Double, expense: Double) {
    val maxVal = maxOf(sales, expense, 1.0)
    val salesFrac = (sales / maxVal).toFloat().coerceIn(0.03f, 1f)
    val expenseFrac = (expense / maxVal).toFloat().coerceIn(0.03f, 1f)
    val net = sales - expense
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = AppSurface2), border = androidx.compose.foundation.BorderStroke(1.dp, AppStroke), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("SALES vs EXPENSE", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.weight(1f))
                Text(if (net >= 0) "নেট প্রফিট ৳${"%,.0f".format(net)}" else "নেট লস ৳${"%,.0f".format(-net)}", color = if (net >= 0) SuccessGreen else ErrorRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            BarRow("Sales", sales, salesFrac, InfoBlue)
            Spacer(Modifier.height(8.dp))
            BarRow("Expense", expense, expenseFrac, ErrorRed)
        }
    }
}

@Composable private fun BarRow(label: String, amount: Double, fraction: Float, color: Color) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextSecondary, fontSize = 9.sp)
            Text("৳ ${"%,.0f".format(amount)}", color = TextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Box(Modifier.fillMaxWidth().height(9.dp).clip(RoundedCornerShape(5.dp)).background(AppSurface3)) {
            Box(
                Modifier.fillMaxWidth(fraction).fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(color, color.copy(alpha = .65f))), RoundedCornerShape(5.dp))
            )
        }
    }
}

@Composable private fun StockPill(label: String, value: String, icon: ImageVector, accent: Color, modifier: Modifier) {
    Card(modifier.height(58.dp), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Row(
            Modifier.fillMaxSize()
                .background(Brush.linearGradient(listOf(accent.copy(alpha = .18f), AppSurface2)))
                .border(1.dp, accent.copy(alpha = .35f), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBadge(icon, accent, size = 30.dp, iconSize = 16.dp)
            Spacer(Modifier.width(9.dp))
            Column {
                Text(label.uppercase(), color = TextSecondary, fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                Text(value, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable private fun ProductionCard(k: DashboardRepository.DashboardKpis, modifier: Modifier) {
    Card(modifier.height(152.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(BrickOrange.copy(alpha = .20f), AppSurface2))).border(1.dp, BrickOrange.copy(alpha = .35f), RoundedCornerShape(14.dp))) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Default.Factory, BrickOrange, size = 26.dp, iconSize = 14.dp)
                    Spacer(Modifier.width(6.dp))
                    Text("PRODUCTION", color = BrickOrangeBright, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.height(8.dp)); Text("${"%,.0f".format(k.totalBricksSoldQty)}", color = TextPrimary, fontSize = 23.sp, fontWeight = FontWeight.Black)
                Text("Bricks / Pcs", color = TextSecondary, fontSize = 8.sp)
                Spacer(Modifier.height(9.dp)); Text("Today", color = TextSecondary, fontSize = 8.sp)
                LinearProgressIndicator(progress = { .72f }, modifier = Modifier.fillMaxWidth().padding(top = 5.dp).clip(RoundedCornerShape(4.dp)), color = BrickOrangeBright, trackColor = AppSurface3)
            }
        }
    }
}

@Composable private fun WeatherCard(onClick: () -> Unit, modifier: Modifier) {
    Card(modifier.height(152.dp), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF13273A), Color(0xFF0B1720)))).border(1.dp, InfoBlue.copy(alpha = .35f), RoundedCornerShape(14.dp))) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("WEATHER ALERT", color = EmberGold, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.weight(1f))
                    IconBadge(Icons.Default.Thunderstorm, EmberGold, size = 28.dp, iconSize = 16.dp)
                }
                Spacer(Modifier.height(7.dp)); Text("Moderate Rain Alert", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WaterDrop, null, tint = InfoBlue, modifier = Modifier.size(10.dp))
                    Spacer(Modifier.width(3.dp)); Text("Rain Expected: 60%", color = TextSecondary, fontSize = 8.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Timer, null, tint = TextSecondary, modifier = Modifier.size(10.dp))
                    Spacer(Modifier.width(3.dp)); Text("Alert Lead Time: 60 Minutes", color = TextSecondary, fontSize = 8.sp)
                }
                Spacer(Modifier.height(8.dp)); Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(31.dp), contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = InfoBlue)) { Text("View Forecast", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            }
        }
    }
}

@Composable private fun ActionCard(title: String, icon: ImageVector, accent: Color, modifier: Modifier, onClick: () -> Unit = {}) {
    Card(modifier.height(78.dp).clickable(onClick = onClick), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = Color.Transparent), elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(accent.copy(alpha = .20f), AppSurface2))).border(1.dp, accent.copy(alpha = .4f), RoundedCornerShape(12.dp))) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                IconBadge(icon, accent, size = 32.dp, iconSize = 17.dp)
                Spacer(Modifier.height(5.dp)); Text(title, color = TextPrimary, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun DailyReportDialog(vm: DashboardViewModel, onDismiss: () -> Unit) {
    val sales by vm.dailySales.collectAsState(); val expenses by vm.dailyExpenses.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Today's Report") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Default.ShoppingCart, InfoBlue, size = 22.dp, iconSize = 12.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Sales: ${sales.size} entries — ৳${"%,.0f".format(sales.sumOf { it.amount })}")
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Default.ReceiptLong, ErrorRed, size = 22.dp, iconSize = 12.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Expense: ${expenses.size} entries — ৳${"%,.0f".format(expenses.sumOf { it.amount })}")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        containerColor = AppSurface2, titleContentColor = TextPrimary, textContentColor = TextSecondary
    )
}
