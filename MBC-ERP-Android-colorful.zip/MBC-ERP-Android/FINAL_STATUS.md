# MBC ERP final correction status

## Corrected in this package
- Supabase project URL configured.
- Supabase publishable client key configured (no service-role secret).
- Supabase REST gateway added for authenticated push/pull.
- Encrypted cloud session storage added.
- Cloud schema + RLS + optimistic conflict protection retained.
- Google OAuth redirect/setup instructions included.
- Backup navigation label removed and Android allowBackup remains false.
- Excel migration assets retained unchanged.

## Still requires the user's cloud-console action
1. Enable Google provider in Supabase Auth.
2. Create/configure Google OAuth client and add `mbcerp://login-callback`.
3. Run `cloud/supabase/schema.sql` once in Supabase SQL Editor.
4. Run `cloud/supabase/OWNER_SETUP.sql` after the owner signs in once.
5. Run the migration seed SQL once.
6. Build the APK in GitHub Actions and test with two real phones.

The package does NOT claim that the cloud is live until those console steps and two-device tests are completed.
