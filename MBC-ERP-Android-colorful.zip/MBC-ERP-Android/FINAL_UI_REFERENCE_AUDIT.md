# MBC ERP — Final UI Reference Pass

The UI has been revised against the supplied premium reference image as the visual master.

## Visual targets applied
- Premium black / charcoal background with MBC orange accent
- Premium MBC BRICKS ERP branding and brick-stack visual on login
- PIN keypad login with fingerprint action
- Cash In Hand hero card
- 2x2 KPI layout for Sales / Collection / Expense / Due
- Production + Weather Alert cards directly on Dashboard
- Quick Actions row
- Six-item compact bottom navigation: Dashboard, Sales, Expense, Production, Reports, More
- Orange selected navigation state without a large indicator pill
- Rounded dark cards, thin strokes, compact typography
- Backup is not exposed in the app UI

## Data safety check
All bundled migration JSON files under `app/src/main/assets/migration/` were compared with the input ZIP after the UI changes. No migration JSON file was changed by this UI pass.

## Verification limitation
No Android emulator/device renderer is available in this execution environment, so pixel-by-pixel rendered screenshot comparison cannot be claimed. Source-level UI has been aligned to the supplied reference and syntax/brace checks were performed on the modified Kotlin screens.
