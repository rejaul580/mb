# MBC ERP — Google Sheets Shared ERP

Architecture:
Android App → Google Apps Script Web App → Google Sheets

Shared modules:
Users, Customers, Products, Sales, Expenses, Payments, Due, Cash,
Production, Assets, Partners, Settings, AuditLog.

The app can keep Room for offline storage and sync cloud records using stable IDs and timestamps.
