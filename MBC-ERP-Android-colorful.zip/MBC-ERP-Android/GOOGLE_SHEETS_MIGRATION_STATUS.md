# Google Sheets migration status

This package removes the previous cloud database implementation and replaces it with Google Sheets + Google Apps Script.

## Fixed (2026-08-25): push was silently failing
`GoogleSheetsGateway.upsert()` used a default `OkHttpClient()`, which auto-follows HTTP
redirects. Google Apps Script `/exec` URLs answer with a redirect, and standard HTTP
client behavior downgrades the follow-up request from POST to GET, dropping the body
(entity/payload/token). The app only checked the HTTP status code, not the JSON `ok`
field, so this failure was invisible: data saved locally, never reached the sheet, no
error shown. Fixed by disabling auto-redirect-follow, manually re-issuing the same
method + body to the `Location` header, and validating the response body's `ok` field.
See `app/src/main/java/com/mbcerp/cloud/GoogleSheetsGateway.kt`.

## Shared now (push on create/update + pull on startup/background/manual sync)
- Customers, Sales, Expenses
- Partners, Majhis, Brick Types, Equipment, Expense Categories
- Company Profile (singleton, key `company-profile`)
- Production, Asset Register
- Customer/Partner Extra Payments, Old Due Collections
- Diesel Issues, Coal Usages, Equipment Working Hours
- Cash Summary manual adjustments (keyed by season)
- Offline Room cache remains active; every module above has a stable `syncId`
  (added in Room migration 3→4 for the modules that didn't already have one)
  to prevent cross-device duplicate rows

## Intentionally NOT shared
- **Local PIN users** (`AppUserEntity`) — PIN hashes/salts must never leave the device.
- **Weather cache / alert settings** — per-device cache, not shared ERP data.

## Notes
- Old Due Collections previously had no UI entry point at all (only the one-time Excel
  importer wrote to it) — `CashSummaryRepository.addOldDueCollection()` now exists and
  pushes to Sheets, ready for a UI to call it whenever one is added.
- Append-only ledgers (Old Due Collections, Extra Payments, Diesel/Coal/Working-Hours
  logs, Production, Assets) are pulled with insert-if-not-present-locally merge logic,
  since there's no edit UI for them yet.
- Because of the Room schema change (new `syncId` columns), the app database version
  bumped 3 → 4 with a real `Migration` (not destructive), so existing installs keep
  their data.

## Required before APK build
1. Deploy `cloud/google-apps-script/Code.gs` as a Google Apps Script Web App.
2. Put its `/exec` URL into `GoogleSheetsConfig.WEB_APP_URL`.
3. Optionally configure `API_TOKEN` on both sides.
4. Build with the included GitHub Actions workflow.
