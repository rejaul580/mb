package com.mbcerp.auth

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.mbcerp.data.dao.AppUserDao
import com.mbcerp.data.entity.AppUserEntity
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/**
 * AUTHENTICATION ARCHITECTURE (Decision D4).
 *
 * Phase 1 scope: single-device, offline-first app. There is no backend server, so
 * "authentication" here means a local PIN/passcode lock that protects the ERP data if
 * the phone is lost or shared, plus a lightweight ROLE field (OWNER / MANAGER / VIEWER)
 * that the UI can use to hide sensitive screens (e.g. Cash Summary, Setup) from a
 * VIEWER-role user, even though everyone shares the same on-device database.
 *
 * This is intentionally NOT a full multi-user account system: it does not gate data by
 * user, and it is not designed to resist a sophisticated on-device attacker (no
 * server-side verification is possible without a network). It exists to answer the
 * concrete Phase-1 need: "don't let a random person who picks up the phone see the
 * business's cash and due figures."
 *
 * Storage: EncryptedSharedPreferences (Android Keystore-backed) holds the login-session
 * flag; the PIN hash + per-user salt live in the app_users Room table (never store a
 * plaintext PIN). SHA-256 + random 16-byte salt is used rather than a full KDF like
 * bcrypt/Argon2 because a 4-6 digit local PIN's brute-force space is inherently small
 * regardless of hash cost, and this keeps Phase 1 free of a new native dependency.
 *
 * Migration path to real multi-user / cloud auth (documented for Phase 2+, per Decision
 * D4's "leave the door open" requirement): swap AuthManager's Room-backed check for a
 * Repository-layer call to a remote auth API; UI (LoginViewModel) does not need to change.
 */
class AuthManager(
    private val context: Context,
    private val appUserDao: AppUserDao
) {
    private val masterKey by lazy {
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    }

    private val prefs by lazy {
        EncryptedSharedPreferences.create(
            context,
            "mbc_erp_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    suspend fun isFirstRun(): Boolean = appUserDao.countActiveUsers() == 0

    /**
     * The single local user's username, for the normal (non-first-run) login screen.
     * Phase 1 is single-device/single-owner, so the login screen never asks for a
     * username again after setup -- it must look up whatever username was chosen
     * during createOwnerAccount(), never assume it's still "owner".
     */
    suspend fun getStoredUsername(): String? = appUserDao.getPrimaryUsername()

    /** Called once, on first app launch, to set up the owner's PIN. */
    suspend fun createOwnerAccount(username: String, pin: String) {
        val salt = randomSalt()
        val hash = hashPin(pin, salt)
        appUserDao.insert(
            AppUserEntity(username = username, pinHash = hash, salt = salt, role = "OWNER")
        )
        // Bug fix: account creation must also start the session, and persist it,
        // exactly like a normal login does -- otherwise isLoggedIn() stays false,
        // the very next app restart drops back to a login screen, and (combined with
        // the username lookup fix above) that is what previously made a correct PIN
        // get rejected as "wrong" the *second* time it was entered.
        prefs.edit().putBoolean(KEY_LOGGED_IN, true).putString(KEY_CURRENT_USER, username).apply()
    }

    suspend fun login(username: String, pin: String): Boolean {
        val user = appUserDao.findByUsername(username) ?: return false
        val candidateHash = hashPin(pin, user.salt)
        val ok = constantTimeEquals(candidateHash, user.pinHash)
        if (ok) prefs.edit().putBoolean(KEY_LOGGED_IN, true).putString(KEY_CURRENT_USER, username).apply()
        return ok
    }

    fun logout() {
        prefs.edit().clear().apply()
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_LOGGED_IN, false)
    fun currentUsername(): String? = prefs.getString(KEY_CURRENT_USER, null)

    private fun randomSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.getEncoder().encodeToString(bytes)
    }

    private fun hashPin(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(Base64.getDecoder().decode(salt))
        val hashed = digest.digest(pin.toByteArray(Charsets.UTF_8))
        return Base64.getEncoder().encodeToString(hashed)
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var result = 0
        for (i in a.indices) result = result or (a[i].code xor b[i].code)
        return result == 0
    }

    companion object {
        private const val KEY_LOGGED_IN = "logged_in"
        private const val KEY_CURRENT_USER = "current_user"
    }
}
