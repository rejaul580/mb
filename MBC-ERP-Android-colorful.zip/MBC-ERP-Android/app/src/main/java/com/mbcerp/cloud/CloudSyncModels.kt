package com.mbcerp.cloud

import org.json.JSONObject

data class CloudRecord(
    val entity: String,
    val recordKey: String,
    val payload: JSONObject,
    val updatedAt: String,
    val version: Long,
    val deviceId: String? = null
)

/** Contract used by the local repositories. Actual network calls are intentionally isolated here. */
interface CloudSyncGateway {
    suspend fun push(record: CloudRecord, expectedVersion: Long?): Result<CloudRecord>
    suspend fun pull(entity: String, sinceIso: String?): Result<List<CloudRecord>>
}
