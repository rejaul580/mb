package com.mbcerp.cloud

import com.mbcerp.data.entity.AssetRegisterEntity
import com.mbcerp.data.entity.BrickTypeEntity
import com.mbcerp.data.entity.CashSummaryAdjustmentEntity
import com.mbcerp.data.entity.CoalUsageEntity
import com.mbcerp.data.entity.CompanyProfileEntity
import com.mbcerp.data.entity.CustomerEntity
import com.mbcerp.data.entity.CustomerExtraPaymentEntity
import com.mbcerp.data.entity.DieselIssueEntity
import com.mbcerp.data.entity.EquipmentEntity
import com.mbcerp.data.entity.EquipmentWorkingHourEntity
import com.mbcerp.data.entity.ExpenseCategoryEntity
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.data.entity.MajhiEntity
import com.mbcerp.data.entity.OldDueCollectionEntity
import com.mbcerp.data.entity.PartnerEntity
import com.mbcerp.data.entity.PartnerExtraPaymentEntity
import com.mbcerp.data.entity.ProductionEntryEntity
import com.mbcerp.data.entity.SaleEntity
import org.json.JSONObject

fun SaleEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("voucherNo", voucherNo)
    put("truckNo", truckNo); put("partyType", partyType); put("partyName", partyName)
    put("location", location); put("sideParty", sideParty); put("sidePartyMobile", sidePartyMobile)
    put("brickCategory", brickCategory); put("quantity", quantity); put("rate", rate); put("amount", amount)
    put("advancePayment", advancePayment); put("cashReceived", cashReceived); put("remarks", remarks)
    put("saleType", saleType); put("createdAt", createdAt); put("updatedAt", updatedAt); put("isDeleted", isDeleted)
}

fun ExpenseEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("voucherNo", voucherNo)
    put("category", category); put("partyPaidTo", partyPaidTo); put("quantity", quantity); put("unit", unit)
    put("rate", rate); put("amount", amount); put("paidCash", paidCash); put("remarks", remarks)
    put("paymentMethod", paymentMethod); put("createdAt", createdAt); put("updatedAt", updatedAt); put("isDeleted", isDeleted)
}

fun CustomerEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("name", name); put("openingDue", openingDue); put("mobile", mobile); put("isActive", isActive)
}

fun PartnerEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("name", name); put("capital", capital)
    put("shareAnna", shareAnna); put("openingDue", openingDue); put("mobile", mobile); put("isActive", isActive)
}

fun MajhiEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("name", name); put("isActive", isActive)
}

fun BrickTypeEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("category", category); put("rate", rate)
    put("unitSize", unitSize); put("unitDescription", unitDescription); put("sortOrder", sortOrder)
}

fun EquipmentEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("name", name); put("type", type)
    put("hourlyRate", hourlyRate); put("driverName", driverName); put("isActive", isActive)
}

fun ExpenseCategoryEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("category", category); put("sortOrder", sortOrder); put("isActive", isActive)
}

fun CompanyProfileEntity.toCloudJson() = JSONObject().apply {
    put("name", name); put("season", season); put("address", address); put("phones", phones); put("tagline", tagline)
    put("openingCapital", openingCapital); put("customerOpeningDueTotal", customerOpeningDueTotal)
    put("dueBaselineDate", dueBaselineDate); put("defaultDamagePercent", defaultDamagePercent)
    put("seasonEndOverridePercent", seasonEndOverridePercent)
}

fun CashSummaryAdjustmentEntity.toCloudJson() = JSONObject().apply {
    put("season", season); put("seasonFixedAdjustment", seasonFixedAdjustment)
    put("advanceExpenseNextYear", advanceExpenseNextYear); put("coalRelatedDeposit", coalRelatedDeposit)
    put("priorYearDueReturn", priorYearDueReturn); put("oldDueStartingPool", oldDueStartingPool)
    put("forwardDue", forwardDue); put("otherAdjustments", otherAdjustments)
}

fun OldDueCollectionEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("name", name); put("amount", amount)
    put("remarks", remarks); put("isDeleted", isDeleted)
}

fun CustomerExtraPaymentEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("customerName", customerName)
    put("amount", amount); put("remarks", remarks); put("isDeleted", isDeleted)
}

fun PartnerExtraPaymentEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("partnerName", partnerName)
    put("amount", amount); put("remarks", remarks); put("isDeleted", isDeleted)
}

fun DieselIssueEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("issuedTo", issuedTo)
    put("quantity", quantity); put("remarks", remarks); put("isDeleted", isDeleted)
}

fun CoalUsageEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("usedFor", usedFor)
    put("quantity", quantity); put("remarks", remarks); put("isDeleted", isDeleted)
}

fun EquipmentWorkingHourEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("equipmentName", equipmentName)
    put("hours", hours); put("rate", rate); put("remarks", remarks); put("isDeleted", isDeleted)
}

fun ProductionEntryEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("serialRef", serialRef)
    put("majhiName", majhiName); put("type", type); put("rawBricksCounted", rawBricksCounted)
    put("loadedToKiln", loadedToKiln); put("unloadedFiredOut", unloadedFiredOut)
    put("remarks", remarks); put("isDeleted", isDeleted)
}

fun AssetRegisterEntity.toCloudJson() = JSONObject().apply {
    put("syncId", syncId); put("id", id); put("date", date); put("assetType", assetType)
    put("description", description); put("location", location); put("area", area); put("unit", unit)
    put("purchaseAmount", purchaseAmount); put("documentRef", documentRef); put("owners", owners)
    put("remarks", remarks); put("isDeleted", isDeleted)
}

fun JSONObject.toSaleEntity(localId: Long = 0) = SaleEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), voucherNo = optString("voucherNo").ifBlank { null },
    truckNo = optString("truckNo").ifBlank { null }, partyType = getString("partyType"), partyName = getString("partyName"),
    location = optString("location").ifBlank { null }, sideParty = optString("sideParty").ifBlank { null },
    sidePartyMobile = optString("sidePartyMobile").ifBlank { null }, brickCategory = getString("brickCategory"),
    quantity = optDouble("quantity", 0.0), rate = optDouble("rate", 0.0), amount = optDouble("amount", 0.0),
    advancePayment = optDouble("advancePayment", 0.0), cashReceived = optDouble("cashReceived", 0.0),
    remarks = optString("remarks").ifBlank { null }, saleType = optString("saleType").ifBlank { null },
    createdAt = optLong("createdAt", System.currentTimeMillis()), updatedAt = optLong("updatedAt", System.currentTimeMillis()),
    isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toExpenseEntity(localId: Long = 0) = ExpenseEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), voucherNo = optString("voucherNo").ifBlank { null },
    category = getString("category"), partyPaidTo = optString("partyPaidTo").ifBlank { null }, quantity = optDouble("quantity", 0.0),
    unit = optString("unit").ifBlank { null }, rate = optDouble("rate", 0.0), amount = optDouble("amount", 0.0),
    paidCash = optDouble("paidCash", 0.0), remarks = optString("remarks").ifBlank { null },
    paymentMethod = optString("paymentMethod").ifBlank { null }, createdAt = optLong("createdAt", System.currentTimeMillis()),
    updatedAt = optLong("updatedAt", System.currentTimeMillis()), isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toCustomerEntity(localId: Long = 0) = CustomerEntity(
    id = localId, syncId = getString("syncId"), name = getString("name"), openingDue = optDouble("openingDue", 0.0),
    mobile = optString("mobile").ifBlank { null }, isActive = optBoolean("isActive", true)
)

fun JSONObject.toPartnerEntity(localId: Long = 0) = PartnerEntity(
    id = localId, syncId = getString("syncId"), name = getString("name"), capital = optDouble("capital", 0.0),
    shareAnna = optDouble("shareAnna", 0.0), openingDue = optDouble("openingDue", 0.0),
    mobile = optString("mobile").ifBlank { null }, isActive = optBoolean("isActive", true)
)

fun JSONObject.toMajhiEntity(localId: Long = 0) = MajhiEntity(
    id = localId, syncId = getString("syncId"), name = getString("name"), isActive = optBoolean("isActive", true)
)

fun JSONObject.toBrickTypeEntity(localId: Long = 0) = BrickTypeEntity(
    id = localId, syncId = getString("syncId"), category = getString("category"), rate = optDouble("rate", 0.0),
    unitSize = if (has("unitSize") && !isNull("unitSize")) optDouble("unitSize") else null,
    unitDescription = optString("unitDescription").ifBlank { null }, sortOrder = optInt("sortOrder", 0)
)

fun JSONObject.toEquipmentEntity(localId: Long = 0) = EquipmentEntity(
    id = localId, syncId = getString("syncId"), name = getString("name"), type = getString("type"),
    hourlyRate = optDouble("hourlyRate", 0.0), driverName = optString("driverName").ifBlank { null },
    isActive = optBoolean("isActive", true)
)

fun JSONObject.toExpenseCategoryEntity(localId: Long = 0) = ExpenseCategoryEntity(
    id = localId, syncId = getString("syncId"), category = getString("category"), sortOrder = optInt("sortOrder", 0),
    isActive = optBoolean("isActive", true)
)

fun JSONObject.toCashSummaryAdjustmentEntity() = CashSummaryAdjustmentEntity(
    season = getString("season"), seasonFixedAdjustment = optDouble("seasonFixedAdjustment", 0.0),
    advanceExpenseNextYear = optDouble("advanceExpenseNextYear", 0.0), coalRelatedDeposit = optDouble("coalRelatedDeposit", 0.0),
    priorYearDueReturn = optDouble("priorYearDueReturn", 0.0), oldDueStartingPool = optDouble("oldDueStartingPool", 0.0),
    forwardDue = optDouble("forwardDue", 0.0), otherAdjustments = optDouble("otherAdjustments", 0.0)
)

fun JSONObject.toOldDueCollectionEntity(localId: Long = 0) = OldDueCollectionEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), name = getString("name"),
    amount = optDouble("amount", 0.0), remarks = optString("remarks").ifBlank { null }, isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toCustomerExtraPaymentEntity(localId: Long = 0) = CustomerExtraPaymentEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), customerName = getString("customerName"),
    amount = optDouble("amount", 0.0), remarks = optString("remarks").ifBlank { null }, isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toPartnerExtraPaymentEntity(localId: Long = 0) = PartnerExtraPaymentEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), partnerName = getString("partnerName"),
    amount = optDouble("amount", 0.0), remarks = optString("remarks").ifBlank { null }, isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toDieselIssueEntity(localId: Long = 0) = DieselIssueEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), issuedTo = optString("issuedTo").ifBlank { null },
    quantity = optDouble("quantity", 0.0), remarks = optString("remarks").ifBlank { null }, isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toCoalUsageEntity(localId: Long = 0) = CoalUsageEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), usedFor = optString("usedFor").ifBlank { null },
    quantity = optDouble("quantity", 0.0), remarks = optString("remarks").ifBlank { null }, isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toEquipmentWorkingHourEntity(localId: Long = 0) = EquipmentWorkingHourEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), equipmentName = getString("equipmentName"),
    hours = optDouble("hours", 0.0), rate = optDouble("rate", 0.0), remarks = optString("remarks").ifBlank { null },
    isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toProductionEntryEntity(localId: Long = 0) = ProductionEntryEntity(
    id = localId, syncId = getString("syncId"), date = getString("date"), serialRef = optString("serialRef").ifBlank { null },
    majhiName = optString("majhiName").ifBlank { null }, type = optString("type").ifBlank { null },
    rawBricksCounted = optDouble("rawBricksCounted", 0.0), loadedToKiln = optDouble("loadedToKiln", 0.0),
    unloadedFiredOut = optDouble("unloadedFiredOut", 0.0), remarks = optString("remarks").ifBlank { null },
    isDeleted = optBoolean("isDeleted", false)
)

fun JSONObject.toAssetRegisterEntity(localId: Long = 0) = AssetRegisterEntity(
    id = localId, syncId = getString("syncId"), date = optString("date").ifBlank { null },
    assetType = optString("assetType").ifBlank { null }, description = optString("description").ifBlank { null },
    location = optString("location").ifBlank { null },
    area = if (has("area") && !isNull("area")) optDouble("area") else null,
    unit = optString("unit").ifBlank { null }, purchaseAmount = optDouble("purchaseAmount", 0.0),
    documentRef = optString("documentRef").ifBlank { null }, owners = optString("owners").ifBlank { null },
    remarks = optString("remarks").ifBlank { null }, isDeleted = optBoolean("isDeleted", false)
)
