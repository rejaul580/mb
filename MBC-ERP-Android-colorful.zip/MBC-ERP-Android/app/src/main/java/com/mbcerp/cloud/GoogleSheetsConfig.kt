package com.mbcerp.cloud

/** Configure this URL after deploying cloud/google-apps-script/Code.gs as a Web App. */
object GoogleSheetsConfig {
    const val WEB_APP_URL = "https://script.google.com/macros/s/AKfycbweSQ2JJSznVe_UwID936z3Y5IOmycKOWtKIQCKllt9JRbEf1PtJyBnyyXAJFK-GmBc/exec"
    const val API_TOKEN = ""
    val CONNECTED = WEB_APP_URL.startsWith("https://")
}
