package com.mbcerp.cloud

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import android.util.Log

/**
 * Google Sheets transport used for the shared Google Sheets backend.
 * The Apps Script Web App owns the spreadsheet; the Android app never receives
 * a Google service-account key.
 *
 * IMPORTANT: Google Apps Script /exec URLs respond to requests with an HTTP redirect
 * to a script.googleusercontent.com URL that actually serves the result. A plain
 * OkHttpClient() follows that redirect automatically -- but per standard HTTP client
 * behavior it downgrades the follow-up request from POST to GET and drops the body.
 * That silently turns every "upsert" push into a bodyless GET, which Code.gs answers
 * with {ok:false, error:"Missing entity"} while still returning HTTP 200. The old code
 * only checked response.isSuccessful (the HTTP status), so that failure was swallowed
 * and treated as a success -- data saved locally, never reached the sheet, no error
 * shown anywhere. Fixed by disabling auto-redirect-follow and manually re-issuing the
 * *same* method + body to the Location header, and by validating the "ok" field in the
 * JSON body instead of trusting the HTTP status alone.
 */
class GoogleSheetsGateway(
    private val url: String = GoogleSheetsConfig.WEB_APP_URL,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(false)
        .followSslRedirects(false)
        .build()
) {
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    /** Executes [request] and, if the server responds with a redirect, manually re-issues
     *  the identical request (same method + body) against the Location header instead of
     *  letting OkHttp auto-follow it and silently downgrade POST to GET. */
    private fun executeFollowingRedirect(request: Request): Response {
        var current = request
        var response = client.newCall(current).execute()
        var hops = 0
        while (response.isRedirect && hops < 5) {
            val location = response.header("Location") ?: break
            response.close()
            current = current.newBuilder().url(location).build()
            response = client.newCall(current).execute()
            hops++
        }
        return response
    }

    suspend fun upsert(entity: String, recordKey: String, payload: JSONObject): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(GoogleSheetsConfig.CONNECTED) { "Google Sheets URL is not configured." }
            val body = JSONObject().apply {
                put("action", "upsert")
                put("entity", entity)
                put("recordKey", recordKey)
                put("payload", payload)
                put("token", GoogleSheetsConfig.API_TOKEN)
            }
            val request = Request.Builder().url(url).post(body.toString().toRequestBody(jsonType)).build()
            executeFollowingRedirect(request).use { response ->
                check(response.isSuccessful) { "Google Sheets HTTP ${response.code}" }
                val bodyStr = response.body?.string().orEmpty()
                val root = runCatching { JSONObject(bodyStr) }.getOrNull()
                check(root != null && root.optBoolean("ok", false)) {
                    "Google Sheets push rejected: ${root?.optString("error") ?: bodyStr.take(200)}"
                }
            }
        }.onFailure { Log.w("GoogleSheetsGateway", "upsert($entity, $recordKey) failed: ${it.message}") }
    }

    suspend fun pull(entity: String): Result<List<JSONObject>> = withContext(Dispatchers.IO) {
        runCatching {
            require(GoogleSheetsConfig.CONNECTED) { "Google Sheets URL is not configured." }
            val request = Request.Builder().url("$url?action=pull&entity=$entity&token=${java.net.URLEncoder.encode(GoogleSheetsConfig.API_TOKEN, "UTF-8")}").get().build()
            executeFollowingRedirect(request).use { response ->
                check(response.isSuccessful) { "Google Sheets HTTP ${response.code}" }
                val root = JSONObject(response.body?.string().orEmpty())
                check(root.optBoolean("ok", false)) { "Google Sheets pull rejected: ${root.optString("error")}" }
                val rows = root.optJSONArray("records") ?: JSONArray()
                buildList { for (i in 0 until rows.length()) add(rows.getJSONObject(i)) }
            }
        }.onFailure { Log.w("GoogleSheetsGateway", "pull($entity) failed: ${it.message}") }
    }
}
