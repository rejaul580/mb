package com.mbcerp.cloud

import com.mbcerp.data.db.AppDatabase

/**
 * Pulls every entity that is pushed by the repositories (see Repositories.kt) back down
 * and merges it into the local Room cache, keyed by the entity's stable `syncId` so the
 * same record updates in place instead of duplicating across devices.
 *
 * Intentionally NOT pulled: AppUserEntity (local PIN auth must never sync) and the Weather
 * cache/settings tables (per-device, not shared ERP data).
 */
class GoogleSheetsSyncManager(
    private val database: AppDatabase,
    private val gateway: GoogleSheetsGateway
) {
    suspend fun pullSharedData(): Result<Unit> = runCatching {
        syncCustomers()
        syncSales()
        syncExpenses()
        syncPartners()
        syncMajhis()
        syncBrickTypes()
        syncEquipment()
        syncExpenseCategories()
        syncCompanyProfile()
        syncCashSummaryAdjustments()
        syncOldDueCollections()
        syncCustomerExtraPayments()
        syncPartnerExtraPayments()
        syncDieselIssues()
        syncCoalUsages()
        syncEquipmentWorkingHours()
        syncProduction()
        syncAssets()
    }

    private suspend fun syncCustomers() {
        gateway.pull("Customers").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toCustomerEntity()
            val local = database.customerDao().findBySyncId(incoming.syncId)
            if (local == null) database.customerDao().insert(incoming)
            else database.customerDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncSales() {
        gateway.pull("Sales").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toSaleEntity()
            val local = database.saleDao().findBySyncId(incoming.syncId)
            if (local == null) database.saleDao().insert(incoming)
            else database.saleDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncExpenses() {
        gateway.pull("Expenses").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toExpenseEntity()
            val local = database.expenseDao().findBySyncId(incoming.syncId)
            if (local == null) database.expenseDao().insert(incoming)
            else database.expenseDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncPartners() {
        gateway.pull("Partners").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toPartnerEntity()
            val local = database.partnerDao().findBySyncId(incoming.syncId)
            if (local == null) database.partnerDao().insert(incoming)
            else database.partnerDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncMajhis() {
        gateway.pull("Majhis").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toMajhiEntity()
            val local = database.majhiDao().findBySyncId(incoming.syncId)
            if (local == null) database.majhiDao().insert(incoming)
            else database.majhiDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncBrickTypes() {
        gateway.pull("BrickTypes").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toBrickTypeEntity()
            val local = database.brickTypeDao().findBySyncId(incoming.syncId)
            if (local == null) database.brickTypeDao().insert(incoming)
            else database.brickTypeDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncEquipment() {
        gateway.pull("Equipment").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toEquipmentEntity()
            val local = database.equipmentDao().findBySyncId(incoming.syncId)
            if (local == null) database.equipmentDao().insert(incoming)
            else database.equipmentDao().update(incoming.copy(id = local.id))
        }
    }

    private suspend fun syncExpenseCategories() {
        gateway.pull("ExpenseCategories").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toExpenseCategoryEntity()
            val local = database.expenseCategoryDao().findBySyncId(incoming.syncId)
            if (local == null) database.expenseCategoryDao().insert(incoming)
            else database.expenseCategoryDao().update(incoming.copy(id = local.id))
        }
    }

    /** Singleton row (fixed key "company-profile"); only merges in if a local profile
     *  already exists, since first-run profile creation stays a local Setup-screen action. */
    private suspend fun syncCompanyProfile() {
        val rows = gateway.pull("CompanyProfile").getOrThrow()
        val payload = rows.firstOrNull()?.getJSONObject("payload") ?: return
        val current = database.companyProfileDao().get() ?: return
        database.companyProfileDao().upsert(
            current.copy(
                name = payload.optString("name", current.name),
                season = payload.optString("season", current.season),
                address = payload.optString("address").ifBlank { current.address },
                phones = payload.optString("phones").ifBlank { current.phones },
                tagline = payload.optString("tagline").ifBlank { current.tagline },
                openingCapital = payload.optDouble("openingCapital", current.openingCapital),
                customerOpeningDueTotal = payload.optDouble("customerOpeningDueTotal", current.customerOpeningDueTotal),
                dueBaselineDate = payload.optString("dueBaselineDate").ifBlank { current.dueBaselineDate },
                defaultDamagePercent = payload.optDouble("defaultDamagePercent", current.defaultDamagePercent)
            )
        )
    }

    private suspend fun syncCashSummaryAdjustments() {
        gateway.pull("CashSummaryAdjustments").getOrThrow().forEach { row ->
            database.cashSummaryAdjustmentDao().upsert(row.getJSONObject("payload").toCashSummaryAdjustmentEntity())
        }
    }

    private suspend fun syncOldDueCollections() {
        gateway.pull("OldDueCollections").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toOldDueCollectionEntity()
            if (database.oldDueCollectionDao().findBySyncId(incoming.syncId) == null) {
                database.oldDueCollectionDao().insert(incoming)
            }
        }
    }

    private suspend fun syncCustomerExtraPayments() {
        gateway.pull("CustomerExtraPayments").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toCustomerExtraPaymentEntity()
            if (database.extraPaymentDao().findCustomerPaymentBySyncId(incoming.syncId) == null) {
                database.extraPaymentDao().insertCustomerPayment(incoming)
            }
        }
    }

    private suspend fun syncPartnerExtraPayments() {
        gateway.pull("PartnerExtraPayments").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toPartnerExtraPaymentEntity()
            if (database.extraPaymentDao().findPartnerPaymentBySyncId(incoming.syncId) == null) {
                database.extraPaymentDao().insertPartnerPayment(incoming)
            }
        }
    }

    private suspend fun syncDieselIssues() {
        gateway.pull("DieselIssues").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toDieselIssueEntity()
            if (database.stockDao().findDieselIssueBySyncId(incoming.syncId) == null) {
                database.stockDao().insertDieselIssue(incoming)
            }
        }
    }

    private suspend fun syncCoalUsages() {
        gateway.pull("CoalUsages").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toCoalUsageEntity()
            if (database.stockDao().findCoalUsageBySyncId(incoming.syncId) == null) {
                database.stockDao().insertCoalUsage(incoming)
            }
        }
    }

    private suspend fun syncEquipmentWorkingHours() {
        gateway.pull("EquipmentWorkingHours").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toEquipmentWorkingHourEntity()
            if (database.stockDao().findWorkingHourBySyncId(incoming.syncId) == null) {
                database.stockDao().insertWorkingHour(incoming)
            }
        }
    }

    private suspend fun syncProduction() {
        gateway.pull("Production").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toProductionEntryEntity()
            if (database.productionDao().findBySyncId(incoming.syncId) == null) {
                database.productionDao().insert(incoming)
            }
        }
    }

    private suspend fun syncAssets() {
        gateway.pull("Assets").getOrThrow().forEach { row ->
            val incoming = row.getJSONObject("payload").toAssetRegisterEntity()
            if (database.assetRegisterDao().findBySyncId(incoming.syncId) == null) {
                database.assetRegisterDao().insert(incoming)
            }
        }
    }
}
