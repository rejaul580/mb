package com.mbcerp.cloud

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.mbcerp.MbcErpApp

class GoogleSheetsSyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        if (!GoogleSheetsConfig.CONNECTED) return Result.success()
        val app = applicationContext as MbcErpApp
        return app.googleSheetsSyncManager.pullSharedData().fold(
            onSuccess = { Result.success() },
            onFailure = { Result.retry() }
        )
    }
}
