package com.mbcerp.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * SALES REGISTER (AUDIT REPORT §2.2). This is the single central transaction table —
 * Customer Ledger, Partner Ledger, Dashboard, Cash Summary, Delivery Challan and
 * Production Register are all derived VIEWS/queries over this table (Pattern 3 in the
 * audit, "Filtered-Row Puller" — no separate physical tables for those screens).
 *
 * IMPORTANT (fidelity to source): column K (amount), L (advance), M (cashReceived) are
 * *manual, plain values* in the original Excel — NOT formulas. Column N (due) IS a
 * formula (`=K-L-M`) and is therefore NOT stored here; it is always computed on read
 * (see FormulaPatterns.calcSalesDue) exactly like Excel recalculates it live.
 */
@Entity(
    tableName = "sales",
    indices = [Index("date"), Index("partyType", "partyName"), Index("voucherNo")]
)
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String,                 // ISO yyyy-MM-dd
    val voucherNo: String? = null,
    val truckNo: String? = null,
    val partyType: String,            // "Customer" | "Partner"
    val partyName: String,
    val location: String? = null,
    val sideParty: String? = null,
    /** Reserved field flagged in AUDIT §9 Q1 (header/formula mismatch in source col T).
     *  Kept nullable; not populated by the Excel migration since no reliable source data exists. */
    val sidePartyMobile: String? = null,
    val brickCategory: String,
    val quantity: Double = 0.0,
    val rate: Double = 0.0,           // snapshot of BrickType.rate at entry time (Pattern 1)
    val amount: Double = 0.0,         // manual value, not qty*rate (matches Excel behaviour exactly)
    val advancePayment: Double = 0.0,
    val cashReceived: Double = 0.0,   // Entry-Guide rule: sign carries meaning, +in / -out
    val remarks: String? = null,
    val saleType: String? = null,     // null | "Regular Sale" | "Advance Sale"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isDeleted: Boolean = false
)

/**
 * EXPENSE REGISTER (AUDIT REPORT §2.3). Second central transaction table. Diesel/Coal
 * Register, Majhi Ledger, Equipment Register, Expense Summary, Ledger Viewer, and all
 * 41 HL_ hidden-sheet categories are derived queries filtered by `category` — see
 * AUDIT §7.4 / DECISIONS.md D-none (structural decision already covered in audit).
 */
@Entity(
    tableName = "expenses",
    indices = [Index("date"), Index("category"), Index("partyPaidTo"), Index("voucherNo")]
)
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String,
    val voucherNo: String? = null,
    val category: String,
    val partyPaidTo: String? = null,  // equipment name, majhi name, or free text
    val quantity: Double = 0.0,
    val unit: String? = null,
    val rate: Double = 0.0,
    val amount: Double = 0.0,
    val paidCash: Double = 0.0,       // duePayable = amount - paidCash, computed on read
    val remarks: String? = null,
    val paymentMethod: String? = null, // "Cash" | "Bank" | "Others"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val isDeleted: Boolean = false
)

@Entity(tableName = "customer_extra_payments")
data class CustomerExtraPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String,
    val customerName: String,
    val amount: Double,
    val remarks: String? = null,
    val isDeleted: Boolean = false
)

@Entity(tableName = "partner_extra_payments")
data class PartnerExtraPaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String,
    val partnerName: String,
    val amount: Double,
    val remarks: String? = null,
    val isDeleted: Boolean = false
)

@Entity(tableName = "diesel_issues")
data class DieselIssueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String,
    val issuedTo: String? = null, // equipment or majhi name
    val quantity: Double,
    val remarks: String? = null,
    val isDeleted: Boolean = false
)

@Entity(tableName = "coal_usages")
data class CoalUsageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String,
    val usedFor: String? = null,
    val quantity: Double,
    val remarks: String? = null,
    val isDeleted: Boolean = false
)

@Entity(tableName = "equipment_working_hours")
data class EquipmentWorkingHourEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String,
    val equipmentName: String,
    val hours: Double,
    val rate: Double = 0.0,
    val remarks: String? = null,
    val isDeleted: Boolean = false
)

@Entity(tableName = "production_entries")
data class ProductionEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String,
    val serialRef: String? = null,
    val majhiName: String? = null,
    val type: String? = null, // "Manual" | "Auto"
    val rawBricksCounted: Double = 0.0,
    val loadedToKiln: Double = 0.0,
    val unloadedFiredOut: Double = 0.0,
    val remarks: String? = null,
    val isDeleted: Boolean = false
)

@Entity(tableName = "asset_register")
data class AssetRegisterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @androidx.room.ColumnInfo(defaultValue = "") val syncId: String = java.util.UUID.randomUUID().toString(),
    val date: String? = null,
    val assetType: String? = null,
    val description: String? = null,
    val location: String? = null,
    val area: Double? = null,
    val unit: String? = null,
    val purchaseAmount: Double = 0.0,
    val documentRef: String? = null,
    val owners: String? = null,
    val remarks: String? = null,
    val isDeleted: Boolean = false
)
