package com.mbcerp.ui.asset

import androidx.compose.ui.res.stringResource

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.AssetRegisterEntity
import com.mbcerp.repository.AssetRegisterRepository
import com.mbcerp.ui.common.EmptyState
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

/** ASSET REGISTER (AUDIT §2.10). Manual-entry only -- no auto cross-sheet sync, matches source. */
class AssetRegisterViewModel(private val repo: AssetRegisterRepository) : ViewModel() {
    val entries = repo.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun addEntry(e: AssetRegisterEntity) = viewModelScope.launch { repo.addEntry(e) }
}

class AssetRegisterViewModelFactory(private val repo: AssetRegisterRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = AssetRegisterViewModel(repo) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssetRegisterScreen(vm: AssetRegisterViewModel) {
    val entries by vm.entries.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = AppBlack,
        topBar = { TopAppBar(title = { Text("Asset Register (${entries.size})", color = TextPrimary, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBlack, titleContentColor = TextPrimary)) },
        floatingActionButton = { FloatingActionButton(onClick = { showDialog = true }, containerColor = LimeAccent, contentColor = androidx.compose.ui.graphics.Color.Black) { Icon(Icons.Default.Add, contentDescription = "Add") } }
    ) { padding ->
        if (entries.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize()) {
                EmptyState(Icons.Default.Domain, "কোনো Asset এন্ট্রি নেই", "নিচের + বাটনে চাপ দিয়ে জমি/সম্পত্তির তথ্য যোগ করুন")
            }
        } else {
            LazyColumn(Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
                items(entries) { e ->
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = AppSurface2),
                        border = androidx.compose.foundation.BorderStroke(1.dp, LimeAccent.copy(alpha = .35f)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            ColorBadge(Icons.Default.Domain, LimeAccent, size = 36.dp, iconSize = 18.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(e.description ?: e.assetType ?: "-", style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "${e.date ?: "-"}  •  ${e.assetType ?: "-"}  •  ৳${"%,.2f".format(e.purchaseAmount)}",
                                    style = MaterialTheme.typography.bodyMedium, color = LimeAccent
                                )
                                Text(e.location ?: "-", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        var date by remember { mutableStateOf(LocalDate.now().toString()) }
        var assetType by remember { mutableStateOf("Land") }
        var description by remember { mutableStateOf("") }
        var location by remember { mutableStateOf("") }
        var amount by remember { mutableStateOf("0") }
        var owners by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("নতুন Asset Entry") },
            text = {
                Column {
                    OutlinedTextField(date, { date = it }, label = { Text("Date") })
                    OutlinedTextField(assetType, { assetType = it }, label = { Text("Asset Type") })
                    OutlinedTextField(description, { description = it }, label = { Text("Description") })
                    OutlinedTextField(location, { location = it }, label = { Text("Location") })
                    OutlinedTextField(amount, { amount = it }, label = { Text("Purchase Amount") })
                    OutlinedTextField(owners, { owners = it }, label = { Text("Owners") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.addEntry(
                        AssetRegisterEntity(
                            date = date, assetType = assetType, description = description.ifBlank { null },
                            location = location.ifBlank { null }, purchaseAmount = amount.toDoubleOrNull() ?: 0.0,
                            owners = owners.ifBlank { null }
                        )
                    )
                    showDialog = false
                }) { Text(stringResource(com.mbcerp.R.string.action_add)) }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}
