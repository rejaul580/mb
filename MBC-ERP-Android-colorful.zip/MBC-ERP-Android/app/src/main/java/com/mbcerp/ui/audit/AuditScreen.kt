package com.mbcerp.ui.audit

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.domain.calc.ValidationEngine
import com.mbcerp.repository.AuditRepository
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/** AUDIT / VALIDATION SCREEN (AUDIT §2.11 "Audit Sheet"). Self-diagnostic only -- creates no data. */
class AuditViewModel(private val auditRepository: AuditRepository) : ViewModel() {
    private val _results = MutableStateFlow<List<ValidationEngine.AuditResult>>(emptyList())
    val results: StateFlow<List<ValidationEngine.AuditResult>> = _results
    private val _checking = MutableStateFlow(false)
    val checking: StateFlow<Boolean> = _checking

    fun runChecks() = viewModelScope.launch {
        _checking.value = true
        _results.value = auditRepository.runAllChecks()
        _checking.value = false
    }
}

class AuditViewModelFactory(private val auditRepository: AuditRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = AuditViewModel(auditRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditScreen(vm: AuditViewModel) {
    val results by vm.results.collectAsState()
    val checking by vm.checking.collectAsState()
    LaunchedEffect(Unit) { vm.runChecks() }

    Scaffold(containerColor = AppBlack, topBar = { TopAppBar(title = { Text("Audit / Validation", color = TextPrimary, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBlack, titleContentColor = TextPrimary)) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            val failCount = results.count { !it.ok }
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(
                    containerColor = if (failCount == 0) SuccessGreen.copy(alpha = .16f) else ErrorRed.copy(alpha = .16f)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (failCount == 0) SuccessGreen.copy(alpha = .4f) else ErrorRed.copy(alpha = .4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    ColorBadge(
                        if (failCount == 0) Icons.Default.CheckCircle else Icons.Default.Error,
                        if (failCount == 0) SuccessGreen else ErrorRed,
                        size = 40.dp, iconSize = 22.dp
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            if (failCount == 0) "সব চেক পাশ" else "$failCount টা চেক-এ সমস্যা",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (failCount == 0) SuccessGreen else ErrorRed,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                        )
                        Text(
                            "${results.size} টা check চালানো হয়েছে",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(results) { r ->
                    Card(
                        shape = MaterialTheme.shapes.medium,
                        colors = CardDefaults.cardColors(containerColor = AppSurface2),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (r.ok) SuccessGreen.copy(alpha = .3f) else ErrorRed.copy(alpha = .4f)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                            leadingContent = { ColorBadge(if (r.ok) Icons.Default.CheckCircle else Icons.Default.Error, if (r.ok) SuccessGreen else ErrorRed, size = 34.dp, iconSize = 18.dp) },
                            headlineContent = { Text(r.check, color = TextPrimary) },
                            supportingContent = r.detail?.let { { Text(it, color = TextSecondary) } }
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { vm.runChecks() }, enabled = !checking, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = PinkAccent, contentColor = androidx.compose.ui.graphics.Color.White)) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (checking) "চেক করা হচ্ছে…" else "Re-run Checks")
            }
        }
    }
}
