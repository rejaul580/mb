package com.mbcerp.ui.auth

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.House
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.auth.AuthManager
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

// ---- Reference-design palette (matches the approved "MBC Bricks" login mock) ----
private val MbcNavy = Color(0xFF0B2447)
private val MbcNavyDeep = Color(0xFF071A33)
private val MbcRed = Color(0xFFB3161B)
private val MbcRedBright = Color(0xFFE0221F)
private val MbcSky = Color(0xFF6EC1EE)
private val MbcSkyLight = Color(0xFFCFEBFB)
private val MbcFieldBg = Color(0xFFF3F5F7)
private val MbcMuted = Color(0xFF7C8A9A)

/**
 * NOTE on fidelity to the reference image: this environment has no network access, so the
 * photographic chimney/brick-yard background in the mock can't be downloaded or embedded --
 * it's redrawn here as vector art (sky gradient, chimney, brick stacks) in the same palette
 * and composition instead. Everything else (layout, colors, copy, card structure, bottom
 * feature strip) follows the reference 1:1.
 *
 * Business logic (LoginViewModel / AuthManager, PIN-based single-device auth) is UNCHANGED --
 * only this Composable UI was redesigned. The "Password" field below is still the app's PIN,
 * just now shown as a masked text field with a show/hide eye icon (like the mock) instead of
 * the old dot-indicator + numpad. "Select Company" has no real target yet (the app is
 * single-company / single-device), so it's kept as a static branded pill rather than a fake
 * dropdown that does nothing.
 */
class LoginViewModel(private val authManager: AuthManager) : ViewModel() {
    private val _isFirstRun = MutableStateFlow<Boolean?>(null)
    val isFirstRun: StateFlow<Boolean?> = _isFirstRun
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _success = MutableStateFlow(false)
    val success: StateFlow<Boolean> = _success
    // Bug fix (kept from previous patch): the login screen must use the actual saved
    // username, never a hardcoded "owner" -- otherwise a correct PIN can get rejected
    // as "wrong" on every login after the first one.
    private val _storedUsername = MutableStateFlow<String?>(null)
    val storedUsername: StateFlow<String?> = _storedUsername

    fun checkFirstRun() = viewModelScope.launch {
        val firstRun = authManager.isFirstRun()
        _isFirstRun.value = firstRun
        if (!firstRun) _storedUsername.value = authManager.getStoredUsername()
    }
    fun createOwner(username: String, pin: String, confirmPin: String) = viewModelScope.launch {
        _error.value = null
        if (pin.length < 4) { _error.value = "PIN কমপক্ষে ৪ সংখ্যার হতে হবে"; return@launch }
        if (pin != confirmPin) { _error.value = "PIN দুটো মিলছে না"; return@launch }
        authManager.createOwnerAccount(username, pin); _success.value = true
    }
    fun login(username: String, pin: String) = viewModelScope.launch {
        _error.value = null
        if (authManager.login(username, pin)) _success.value = true else _error.value = "ভুল Username বা PIN"
    }
}

class LoginViewModelFactory(private val authManager: AuthManager) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = LoginViewModel(authManager) as T
}

@Composable
fun LoginScreen(vm: LoginViewModel, onLoggedIn: () -> Unit) {
    val isFirstRun by vm.isFirstRun.collectAsState()
    val storedUsername by vm.storedUsername.collectAsState()
    val error by vm.error.collectAsState()
    val success by vm.success.collectAsState()
    LaunchedEffect(Unit) { vm.checkFirstRun() }
    LaunchedEffect(success) { if (success) onLoggedIn() }

    var username by remember(storedUsername) { mutableStateOf(storedUsername ?: "owner") }
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var pinVisible by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(true) }

    Box(Modifier.fillMaxSize().background(Color.White)) {

        Column(Modifier.fillMaxSize()) {
            // ---- Top brand / brick-factory backdrop ----
            Box(Modifier.fillMaxWidth().weight(1f)) {
                FactoryBackdrop(Modifier.fillMaxSize())
                Column(
                    Modifier.fillMaxWidth().padding(top = 34.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "MBC", color = MbcRed, fontSize = 58.sp, fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.width(26.dp).height(3.dp).background(MbcRed))
                        Text(
                            "  BRICKS  ", color = MbcNavy, fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp
                        )
                        Box(Modifier.width(26.dp).height(3.dp).background(MbcRed))
                    }
                    Spacer(Modifier.height(10.dp))
                    Surface(shape = RoundedCornerShape(20.dp), color = MbcNavy) {
                        Text(
                            "ইট ভাটা, রাউজান", color = Color.White, fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 9.dp)
                        )
                    }
                }
            }

            // ---- White login card ----
            Surface(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
                color = Color.White,
                shadowElevation = 10.dp
            ) {
                Column(Modifier.padding(horizontal = 22.dp, vertical = 24.dp)) {
                    Text(
                        "Welcome Back", color = MbcNavy, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
                    )
                    Text(
                        if (isFirstRun == true) "Create your Owner account" else "Login to your account",
                        color = MbcMuted, fontSize = 13.sp,
                        modifier = Modifier.fillMaxWidth().padding(top = 2.dp), textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(20.dp))

                    BrandedField(
                        value = username, onValue = { username = it },
                        placeholder = "User Name", leadingIcon = Icons.Default.Person
                    )
                    Spacer(Modifier.height(13.dp))
                    BrandedField(
                        value = pin, onValue = { pin = it.filter(Char::isDigit).take(8) },
                        placeholder = "Password", leadingIcon = Icons.Default.Lock,
                        isPassword = true, visible = pinVisible, onToggleVisible = { pinVisible = !pinVisible },
                        keyboardType = KeyboardType.NumberPassword
                    )

                    if (isFirstRun == true) {
                        Spacer(Modifier.height(13.dp))
                        BrandedField(
                            value = confirmPin, onValue = { confirmPin = it.filter(Char::isDigit).take(8) },
                            placeholder = "Confirm Password", leadingIcon = Icons.Default.Lock,
                            isPassword = true, visible = pinVisible, onToggleVisible = { pinVisible = !pinVisible },
                            keyboardType = KeyboardType.NumberPassword
                        )
                    }

                    Spacer(Modifier.height(12.dp))
                    Row(
                        Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = rememberMe, onCheckedChange = { rememberMe = it },
                                colors = CheckboxDefaults.colors(checkedColor = MbcNavy)
                            )
                            Text("Remember Me", color = MbcNavy, fontSize = 12.sp)
                        }
                        Text(
                            "Forgot Password?", color = MbcNavy, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { /* not wired to any flow yet */ }
                        )
                    }

                    error?.let {
                        Spacer(Modifier.height(10.dp))
                        Text(it, color = MbcRedBright, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    }

                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = {
                            if (isFirstRun == true) vm.createOwner(username, pin, confirmPin)
                            else vm.login(username, pin)
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(26.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MbcRed)
                    ) {
                        Text(
                            if (isFirstRun == true) "CREATE OWNER" else "LOGIN",
                            fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, letterSpacing = 1.sp
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        HorizontalDivider(Modifier.weight(1f), color = MbcMuted.copy(alpha = .3f))
                        Text("  OR  ", color = MbcMuted, fontSize = 12.sp)
                        HorizontalDivider(Modifier.weight(1f), color = MbcMuted.copy(alpha = .3f))
                    }
                    Spacer(Modifier.height(16.dp))

                    // Single-company app -- shown as a static branded pill, not a working
                    // dropdown, since there is nothing else to select yet.
                    OutlinedButton(
                        onClick = { }, enabled = false,
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MbcNavy, disabledContentColor = MbcNavy
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MbcMuted.copy(alpha = .35f))
                    ) {
                        Icon(Icons.Default.House, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("MBC Bricks — ইট ভাটা, রাউজান", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            // ---- Bottom navy feature strip ----
            Box(Modifier.fillMaxWidth().background(MbcNavyDeep)) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 18.dp, horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    FeatureIcon(Icons.Default.Layers, "Premium\nQuality Bricks")
                    FeatureIcon(Icons.Default.Shield, "Strong &\nDurable")
                    FeatureIcon(Icons.Default.Eco, "Eco\nFriendly")
                }
            }
        }
    }
}

@Composable
private fun FactoryBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        // Sky
        drawRect(Brush.verticalGradient(listOf(MbcSky, MbcSkyLight)), size = size)
        // Sun glow
        drawCircle(Color.White.copy(alpha = .35f), radius = size.minDimension * .4f, center = Offset(size.width * .15f, size.height * .12f))

        // Ground / brick yard
        val groundTop = size.height * .74f
        drawRect(Brush.verticalGradient(listOf(BrickOrangeDark.copy(alpha = .85f), BrickOrangeDark)), topLeft = Offset(0f, groundTop), size = Size(size.width, size.height - groundTop))

        // Chimney
        val chimneyX = size.width * .74f
        val chimneyW = size.width * .07f
        val chimneyTop = size.height * .06f
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(BrickOrangeBright, BrickOrangeDark)),
            topLeft = Offset(chimneyX - chimneyW / 2f, chimneyTop),
            size = Size(chimneyW, groundTop - chimneyTop),
            cornerRadius = CornerRadius(4f, 4f)
        )
        val bandCount = 5
        repeat(bandCount) { i ->
            val y = chimneyTop + (groundTop - chimneyTop) * (i + 1f) / (bandCount + 1f)
            drawRect(Color.White.copy(alpha = .8f), topLeft = Offset(chimneyX - chimneyW / 2f, y), size = Size(chimneyW, chimneyW * .22f))
        }

        // Brick stacks silhouette across the yard
        val brickW = size.width * .09f
        val brickH = brickW * .55f
        val rows = 3
        (0 until 6).forEach { col ->
            val baseX = size.width * .02f + col * (brickW * 1.05f)
            repeat(rows) { row ->
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(BrickOrangeBright, BrickOrangeDark)),
                    topLeft = Offset(baseX, groundTop - (row + 1) * brickH * .92f),
                    size = Size(brickW, brickH),
                    cornerRadius = CornerRadius(3f, 3f)
                )
            }
        }
    }
}

@Composable
private fun FeatureIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = .08f))
                .border(1.dp, Color.White.copy(alpha = .25f), CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 10.sp, textAlign = TextAlign.Center, lineHeight = 12.sp)
    }
}

@Composable
private fun BrandedField(
    value: String,
    onValue: (String) -> Unit,
    placeholder: String,
    leadingIcon: androidx.compose.ui.graphics.vector.ImageVector,
    isPassword: Boolean = false,
    visible: Boolean = false,
    onToggleVisible: (() -> Unit)? = null,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        singleLine = true,
        placeholder = { Text(placeholder, color = MbcMuted, fontSize = 14.sp) },
        leadingIcon = {
            Box(
                Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(MbcNavy),
                contentAlignment = Alignment.Center
            ) { Icon(leadingIcon, null, tint = Color.White, modifier = Modifier.size(15.dp)) }
        },
        trailingIcon = if (isPassword && onToggleVisible != null) {
            {
                IconButton(onClick = onToggleVisible) {
                    Icon(if (visible) Icons.Default.Visibility else Icons.Default.VisibilityOff, null, tint = MbcMuted)
                }
            }
        } else null,
        visualTransformation = if (isPassword && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth().height(58.dp),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MbcNavy, unfocusedBorderColor = Color.Transparent,
            focusedTextColor = MbcNavy, unfocusedTextColor = MbcNavy,
            focusedContainerColor = MbcFieldBg, unfocusedContainerColor = MbcFieldBg,
            cursorColor = MbcNavy
        )
    )
}
