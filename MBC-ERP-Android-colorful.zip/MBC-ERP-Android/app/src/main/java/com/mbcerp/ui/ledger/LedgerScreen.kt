package com.mbcerp.ui.ledger

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.domain.calc.DueCalculator
import com.mbcerp.repository.LedgerRepository
import com.mbcerp.repository.SetupRepository
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * CUSTOMER / PARTNER LEDGER SCREEN. One shared screen for both party types.
 *
 * D-quirk-1 (fully resolved, see DueCalculator.kt doc comment): Partner Due uses one
 * consistent formula everywhere. Customer Due genuinely differs between the source
 * file's two screens -- this UI shows BOTH figures explicitly, with a visible warning
 * whenever they disagree, instead of silently picking one (per "do not change the
 * original Excel logic").
 */
class LedgerViewModel(
    private val ledgerRepository: LedgerRepository,
    private val setupRepository: SetupRepository
) : ViewModel() {

    val customers = setupRepository.observeCustomers().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val partners = setupRepository.observePartners().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _customerSummary = MutableStateFlow<DueCalculator.CustomerDueSummary?>(null)
    val customerSummary: StateFlow<DueCalculator.CustomerDueSummary?> = _customerSummary

    private val _partnerSummary = MutableStateFlow<DueCalculator.PartnerDueSummary?>(null)
    val partnerSummary: StateFlow<DueCalculator.PartnerDueSummary?> = _partnerSummary

    private val _allPartnerDues = MutableStateFlow<List<DueCalculator.PartnerDueSummary>>(emptyList())
    val allPartnerDues: StateFlow<List<DueCalculator.PartnerDueSummary>> = _allPartnerDues

    fun selectCustomer(name: String) {
        viewModelScope.launch { _customerSummary.value = ledgerRepository.customerDue(name) }
    }

    fun selectPartner(name: String) {
        viewModelScope.launch { _partnerSummary.value = ledgerRepository.partnerDue(name) }
    }

    fun loadAllPartnerDues() {
        viewModelScope.launch { _allPartnerDues.value = ledgerRepository.allPartnerDues() }
    }
}

class LedgerViewModelFactory(
    private val ledgerRepository: LedgerRepository,
    private val setupRepository: SetupRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = LedgerViewModel(ledgerRepository, setupRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LedgerScreen(vm: LedgerViewModel) {
    var partyType by remember { mutableStateOf("Customer") }
    val customers by vm.customers.collectAsState()
    val partners by vm.partners.collectAsState()
    val customerSummary by vm.customerSummary.collectAsState()
    val partnerSummary by vm.partnerSummary.collectAsState()
    val allPartnerDues by vm.allPartnerDues.collectAsState()
    var expanded by remember { mutableStateOf(false) }
    var selectedName by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { vm.loadAllPartnerDues() }

    Scaffold(containerColor = AppBlack, topBar = { TopAppBar(title = { Text("Customer / Partner Ledger", color = TextPrimary, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBlack, titleContentColor = TextPrimary)) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Row {
                FilterChip(selected = partyType == "Customer", onClick = { partyType = "Customer"; selectedName = "" }, label = { Text("Customer") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = partyType == "Partner", onClick = { partyType = "Partner"; selectedName = "" }, label = { Text("Partner") })
            }
            Spacer(Modifier.height(8.dp))
            val names = if (partyType == "Partner") partners.map { it.name } else customers.map { it.name }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = selectedName, onValueChange = {}, readOnly = true, label = { Text("নাম বাছুন") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    names.forEach { n ->
                        DropdownMenuItem(text = { Text(n) }, onClick = {
                            selectedName = n; expanded = false
                            if (partyType == "Partner") vm.selectPartner(n) else vm.selectCustomer(n)
                        })
                    }
                }
            }

            if (partyType == "Customer") {
                customerSummary?.let { s ->
                    Spacer(Modifier.height(16.dp))
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = AppSurface2), border = androidx.compose.foundation.BorderStroke(1.dp, InfoBlue.copy(alpha = .35f))) {
                        Column(Modifier.padding(12.dp)) {
                            Text(s.customerName, style = MaterialTheme.typography.titleMedium, color = InfoBlue, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                            Text("Total Sales (all-time): ৳${"%,.2f".format(s.totalSalesAllTime)}")
                            Text("Received at Sale (all-time): ৳${"%,.2f".format(s.receivedAtSaleAllTime)}")
                            Text("Extra Payment: ৳${"%,.2f".format(s.extraPayment)}")
                            Text("Opening Due (Setup): ৳${"%,.2f".format(s.openingDue)}")
                            Divider(Modifier.padding(vertical = 6.dp))
                            Text(
                                "প্রকৃত বকেয়া (সঠিক হিসাব): ৳${"%,.2f".format(s.totalDueDetailScreen)}",
                                style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary
                            )
                            Text("(= মোট বিক্রয় − মোট গৃহীত টাকা − Extra Payment, সব লেনদেন ধরে)", style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "পুরনো Excel-এর 'All-Customer-List' কলামে যা দেখাত: ৳${"%,.2f".format(s.totalDueAllListScreen)}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text("(= শুধু Opening Due − Extra Payment; Sales Register-এর প্রকৃত বিক্রয়/পরিশোধ একদমই ধরে না)", style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "নোট: মূল Excel ফাইলে এই দুই কলাম ভিন্ন সংখ্যা দেখাত — এটা বিরল কোনো ব্যতিক্রম নয়, " +
                                "যাদের Setup-এ Opening Due লেখা নেই (বেশিরভাগ কাস্টমার) তাদের ক্ষেত্রে এটা সবসময় ঘটে। " +
                                "App এখানে দুটোই যাচাইকৃতভাবে অবিকল দেখাচ্ছে, কিন্তু 'প্রকৃত বকেয়া' লেখা সংখ্যাটাই " +
                                "প্রকৃত হিসাবের জন্য ব্যবহার করা উচিত।",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }
                }
            }

            if (partyType == "Partner") {
                partnerSummary?.let { s ->
                    Spacer(Modifier.height(16.dp))
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = AppSurface2), border = androidx.compose.foundation.BorderStroke(1.dp, InfoBlue.copy(alpha = .35f))) {
                        Column(Modifier.padding(12.dp)) {
                            Text(s.partnerName, style = MaterialTheme.typography.titleMedium, color = InfoBlue, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                            Text("Total Sales: ৳${"%,.2f".format(s.totalSales)}")
                            Text("Received at Sale: ৳${"%,.2f".format(s.receivedAtSaleAllTime)}")
                            Text("Extra Payment: ৳${"%,.2f".format(s.extraPayment)}")
                            Text("Total Due: ৳${"%,.2f".format(s.totalDue)}", style = MaterialTheme.typography.titleMedium, color = WarningAmber, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("সব Partner-এর Due (Total: ৳${"%,.2f".format(allPartnerDues.sumOf { it.totalDue })})", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                LazyColumn(Modifier.fillMaxWidth()) {
                    items(allPartnerDues) { p ->
                        ListItem(
                            headlineContent = { Text(p.partnerName) },
                            leadingContent = { ColorBadgeSoft(Icons.Default.Groups, InfoBlue) },
                            supportingContent = { Text("Due: ৳${"%,.2f".format(p.totalDue)}", color = WarningAmber) }
                        )
                        Divider()
                    }
                }
            }
        }
    }
}
