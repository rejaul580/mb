package com.mbcerp.ui.registers

import androidx.compose.ui.res.stringResource

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Build
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.data.entity.ExpenseEntity
import com.mbcerp.domain.calc.StockCalculator
import com.mbcerp.repository.RegisterRepository
import com.mbcerp.repository.SetupRepository
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

/**
 * DIESEL / COAL / MAJHI / EQUIPMENT REGISTER SCREEN (AUDIT §2.5, §2.6). Excel had 4
 * nearly-identical sheets for this; here it's one tab-based screen driving the same
 * RegisterRepository queries -- exactly mirroring the "filtered-row-puller" pattern
 * (AUDIT §4.1 Pattern 3) that made those 4 sheets structurally interchangeable.
 *
 * Diesel/Coal Issue and Equipment Working-Hours entry dialogs added so those three
 * mini-ledger tables (previously write-only from Excel migration / external export/import
 * restore, with no in-app way to add a new entry) are now actually usable day-to-day.
 */
class RegistersViewModel(
    private val registerRepository: RegisterRepository,
    private val setupRepository: SetupRepository
) : ViewModel() {

    val majhis = registerRepository.observeMajhis().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val equipment = registerRepository.observeEquipment().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _dieselStock = MutableStateFlow<StockCalculator.StockResult?>(null)
    val dieselStock: StateFlow<StockCalculator.StockResult?> = _dieselStock
    private val _dieselRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val dieselRows: StateFlow<List<ExpenseEntity>> = _dieselRows

    private val _coalStock = MutableStateFlow<StockCalculator.StockResult?>(null)
    val coalStock: StateFlow<StockCalculator.StockResult?> = _coalStock
    private val _coalRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val coalRows: StateFlow<List<ExpenseEntity>> = _coalRows

    private val _majhiRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val majhiRows: StateFlow<List<ExpenseEntity>> = _majhiRows
    private val _majhiTotal = MutableStateFlow(0.0)
    val majhiTotal: StateFlow<Double> = _majhiTotal

    private val _equipRows = MutableStateFlow<List<ExpenseEntity>>(emptyList())
    val equipRows: StateFlow<List<ExpenseEntity>> = _equipRows
    private val _equipHours = MutableStateFlow(0.0)
    val equipHours: StateFlow<Double> = _equipHours
    private val _equipPaid = MutableStateFlow(0.0)
    val equipPaid: StateFlow<Double> = _equipPaid

    fun loadDiesel() = viewModelScope.launch {
        _dieselStock.value = registerRepository.dieselStock()
        _dieselRows.value = registerRepository.dieselPurchaseRows()
    }

    fun loadCoal() = viewModelScope.launch {
        _coalStock.value = registerRepository.coalStock()
        _coalRows.value = registerRepository.coalPurchaseRows()
    }

    fun loadMajhi(name: String) = viewModelScope.launch {
        _majhiRows.value = registerRepository.majhiLedgerRows(name)
        _majhiTotal.value = registerRepository.majhiTotalAdvance(name)
    }

    fun loadEquipment(name: String) = viewModelScope.launch {
        _equipRows.value = registerRepository.equipmentLedgerRows(name)
        _equipHours.value = registerRepository.equipmentTotalHours(name)
        _equipPaid.value = registerRepository.equipmentTotalPaid(name)
    }

    fun recordDieselIssue(date: String, issuedTo: String?, quantity: Double) = viewModelScope.launch {
        registerRepository.recordDieselIssue(date, issuedTo, quantity)
        loadDiesel()
    }

    fun recordCoalUsage(date: String, usedFor: String?, quantity: Double) = viewModelScope.launch {
        registerRepository.recordCoalUsage(date, usedFor, quantity)
        loadCoal()
    }

    fun recordWorkingHours(date: String, equipmentName: String, hours: Double) = viewModelScope.launch {
        registerRepository.recordWorkingHours(date, equipmentName, hours)
        loadEquipment(equipmentName)
    }
}

class RegistersViewModelFactory(
    private val registerRepository: RegisterRepository,
    private val setupRepository: SetupRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = RegistersViewModel(registerRepository, setupRepository) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistersScreen(vm: RegistersViewModel) {
    val tabs = listOf("Diesel", "Coal", "Majhi Ledger", "Equipment")
    var tab by remember { mutableStateOf(0) }

    Scaffold(containerColor = AppBlack, topBar = { TopAppBar(title = { Text("Diesel / Coal / Majhi / Equipment", color = TextPrimary, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBlack, titleContentColor = TextPrimary)) }) { padding ->
        Column(Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tab, containerColor = AppBlack, contentColor = WarningAmber) {
                tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }, selectedContentColor = WarningAmber, unselectedContentColor = TextSecondary) }
            }
            when (tab) {
                0 -> DieselTab(vm)
                1 -> CoalTab(vm)
                2 -> MajhiTab(vm)
                3 -> EquipmentTab(vm)
            }
        }
    }
}

@Composable
private fun DieselTab(vm: RegistersViewModel) {
    val stock by vm.dieselStock.collectAsState()
    val rows by vm.dieselRows.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadDiesel() }
    Column(Modifier.padding(12.dp)) {
        stock?.let {
            Card(colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = .14f)), border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = .4f))) {
                Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    ColorBadge(Icons.Default.LocalGasStation, WarningAmber, size = 36.dp, iconSize = 18.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Total Purchased: ${it.purchasedOrProduced} L", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        Text("Cost: ৳${it.totalCost}  |  Current Stock: ${it.currentStock} L", style = MaterialTheme.typography.titleSmall, color = WarningAmber, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { showDialog = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = WarningAmber, contentColor = androidx.compose.ui.graphics.Color.Black)) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Diesel Issue এন্ট্রি দিন (মেশিন/মাঝিকে দেওয়া)")
        }
        Spacer(Modifier.height(8.dp))
        Text("ক্রয়ের ইতিহাস (Expense Register থেকে)", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
        LazyColumn { items(rows) { r -> ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }, leadingContent = { ColorBadgeSoft(Icons.Default.LocalGasStation, WarningAmber) }, supportingContent = { Text(r.remarks ?: "") }); Divider() } }
    }
    if (showDialog) {
        IssueEntryDialog(
            title = "Diesel Issue", quantityLabel = "Liters", targetLabel = "কাকে/কোথায় (মেশিন/মাঝি)",
            onDismiss = { showDialog = false },
            onSave = { date, target, qty -> vm.recordDieselIssue(date, target, qty); showDialog = false }
        )
    }
}

@Composable
private fun CoalTab(vm: RegistersViewModel) {
    val stock by vm.coalStock.collectAsState()
    val rows by vm.coalRows.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadCoal() }
    Column(Modifier.padding(12.dp)) {
        stock?.let {
            Card(colors = CardDefaults.cardColors(containerColor = EmberGold.copy(alpha = .14f)), border = androidx.compose.foundation.BorderStroke(1.dp, EmberGold.copy(alpha = .4f))) {
                Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    ColorBadge(Icons.Default.LocalFireDepartment, EmberGold, size = 36.dp, iconSize = 18.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Total Purchased: ${it.purchasedOrProduced}", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        Text("Cost: ৳${it.totalCost}  |  Current Stock: ${it.currentStock}", style = MaterialTheme.typography.titleSmall, color = EmberGold, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { showDialog = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = EmberGold, contentColor = androidx.compose.ui.graphics.Color.Black)) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Coal Usage এন্ট্রি দিন")
        }
        Spacer(Modifier.height(8.dp))
        Text("ক্রয়ের ইতিহাস (Expense Register থেকে)", style = MaterialTheme.typography.titleSmall, color = TextPrimary)
        LazyColumn { items(rows) { r -> ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }, leadingContent = { ColorBadgeSoft(Icons.Default.LocalFireDepartment, EmberGold) }, supportingContent = { Text(r.remarks ?: "") }); Divider() } }
    }
    if (showDialog) {
        IssueEntryDialog(
            title = "Coal Usage", quantityLabel = "Quantity", targetLabel = "কোন কাজে ব্যবহার",
            onDismiss = { showDialog = false },
            onSave = { date, target, qty -> vm.recordCoalUsage(date, target, qty); showDialog = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MajhiTab(vm: RegistersViewModel) {
    val majhis by vm.majhis.collectAsState()
    val rows by vm.majhiRows.collectAsState()
    val total by vm.majhiTotal.collectAsState()
    var selected by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    Column(Modifier.padding(12.dp)) {
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(selected, {}, readOnly = true, label = { Text("Majhi বাছুন") }, modifier = Modifier.fillMaxWidth().menuAnchor())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                majhis.forEach { m -> DropdownMenuItem(text = { Text(m.name) }, onClick = { selected = m.name; expanded = false; vm.loadMajhi(m.name) }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Total Advance/Payment: ৳${"%,.2f".format(total)}", style = MaterialTheme.typography.titleSmall, color = VioletAccent, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Text("নোট: majhi advance এখানে informational -- season-শেষে ম্যানুয়ালি settle করা হয় (Excel-এর নিয়ম অনুযায়ী), Due-এর সাথে auto-deduct হয় না।", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        LazyColumn { items(rows) { r -> ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }, leadingContent = { ColorBadgeSoft(Icons.Default.Person, VioletAccent) }); Divider() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EquipmentTab(vm: RegistersViewModel) {
    val equipment by vm.equipment.collectAsState()
    val rows by vm.equipRows.collectAsState()
    val hours by vm.equipHours.collectAsState()
    val paid by vm.equipPaid.collectAsState()
    var selected by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var showHoursDialog by remember { mutableStateOf(false) }
    Column(Modifier.padding(12.dp)) {
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
            OutlinedTextField(selected, {}, readOnly = true, label = { Text("Equipment বাছুন") }, modifier = Modifier.fillMaxWidth().menuAnchor())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                equipment.forEach { e -> DropdownMenuItem(text = { Text(e.name) }, onClick = { selected = e.name; expanded = false; vm.loadEquipment(e.name) }) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Total Paid: ৳${"%,.2f".format(paid)}  |  Total Working Hours: $hours", style = MaterialTheme.typography.titleSmall, color = CyanAccent, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { if (selected.isNotBlank()) showHoursDialog = true },
            enabled = selected.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = androidx.compose.ui.graphics.Color.Black)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Working Hours এন্ট্রি দিন")
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn { items(rows) { r -> ListItem(headlineContent = { Text("${r.date}  ৳${r.amount}") }, leadingContent = { ColorBadgeSoft(Icons.Default.Build, CyanAccent) }); Divider() } }
    }
    if (showHoursDialog) {
        var date by remember { mutableStateOf(LocalDate.now().toString()) }
        var hoursInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showHoursDialog = false },
            title = { Text("Working Hours -- $selected") },
            text = {
                Column {
                    OutlinedTextField(date, { date = it }, label = { Text("Date") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(hoursInput, { hoursInput = it }, label = { Text("Hours") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.recordWorkingHours(date, selected, hoursInput.toDoubleOrNull() ?: 0.0)
                    showHoursDialog = false
                }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
            },
            dismissButton = { TextButton(onClick = { showHoursDialog = false }) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
        )
    }
}

@Composable
private fun IssueEntryDialog(
    title: String,
    quantityLabel: String,
    targetLabel: String,
    onDismiss: () -> Unit,
    onSave: (date: String, target: String?, quantity: Double) -> Unit
) {
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var target by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(date, { date = it }, label = { Text("Date") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(target, { target = it }, label = { Text(targetLabel) }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(quantity, { quantity = it }, label = { Text(quantityLabel) }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(date, target.ifBlank { null }, quantity.toDoubleOrNull() ?: 0.0) }) { Text(stringResource(com.mbcerp.R.string.action_save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(com.mbcerp.R.string.action_cancel)) } }
    )
}
