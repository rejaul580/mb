package com.mbcerp.ui.sales

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mbcerp.domain.entry.EntryMode
import com.mbcerp.domain.entry.SalesEntryInput
import java.time.LocalDate

/**
 * SALES ENTRY SCREEN (Phase 2). Directly implements the Entry Guide's guided-mode
 * pattern (AUDIT §6.1 / domain/entry/EntryGuideEngine.kt): the user first picks WHAT
 * KIND of transaction this is, and the form then shows only the relevant fields and
 * applies the correct +/- sign automatically -- removing the single biggest source of
 * data-entry error in the original spreadsheet (a clerk typing the wrong sign in
 * column M by hand).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesEntryScreen(vm: SalesEntryViewModel, onSaved: () -> Unit) {
    val customers by vm.customers.collectAsState()
    val partners by vm.partners.collectAsState()
    val brickTypes by vm.brickTypes.collectAsState()
    val result by vm.result.collectAsState()

    var mode by remember { mutableStateOf<EntryMode>(EntryMode.RegularSale) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var voucherNo by remember { mutableStateOf("") }
    var truckNo by remember { mutableStateOf("") }
    var partyType by remember { mutableStateOf("Customer") }
    var partyName by remember { mutableStateOf("") }
    var counterpartyName by remember { mutableStateOf("") }
    var brickCategory by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var cashAmount by remember { mutableStateOf("") }
    var remarks by remember { mutableStateOf("") }

    Scaffold(topBar = { TopAppBar(title = { Text("নতুন বিক্রয় এন্ট্রি") }) }) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("লেনদেনের ধরন বাছুন", style = MaterialTheme.typography.titleMedium)
            EntryMode.salesEntryModes.forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                    RadioButton(selected = mode == m, onClick = { mode = m })
                    Column {
                        Text(m.label, style = MaterialTheme.typography.bodyMedium)
                        Text(m.description, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            OutlinedTextField(date, { date = it }, label = { Text("Date (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(voucherNo, { voucherNo = it }, label = { Text("Voucher No") }, modifier = Modifier.fillMaxWidth())
            if (mode == EntryMode.RegularSale) {
                OutlinedTextField(truckNo, { truckNo = it }, label = { Text("Truck No") }, modifier = Modifier.fillMaxWidth())
            }

            Spacer(Modifier.height(8.dp))
            Text("Party", style = MaterialTheme.typography.titleSmall)
            Row {
                FilterChip(selected = partyType == "Customer", onClick = { partyType = "Customer" }, label = { Text("Customer") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = partyType == "Partner", onClick = { partyType = "Partner" }, label = { Text("Partner") })
            }
            val nameOptions = if (partyType == "Partner") partners.map { it.name } else customers.map { it.name }
            DropdownField("Party Name", partyName, nameOptions) { partyName = it }

            if (mode == EntryMode.DueTransferBetweenPartners) {
                DropdownField("দ্বিতীয় Partner (Counterparty)", counterpartyName, partners.map { it.name }) { counterpartyName = it }
            }

            if (mode == EntryMode.RegularSale) {
                Spacer(Modifier.height(8.dp))
                DropdownField("Brick Category", brickCategory, brickTypes.map { it.category }) { selected ->
                    brickCategory = selected
                    brickTypes.firstOrNull { it.category == selected }?.let { rate = it.rate.toString() }
                }
                OutlinedTextField(quantity, { quantity = it }, label = { Text("Quantity") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(rate, { rate = it }, label = { Text("Rate (auto-filled, editable)") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(amount, { amount = it }, label = { Text("Amount") }, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            }

            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                cashAmount, { cashAmount = it },
                label = { Text(cashLabelFor(mode)) },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                "সবসময় ধনাত্মক সংখ্যা লিখুন — সঠিক +/- চিহ্ন উপরের মোড অনুযায়ী নিজে থেকেই বসবে।",
                style = MaterialTheme.typography.bodySmall
            )

            OutlinedTextField(remarks, { remarks = it }, label = { Text("Remarks") }, modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(16.dp))
            when (val r = result) {
                is SalesEntryResult.Error -> Text(r.message, color = MaterialTheme.colorScheme.error)
                is SalesEntryResult.Success -> LaunchedEffect(r) { onSaved(); vm.resetResult() }
                else -> {}
            }

            Button(
                enabled = result !is SalesEntryResult.Saving,
                onClick = {
                    val input = SalesEntryInput(
                        mode = mode, date = date, voucherNo = voucherNo.ifBlank { null },
                        truckNo = truckNo.ifBlank { null }, partyType = partyType, partyName = partyName,
                        brickCategory = brickCategory.ifBlank { null },
                        quantity = quantity.toDoubleOrNull() ?: 0.0,
                        rate = rate.toDoubleOrNull() ?: 0.0,
                        amount = amount.toDoubleOrNull() ?: 0.0,
                        cashAmount = cashAmount.toDoubleOrNull() ?: 0.0,
                        remarks = remarks.ifBlank { null }
                    )
                    vm.submit(input, counterpartyName.ifBlank { null })
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text(if (result is SalesEntryResult.Saving) "Saving…" else "Save") }
        }
    }
}

private fun cashLabelFor(mode: EntryMode): String = when (mode) {
    EntryMode.RegularSale -> "Cash Received (এখন হাতে পাওয়া টাকা, না পেলে 0)"
    EntryMode.PartnerDueSettlement -> "Amount Received (Due শোধ)"
    EntryMode.AdvanceToPartner -> "Amount Given (মাঠ থেকে দেওয়া)"
    EntryMode.AdvanceSale -> "Advance Amount"
    EntryMode.DueTransferBetweenPartners -> "Transfer Amount"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DropdownField(label: String, value: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    var query by remember(value) { mutableStateOf(value) }
    // Filters as the user types and caps the rendered list — with real production data
    // (hundreds of customers/partners) rendering every option in one non-lazy Column
    // inside ExposedDropdownMenu can freeze/crash the screen, so we only ever render
    // a bounded number of matches at once.
    val filtered = remember(query, options) {
        val matches = if (query.isBlank()) options else options.filter { it.contains(query, ignoreCase = true) }
        matches.take(40)
    }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it; onSelect(it); expanded = true },
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.fillMaxWidth().menuAnchor()
        )
        if (filtered.isNotEmpty()) {
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                filtered.forEach { opt ->
                    DropdownMenuItem(text = { Text(opt) }, onClick = { query = opt; onSelect(opt); expanded = false })
                }
                if (options.size > filtered.size) {
                    DropdownMenuItem(text = { Text("... আরও ${options.size - filtered.size} জন — খুঁজতে টাইপ করুন", color = MaterialTheme.colorScheme.outline) }, onClick = {}, enabled = false)
                }
            }
        }
    }
}
