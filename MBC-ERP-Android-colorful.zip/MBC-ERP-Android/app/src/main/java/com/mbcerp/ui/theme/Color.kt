package com.mbcerp.ui.theme

import androidx.compose.ui.graphics.Color

// MBC ERP premium palette — switched to a forest-green brand identity.
val BrickOrange = Color(0xFF1E8A54)
val BrickOrangeBright = Color(0xFF2ECC71)
val BrickOrangeDark = Color(0xFF115C36)
val EmberGold = Color(0xFFFFB23E)
val AppBlack = Color(0xFF05090C)
val AppSurface = Color(0xFF0B1217)
val AppSurface2 = Color(0xFF111A20)
val AppSurface3 = Color(0xFF172229)
val AppStroke = Color(0xFF25343D)
val TextPrimary = Color(0xFFF7F9FA)
val TextSecondary = Color(0xFF9BAAB3)
val SuccessGreen = Color(0xFF35C98B)
val WarningAmber = Color(0xFFFFB020)
val ErrorRed = Color(0xFFFF5B5B)
val InfoBlue = Color(0xFF4DA3FF)
val VioletAccent = Color(0xFFA073FF)
val PinkAccent = Color(0xFFFF6FA3)
val CyanAccent = Color(0xFF2FD1D9)
val LimeAccent = Color(0xFFB9E23C)

// Compatibility names used by older screens.
val BrickPrimary = BrickOrange
val BrickOnPrimary = Color.White
val BrickPrimaryContainer = Color(0xFF4A1B0A)
val BrickOnPrimaryContainer = Color.White
val ClaySecondary = Color(0xFF53636D)
val ClayOnSecondary = Color.White
val ClaySecondaryContainer = AppSurface3
val ClayOnSecondaryContainer = TextPrimary
val EmberTertiary = EmberGold
val EmberOnTertiary = Color(0xFF241300)
val EmberTertiaryContainer = Color(0xFF4B3210)
val EmberOnTertiaryContainer = Color.White
val LightBackground = Color(0xFFF4F6F7)
val LightOnBackground = Color(0xFF11181D)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9EEF1)
val LightOnSurfaceVariant = Color(0xFF53636D)
val LightOutline = Color(0xFF9AA7AE)
val OnErrorRed = Color.White
val ErrorContainer = Color(0xFF4B1111)
val OnErrorContainer = Color.White
val SuccessContainer = Color(0xFF123F30)
val BrickPrimaryDark = BrickOrange
val BrickOnPrimaryDark = Color.White
val BrickPrimaryContainerDark = Color(0xFF4A1B0A)
val BrickOnPrimaryContainerDark = Color.White
val ClaySecondaryDark = Color(0xFFAFC0C9)
val ClayOnSecondaryDark = Color(0xFF102027)
val ClaySecondaryContainerDark = AppSurface3
val ClayOnSecondaryContainerDark = TextPrimary
val DarkBackground = AppBlack
val DarkOnBackground = TextPrimary
val DarkSurface = AppSurface
val DarkSurfaceVariant = AppSurface3
val DarkOnSurfaceVariant = TextSecondary
val DarkOutline = AppStroke
