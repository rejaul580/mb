package com.mbcerp.ui.theme

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * A vivid, colorful circular icon badge — solid accent-colored background with a
 * white glyph. Shared across the app (Dashboard, More menu, list rows, dialogs) so
 * every module gets a consistent, colorful identity instead of a flat mono icon.
 */
@Composable
fun ColorBadge(icon: ImageVector, accent: Color, size: Dp = 38.dp, iconSize: Dp = 20.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = .72f))))
            .border(1.dp, Color.White.copy(alpha = .18f), CircleShape),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(iconSize)) }
}

/** Softer, tinted variant (accent-on-tint) — used where a solid color would be too heavy. */
@Composable
fun ColorBadgeSoft(icon: ImageVector, accent: Color, size: Dp = 30.dp, iconSize: Dp = 16.dp) {
    Box(
        modifier = Modifier.size(size).clip(RoundedCornerShape(size / 2.8f)).background(accent.copy(alpha = .16f)),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(iconSize)) }
}

@Composable
fun PremiumPage(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().background(AppBlack).padding(horizontal = 14.dp, vertical = 8.dp), content = content)
}

@Composable
fun PremiumTopBar(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null, action: ImageVector? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) { Icon(Icons.Default.ArrowBack, null, tint = TextPrimary) }
            Spacer(Modifier.width(2.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            subtitle?.let { Text(it, color = TextSecondary, fontSize = 9.sp) }
        }
        if (action != null) IconButton(onClick = { onAction?.invoke() }, modifier = Modifier.size(40.dp)) { Icon(action, null, tint = TextPrimary) }
    }
}

@Composable
fun PremiumCard(modifier: Modifier = Modifier, accent: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(13.dp),
        colors = CardDefaults.cardColors(containerColor = if (accent) BrickOrangeDark else AppSurface2),
        border = BorderStroke(1.dp, if (accent) BrickOrange.copy(alpha = .55f) else AppStroke),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        content = { Column(Modifier.padding(13.dp), content = content) }
    )
}

@Composable
fun PremiumAmountCard(label: String, amount: String, modifier: Modifier = Modifier, negative: Boolean = false) {
    PremiumCard(modifier) {
        Text(label.uppercase(), color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text(amount, color = if (negative) ErrorRed else TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun PremiumDatePill(text: String, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(9.dp), color = AppSurface3, border = BorderStroke(1.dp, AppStroke)) {
        Text(text, color = TextPrimary, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp))
    }
}

@Composable
fun PremiumPrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(onClick, modifier.height(44.dp), shape = RoundedCornerShape(9.dp), colors = ButtonDefaults.buttonColors(containerColor = BrickOrange)) {
        Text(text, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}
