package com.mbcerp.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val MbcDarkColors = darkColorScheme(
    primary = BrickOrange,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4A1B0A),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFF8EA1AB),
    onSecondary = Color.White,
    secondaryContainer = AppSurface3,
    onSecondaryContainer = TextPrimary,
    tertiary = EmberGold,
    onTertiary = Color(0xFF241300),
    background = AppBlack,
    onBackground = TextPrimary,
    surface = AppSurface,
    onSurface = TextPrimary,
    surfaceVariant = AppSurface2,
    onSurfaceVariant = TextSecondary,
    outline = AppStroke,
    error = ErrorRed,
    onError = Color.White,
    errorContainer = Color(0xFF4B1111),
    onErrorContainer = Color.White
)

private val MbcLightColors = lightColorScheme(
    primary = BrickOrangeDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE1D2),
    onPrimaryContainer = Color(0xFF3B1100),
    secondary = Color(0xFF52646E),
    onSecondary = Color.White,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnBackground,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline,
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun MbcErpTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) MbcDarkColors else MbcLightColors
    val view = LocalView.current
    if (!view.isInEditMode) SideEffect {
        val window = (view.context as Activity).window
        window.statusBarColor = colors.background.toArgb()
        window.navigationBarColor = colors.background.toArgb()
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
    }
    MaterialTheme(colorScheme = colors, typography = MbcTypography, shapes = MbcShapes, content = content)
}
