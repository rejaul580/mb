package com.mbcerp.ui.weather

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mbcerp.weather.*
import com.mbcerp.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * WEATHER ALERT SETTINGS + STATUS SCREEN (item 5). Lets the owner turn the feature on,
 * set location/thresholds/lead-time, and run a manual "check now" (useful for testing
 * without waiting for the periodic worker). Shows the last cached forecast + risk
 * assessment with a staleness indicator when offline.
 */
class WeatherViewModel(private val weatherDao: WeatherDao) : ViewModel() {
    private val _settings = MutableStateFlow(WeatherAlertSettingsEntity())
    val settings: StateFlow<WeatherAlertSettingsEntity> = _settings

    private val _lastAssessment = MutableStateFlow<RainRiskCalculator.RiskAssessment?>(null)
    val lastAssessment: StateFlow<RainRiskCalculator.RiskAssessment?> = _lastAssessment

    private val _cacheAgeMinutes = MutableStateFlow<Long?>(null)
    val cacheAgeMinutes: StateFlow<Long?> = _cacheAgeMinutes

    private val _checking = MutableStateFlow(false)
    val checking: StateFlow<Boolean> = _checking

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun load() = viewModelScope.launch {
        _settings.value = weatherDao.getSettings() ?: WeatherAlertSettingsEntity()
        val cache = weatherDao.getCache()
        if (cache != null) {
            _cacheAgeMinutes.value = (System.currentTimeMillis() - cache.fetchedAtMillis) / 60_000
        }
    }

    fun saveSettings(s: WeatherAlertSettingsEntity) = viewModelScope.launch {
        weatherDao.saveSettings(s)
        _settings.value = s
    }

    /** Manual "check now" / pull-to-refresh -- runs the same fetch+assess logic as the
     *  background worker, directly on the UI's coroutine scope, so results show up
     *  immediately. Bug fix: this used to only update in-memory UI state, so the "last
     *  updated" cache was never actually saved -- reopening the screen (or the app)
     *  would show the old stale forecast again. Now it writes to WeatherCacheEntity via
     *  weatherDao.saveCache(), same as the background worker does, so a refresh here
     *  really does persist as the newest data. */
    fun checkNow(latitude: Double? = null, longitude: Double? = null) = viewModelScope.launch {
        _checking.value = true
        _error.value = null
        try {
            val s = _settings.value
            val lat = latitude ?: s.latitude
            val lon = longitude ?: s.longitude
            val client = WeatherApiClient()
            val forecast = client.fetchHourlyForecast(lat, lon)
            weatherDao.saveCache(
                WeatherCacheEntity(
                    fetchedAtMillis = System.currentTimeMillis(),
                    latitude = lat, longitude = lon,
                    forecastJson = WeatherForecastCodec.encode(forecast)
                )
            )
            val thresholds = RainRiskCalculator.Thresholds(s.probabilityThresholdPercent, s.heavyRainMm, s.leadTimeHours)
            _lastAssessment.value = RainRiskCalculator.assess(forecast, thresholds)
            _cacheAgeMinutes.value = 0
        } catch (e: Exception) {
            _error.value = "Fetch ব্যর্থ: ${e.message} (ইন্টারনেট সংযোগ চেক করুন)"
        } finally {
            _checking.value = false
        }
    }
}

/**
 * "Use my current location" -- reads the device's last-known GPS/network fix rather
 * than requesting a fresh live fix, so it returns instantly and needs no extra
 * Play-Services-location dependency. Caller must already hold ACCESS_FINE_LOCATION or
 * ACCESS_COARSE_LOCATION; returns null if no provider has a cached fix yet (e.g. GPS
 * has never gotten a lock on this device) or if location services are off.
 */
fun getLastKnownLocation(context: Context): android.location.Location? {
    val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
    var best: android.location.Location? = null
    for (provider in lm.allProviders) {
        val loc = try { lm.getLastKnownLocation(provider) } catch (e: SecurityException) { null } ?: continue
        if (best == null || loc.accuracy < best!!.accuracy) best = loc
    }
    return best
}

class WeatherViewModelFactory(private val weatherDao: WeatherDao) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = WeatherViewModel(weatherDao) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherScreen(vm: WeatherViewModel) {
    val settings by vm.settings.collectAsState()
    val assessment by vm.lastAssessment.collectAsState()
    val cacheAge by vm.cacheAgeMinutes.collectAsState()
    val checking by vm.checking.collectAsState()
    val error by vm.error.collectAsState()
    val context = LocalContext.current

    var enabled by remember(settings) { mutableStateOf(settings.enabled) }
    var lat by remember(settings) { mutableStateOf(settings.latitude.toString()) }
    var lon by remember(settings) { mutableStateOf(settings.longitude.toString()) }
    var prob by remember(settings) { mutableStateOf(settings.probabilityThresholdPercent.toString()) }
    var heavyMm by remember(settings) { mutableStateOf(settings.heavyRainMm.toString()) }
    var leadTime by remember(settings) { mutableStateOf(settings.leadTimeHours.toString()) }
    var interval by remember(settings) { mutableStateOf(settings.checkIntervalMinutes.toString()) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    var locatingNow by remember { mutableStateOf(false) }
    var locationError by remember { mutableStateOf<String?>(null) }
    fun useDeviceLocation() {
        val loc = getLastKnownLocation(context)
        if (loc != null) {
            lat = loc.latitude.toString()
            lon = loc.longitude.toString()
            locationError = null
        } else {
            locationError = "এই মুহূর্তে ডিভাইসের Location পাওয়া যায়নি -- Location/GPS চালু করে আবার চেষ্টা করুন।"
        }
        locatingNow = false
    }
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) useDeviceLocation()
        else {
            locatingNow = false
            locationError = "Location অনুমতি ছাড়া বর্তমান অবস্থান পাওয়া যাবে না -- চাইলে Latitude/Longitude হাতে লিখুন।"
        }
    }
    fun onUseLocationClick() {
        locatingNow = true
        locationError = null
        val fineGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fineGranted || coarseGranted) useDeviceLocation()
        else locationPermissionLauncher.launch(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        )
    }

    LaunchedEffect(Unit) { vm.load() }

    Scaffold(containerColor = AppBlack, topBar = { TopAppBar(title = { Text("Weather Alert", color = TextPrimary, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBlack, titleContentColor = TextPrimary)) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = enabled, onCheckedChange = { checked ->
                    enabled = checked
                    if (checked && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                        if (!granted) notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    // Turning the feature on also offers to fill in the location
                    // automatically, so the owner doesn't have to type lat/long by hand.
                    if (checked) {
                        onUseLocationClick()
                        WeatherAlertWorker.schedule(context, interval.toIntOrNull() ?: 60)
                    } else WeatherAlertWorker.cancel(context)
                })
                Text("Weather Alert চালু রাখুন (Background)")
            }

            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = { onUseLocationClick() },
                enabled = !locatingNow,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.MyLocation, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (locatingNow) "Location খোঁজা হচ্ছে…" else "বর্তমান Location ব্যবহার করুন")
            }
            locationError?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(lat, { lat = it }, label = { Text("Latitude") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(lon, { lon = it }, label = { Text("Longitude") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(prob, { prob = it }, label = { Text("Probability Threshold (%)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(heavyMm, { heavyMm = it }, label = { Text("Heavy Rain Threshold (mm/hr)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(leadTime, { leadTime = it }, label = { Text("Lead Time (hours ahead to check)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(interval, { interval = it }, label = { Text("Check Interval (minutes, min 15)") }, modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                val s = settings.copy(
                    enabled = enabled, latitude = lat.toDoubleOrNull() ?: settings.latitude,
                    longitude = lon.toDoubleOrNull() ?: settings.longitude,
                    probabilityThresholdPercent = prob.toIntOrNull() ?: settings.probabilityThresholdPercent,
                    heavyRainMm = heavyMm.toDoubleOrNull() ?: settings.heavyRainMm,
                    leadTimeHours = leadTime.toIntOrNull() ?: settings.leadTimeHours,
                    checkIntervalMinutes = interval.toIntOrNull() ?: settings.checkIntervalMinutes
                )
                vm.saveSettings(s)
                if (enabled) WeatherAlertWorker.schedule(context, s.checkIntervalMinutes)
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = InfoBlue, contentColor = androidx.compose.ui.graphics.Color.White)) { Text("Settings Save করুন") }

            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = { vm.checkNow(lat.toDoubleOrNull(), lon.toDoubleOrNull()) },
                enabled = !checking,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CyanAccent),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent)
            ) {
                Text(if (checking) "Refresh হচ্ছে…" else "Refresh করে আপডেট দেখুন")
            }

            error?.let { Text(it, color = ErrorRed, modifier = Modifier.padding(top = 8.dp)) }

            cacheAge?.let { age ->
                Text(
                    if (age == 0L) "সর্বশেষ ডেটা: এইমাত্র" else "সর্বশেষ ডেটা: $age মিনিট আগে (cached)",
                    style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.padding(top = 8.dp)
                )
            }

            assessment?.let { a ->
                Spacer(Modifier.height(12.dp))
                val riskColor = when (a.level) {
                    RainRiskCalculator.RiskLevel.HIGH, RainRiskCalculator.RiskLevel.SEVERE -> ErrorRed
                    RainRiskCalculator.RiskLevel.MODERATE -> WarningAmber
                    else -> SuccessGreen
                }
                Card(colors = CardDefaults.cardColors(containerColor = riskColor.copy(alpha = .14f)), border = androidx.compose.foundation.BorderStroke(1.dp, riskColor.copy(alpha = .4f))) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        ColorBadge(Icons.Default.WaterDrop, riskColor, size = 36.dp, iconSize = 18.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("ঝুঁকির মাত্রা: ${a.level}", style = MaterialTheme.typography.titleMedium, color = riskColor, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
                            Text(a.reason, color = TextSecondary)
                            Text("সর্বোচ্চ সম্ভাবনা: ${a.maxProbabilityPercent}%  |  সর্বোচ্চ বৃষ্টিপাত: ${a.maxPrecipitationMm}mm", color = TextSecondary)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "নোট: এই ফিচারের জন্য ইন্টারনেট সংযোগ দরকার (Open-Meteo, কোনো API key লাগে না)। " +
                "কোর বিক্রয়/খরচ এন্ট্রি এর উপর নির্ভর করে না -- সেগুলো সবসময় offline কাজ করবে।",
                style = MaterialTheme.typography.bodySmall, color = TextSecondary
            )
        }
    }
}
