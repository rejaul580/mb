package com.mbcerp.weather

import android.content.Context
import androidx.work.*
import com.mbcerp.MbcErpApp
import java.util.concurrent.TimeUnit

/**
 * Background periodic check (item 5: "background notification"). Runs via WorkManager
 * (survives process death / doze mode better than a plain Service/AlarmManager combo,
 * and is Google's recommended approach for this kind of periodic, deferrable work).
 *
 * DUPLICATE-ALERT PREVENTION: tracked via WeatherAlertSettingsEntity.lastAlertAtMillis
 * and lastAlertedHourBucket -- a new notification only fires if enough wall-clock time
 * has passed (minMinutesBetweenAlerts) AND the risky hour bucket has changed (so the
 * same still-open rain window doesn't re-notify every run, but a genuinely NEW,
 * later-arriving risk window does).
 *
 * OFFLINE CACHE: on a successful fetch, the raw forecast is saved to WeatherCacheEntity
 * so the Weather screen has something to show (with a staleness timestamp) even with
 * no signal; on a failed fetch, the worker falls back to assessing the last cached
 * forecast instead of failing silently.
 *
 * NOT EXECUTED: WorkManager scheduling and the live network fetch cannot be run in
 * this sandbox (no Android runtime, no network). The control flow below has been
 * manually traced against WorkManager's documented Worker contract but not run.
 */
class WeatherAlertWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as MbcErpApp
        val dao = app.database.weatherDao()
        val settings = dao.getSettings() ?: return Result.success() // feature not configured yet
        if (!settings.enabled) return Result.success()

        val forecast = try {
            val client = WeatherApiClient()
            val fetched = client.fetchHourlyForecast(settings.latitude, settings.longitude)
            dao.saveCache(
                WeatherCacheEntity(
                    fetchedAtMillis = System.currentTimeMillis(),
                    latitude = settings.latitude, longitude = settings.longitude,
                    forecastJson = WeatherForecastCodec.encode(fetched)
                )
            )
            fetched
        } catch (e: Exception) {
            // Fetch failed (no signal, DNS, timeout, etc.) -- fall back to last cache
            // rather than doing nothing, so a stale-but-still-useful alert can still fire.
            val cached = dao.getCache() ?: return Result.retry()
            WeatherForecastCodec.decode(cached.forecastJson)
        }

        val thresholds = RainRiskCalculator.Thresholds(
            probabilityThresholdPercent = settings.probabilityThresholdPercent,
            heavyRainMm = settings.heavyRainMm,
            leadTimeHours = settings.leadTimeHours
        )
        val assessment = RainRiskCalculator.assess(forecast, thresholds)

        if (RainRiskCalculator.shouldNotify(assessment.level)) {
            val now = System.currentTimeMillis()
            val minGapMillis = settings.minMinutesBetweenAlerts * 60_000L
            val enoughTimePassed = now - settings.lastAlertAtMillis >= minGapMillis
            val isNewRiskWindow = assessment.firstRiskyHourFromNow != settings.lastAlertedHourBucket

            if (enoughTimePassed && isNewRiskWindow) {
                WeatherNotifier.notify(applicationContext, assessment)
                dao.saveSettings(
                    settings.copy(
                        lastAlertAtMillis = now,
                        lastAlertedHourBucket = assessment.firstRiskyHourFromNow ?: -1
                    )
                )
            }
        }
        return Result.success()
    }

    companion object {
        private const val WORK_NAME = "weather_alert_periodic_check"

        fun schedule(context: Context, intervalMinutes: Int) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<WeatherAlertWorker>(
                intervalMinutes.toLong().coerceAtLeast(15), TimeUnit.MINUTES // WorkManager minimum is 15 min
            ).setConstraints(constraints).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
