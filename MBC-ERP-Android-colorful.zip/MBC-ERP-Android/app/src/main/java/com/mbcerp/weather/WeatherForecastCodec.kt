package com.mbcerp.weather

import org.json.JSONArray

/**
 * Encode/decode for WeatherCacheEntity.forecastJson. Pulled out of WeatherAlertWorker so
 * WeatherViewModel's manual "check now" can write the *same* cache row the background
 * worker does, instead of only updating in-memory UI state (see WeatherScreen.kt).
 */
object WeatherForecastCodec {
    fun encode(points: List<RainRiskCalculator.HourlyForecastPoint>): String {
        val arr = JSONArray()
        points.forEach {
            arr.put(
                org.json.JSONObject()
                    .put("h", it.hoursFromNow)
                    .put("p", it.precipitationProbabilityPercent)
                    .put("mm", it.precipitationMm)
            )
        }
        return arr.toString()
    }

    fun decode(json: String): List<RainRiskCalculator.HourlyForecastPoint> {
        val arr = JSONArray(json)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            RainRiskCalculator.HourlyForecastPoint(o.getInt("h"), o.getInt("p"), o.getDouble("mm"))
        }
    }
}
