# MBC ERP FINAL CLOUD SETUP

This release uses **Google Sheets + Google Apps Script** as the shared cloud data layer. No third-party database service is used.

Follow `GOOGLE_SHEETS_SETUP.md` before building the APK.
