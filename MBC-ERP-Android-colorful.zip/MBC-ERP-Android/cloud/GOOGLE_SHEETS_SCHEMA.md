# Google Sheets schema

## Customers
`recordKey | entity | updatedAt | payload`

## Sales
`recordKey | entity | updatedAt | payload`

## Expenses
`recordKey | entity | updatedAt | payload`

The payload column contains the complete JSON record. This keeps the Android model and spreadsheet transport decoupled and avoids exposing formula/business-logic columns as a fragile public API.
