# MBC ERP — Google Sheets shared database setup

Google Sheets is the shared cloud data store and Google Apps Script is the small API between the Android app and the spreadsheet.

## 1. Create the spreadsheet

Create a blank Google Spreadsheet named `MBC ERP Database`.

The Apps Script will automatically create these tabs:

- Customers
- Sales
- Expenses

## 2. Add the API

Open the spreadsheet:

**Extensions → Apps Script**

Replace the generated code with `cloud/google-apps-script/Code.gs`.

Save it.

## 3. Deploy the Web App

In Apps Script:

**Deploy → New deployment → Web app**

Use:

- Execute as: **Me**
- Who has access: **Anyone**

Copy the Web App URL ending in `/exec`.

## 4. Put the URL in Android

Edit:

`app/src/main/java/com/mbcerp/cloud/GoogleSheetsConfig.kt`

Set `WEB_APP_URL` to the copied `/exec` URL.

## 5. Optional token protection

For a basic write-protection layer, create an Apps Script project property named `API_TOKEN` and give it a random value. Then put the same value in the Android config before building.

Important: a token embedded in an APK is not a secret against a determined attacker. For a high-security production ERP, Google account/OAuth or a proper backend is preferable.

## 6. What is synchronized

This build synchronizes the shared core data:

- Customers
- Sales
- Expenses

Sales/Expense entries are pushed when created/edited/deleted. A background WorkManager job pulls shared Customers/Sales/Expenses approximately every 15 minutes when the Web App URL is configured.

The local Room database remains the offline cache, so the app can still open and work without internet.

## 7. Important first deployment rule

Start with one phone as the initial data owner. Open the app, allow its existing migrated data to be the source, then use the Google Sheet as the shared store. Do not simultaneously seed different datasets from multiple phones.

## 8. Remaining modules

The existing ERP has additional local modules such as Production, Assets, Partner/Majhi setup, Cash adjustments and old-due collections. They remain local in this build and should be moved to shared sheets only after their sync IDs and conflict rules are verified. This is intentional: it prevents duplicate records and accidental financial-data overwrites during the first cloud rollout.
