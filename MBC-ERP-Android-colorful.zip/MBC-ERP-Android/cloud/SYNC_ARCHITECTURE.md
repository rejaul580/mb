# Sync Architecture

- Stable `id` per record.
- `createdAt` and `updatedAt` timestamps.
- Upsert for create/update.
- Explicit delete.
- Download by `updatedAfter` watermark.
- Keep Room for offline operation.
- Do not expose the spreadsheet as a public editor.
