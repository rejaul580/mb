// MBC ERP -- Google Sheets sync backend.
//
// This script is intentionally schema-agnostic: it does NOT hardcode column
// names for Sales/Expenses/Customers etc. Each sheet ("entity") stores three
// columns -- recordKey, updatedAt, payload (a JSON blob of whatever fields
// the Android app sent). This means new fields (or entirely new entities)
// added on the Android side later never require editing this script again.
//
// Wire protocol (must match app/src/main/java/com/mbcerp/cloud/GoogleSheetsGateway.kt):
//   PUSH  -> POST { action:"upsert"|"delete", entity, recordKey, payload, token }
//   PULL  -> GET  ?action=pull&entity=<name>&token=<token>
//            response: { ok:true, records:[ { recordKey, updatedAt, payload }, ... ] }

const SPREADSHEET_ID = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
const API_TOKEN = PropertiesService.getScriptProperties().getProperty('API_TOKEN') || '';

function json_(x) {
  return ContentService.createTextOutput(JSON.stringify(x)).setMimeType(ContentService.MimeType.JSON);
}

function ss_() {
  if (!SPREADSHEET_ID) throw new Error('Set SPREADSHEET_ID in Script Properties (Project Settings).');
  return SpreadsheetApp.openById(SPREADSHEET_ID);
}

function auth_(token) {
  if (!API_TOKEN) return true; // no token configured => open access
  return token === API_TOKEN;
}

// Each entity gets its own sheet/tab, created on first use.
function sheet_(entity) {
  let s = ss_().getSheetByName(entity);
  if (!s) {
    s = ss_().insertSheet(entity);
    s.getRange(1, 1, 1, 3).setValues([['recordKey', 'updatedAt', 'payload']]);
    s.setFrozenRows(1);
  }
  return s;
}

function findRow_(sheet, recordKey) {
  const values = sheet.getDataRange().getValues();
  for (let i = 1; i < values.length; i++) {
    if (String(values[i][0]) === String(recordKey)) return i + 1; // 1-based row index
  }
  return -1;
}

function doGet(e) {
  try {
    const token = (e.parameter && e.parameter.token) || '';
    if (!auth_(token)) return json_({ ok: false, error: 'Unauthorized' });

    const action = (e.parameter.action || 'pull').toLowerCase();
    const entity = e.parameter.entity;
    if (!entity) return json_({ ok: false, error: 'Missing entity' });

    if (action === 'setup') {
      sheet_(entity);
      return json_({ ok: true, entity: entity });
    }
    if (action !== 'pull') return json_({ ok: false, error: 'Unsupported action: ' + action });

    const s = sheet_(entity);
    const values = s.getDataRange().getValues();
    const records = [];
    for (let i = 1; i < values.length; i++) {
      const row = values[i];
      if (!row[0]) continue;
      let payload = {};
      try { payload = JSON.parse(row[2] || '{}'); } catch (err) { payload = {}; }
      records.push({ recordKey: row[0], updatedAt: row[1], payload: payload });
    }
    return json_({ ok: true, entity: entity, records: records });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse((e.postData && e.postData.contents) || '{}');
    const token = body.token || '';
    if (!auth_(token)) return json_({ ok: false, error: 'Unauthorized' });

    const action = (body.action || 'upsert').toLowerCase();
    const entity = body.entity;
    const recordKey = body.recordKey;
    if (!entity || !recordKey) return json_({ ok: false, error: 'Missing entity or recordKey' });

    const s = sheet_(entity);
    const row = findRow_(s, recordKey);

    if (action === 'delete') {
      if (row > 0) s.deleteRow(row);
      return json_({ ok: true, recordKey: recordKey, deleted: true });
    }

    const now = new Date().toISOString();
    const payloadStr = JSON.stringify(body.payload || {});
    const vals = [recordKey, now, payloadStr];
    if (row > 0) s.getRange(row, 1, 1, 3).setValues([vals]);
    else s.getRange(s.getLastRow() + 1, 1, 1, 3).setValues([vals]);

    return json_({ ok: true, recordKey: recordKey, updatedAt: now });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}
