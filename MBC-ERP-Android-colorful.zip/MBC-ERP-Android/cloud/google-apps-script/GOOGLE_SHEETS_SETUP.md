# MBC ERP — Google Sheets Setup

1. Create a Google Spreadsheet named `MBC ERP Database`.
2. Extensions → Apps Script.
3. Paste `Code.gs`.
4. Apps Script → Project Settings → Script Properties:
   - `SPREADSHEET_ID` = the ID from the Sheet URL
   - `API_TOKEN` = a long random secret (recommended)
5. Run `setup()` once and approve permissions.
6. Deploy → New deployment → Web app.
   - Execute as: Me
   - Who has access: Anyone with the link
7. Copy the `/exec` URL and put it into the Android Google Sheets endpoint configuration.
8. Do not make the spreadsheet publicly editable. Users should work through the app.
