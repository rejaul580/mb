#!/usr/bin/env bash
set -euo pipefail
if grep -RniE 'supabase|Supabase' app/src cloud --exclude-dir=build; then
  echo 'ERROR: Supabase reference found.'
  exit 1
fi
for f in app/src/main/java/com/mbcerp/cloud/GoogleSheetsGateway.kt app/src/main/java/com/mbcerp/cloud/GoogleSheetsSyncManager.kt cloud/google-apps-script/Code.gs; do
  test -f "$f" || { echo "ERROR: missing $f"; exit 1; }
done
echo 'Google Sheets migration sanity check passed.'
