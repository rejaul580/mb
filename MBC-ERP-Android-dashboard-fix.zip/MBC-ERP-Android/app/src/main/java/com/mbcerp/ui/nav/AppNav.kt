package com.mbcerp.ui.nav

import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mbcerp.MbcErpApp
import com.mbcerp.R
import com.mbcerp.ui.asset.*
import com.mbcerp.ui.audit.*
import com.mbcerp.ui.cash.*
import com.mbcerp.ui.dashboard.*
import com.mbcerp.ui.expense.*
import com.mbcerp.ui.ledger.*
import com.mbcerp.ui.print.*
import com.mbcerp.ui.production.*
import com.mbcerp.ui.registers.*
import com.mbcerp.ui.sales.*
import com.mbcerp.ui.setup.SetupScreen
import com.mbcerp.ui.setup.SetupViewModel
import com.mbcerp.ui.setup.SetupViewModelFactory

/**
 * Full navigation graph. Bottom nav holds the 4 highest-traffic daily screens (mirrors
 * Dashboard's most-used Quick Menu links, AUDIT §5.2); everything else (Ledgers,
 * Registers, Cash Summary, Production, Asset, Audit, Print, Weather) lives
 * behind a "More" menu sheet -- the Android equivalent of the source Dashboard's full
 * 17-link Quick Menu, without needing a 12-tab bottom bar.
 *
 * Labels use @StringRes references resolved via stringResource() at render time
 * (rather than a plain String field) so the nav is actually locale-aware -- picks up
 * values-en/strings.xml automatically on an English-locale device instead of always
 * showing the Bengali default, unlike the previous hardcoded-String version.
 */
private sealed class Dest(val route: String, @StringRes val labelRes: Int, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Dashboard : Dest("dashboard", R.string.nav_dashboard, Icons.Default.Home)
    object SalesList : Dest("sales_list", R.string.nav_sales, Icons.Default.ShoppingCart)
    object SalesEntry : Dest("sales_entry", R.string.nav_new_sale, Icons.Default.Add)
    object ExpenseList : Dest("expense_list", R.string.nav_expense, Icons.Default.Receipt)
    object ExpenseEntry : Dest("expense_entry", R.string.nav_new_expense, Icons.Default.Add)
    object More : Dest("more", R.string.nav_more, Icons.Default.Menu)
    object Reports : Dest("reports", R.string.nav_reports, Icons.Default.BarChart)
    object Setup : Dest("setup", R.string.nav_setup, Icons.Default.Settings)
    object Ledger : Dest("ledger", R.string.nav_ledger, Icons.Default.People)
    object Registers : Dest("registers", R.string.nav_registers, Icons.Default.LocalGasStation)
    object LedgerViewer : Dest("ledger_viewer", R.string.nav_ledger_viewer, Icons.Default.List)
    object CashSummary : Dest("cash_summary", R.string.nav_cash_summary, Icons.Default.AccountBalance)
    object Production : Dest("production", R.string.nav_production, Icons.Default.Factory)
    object AssetRegister : Dest("asset_register", R.string.nav_asset_register, Icons.Default.Domain)
    object Audit : Dest("audit", R.string.nav_audit, Icons.Default.FactCheck)
    object DeliveryChallan : Dest("delivery_challan", R.string.nav_delivery_challan, Icons.Default.LocalShipping)
    object MoneyReceipt : Dest("money_receipt", R.string.nav_money_receipt, Icons.Default.ReceiptLong)
    object Weather : Dest("weather", R.string.nav_weather, Icons.Default.Cloud)
}

private val bottomTabs = listOf(Dest.Dashboard, Dest.SalesList, Dest.ExpenseList, Dest.Production, Dest.Reports, Dest.More)
private val moreMenuItems = listOf(
    Dest.Setup, Dest.Ledger, Dest.Registers, Dest.LedgerViewer, Dest.CashSummary,
    Dest.Production, Dest.AssetRegister, Dest.Audit, Dest.DeliveryChallan, Dest.MoneyReceipt,
    Dest.Weather
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavHost(app: MbcErpApp) {
    val navController = rememberNavController()
    var showMoreSheet by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = com.mbcerp.ui.theme.AppBlack, tonalElevation = 0.dp, modifier = Modifier.height(68.dp)) {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = backStackEntry?.destination
                bottomTabs.forEach { dest ->
                    val label = stringResource(dest.labelRes)
                    NavigationBarItem(
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = com.mbcerp.ui.theme.BrickOrangeBright, selectedTextColor = com.mbcerp.ui.theme.BrickOrangeBright, unselectedIconColor = com.mbcerp.ui.theme.TextSecondary, unselectedTextColor = com.mbcerp.ui.theme.TextSecondary, indicatorColor = Color.Transparent),
                        selected = currentDestination?.hierarchy?.any { it.route == dest.route } == true,
                        onClick = {
                            if (dest == Dest.More) showMoreSheet = true
                            else navController.navigate(dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = label) },
                        label = { Text(label, fontSize = 8.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Dashboard.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Dest.Dashboard.route) {
                val vm: DashboardViewModel = viewModel(factory = DashboardViewModelFactory(app.dashboardRepository, app.googleSheetsSyncManager))
                DashboardScreen(
                    vm,
                    onWeatherClick = { navController.navigate(Dest.Weather.route) },
                    onAddSaleClick = { navController.navigate(Dest.SalesEntry.route) },
                    onExpenseClick = { navController.navigate(Dest.ExpenseEntry.route) },
                    onProductionClick = { navController.navigate(Dest.Production.route) },
                    onMoreClick = { showMoreSheet = true }
                )
            }
            composable(Dest.SalesList.route) {
                val vm: SalesListViewModel = viewModel(factory = SalesListViewModelFactory(app.salesRepository))
                SalesListScreen(vm, onAddClick = { navController.navigate(Dest.SalesEntry.route) })
            }
            composable(Dest.SalesEntry.route) {
                val vm: SalesEntryViewModel = viewModel(factory = SalesEntryViewModelFactory(app.salesRepository, app.setupRepository))
                SalesEntryScreen(vm, onSaved = { navController.popBackStack() })
            }
            composable(Dest.ExpenseList.route) {
                val vm: ExpenseListViewModel = viewModel(factory = ExpenseListViewModelFactory(app.expenseRepository))
                ExpenseListScreen(vm, onAddClick = { navController.navigate(Dest.ExpenseEntry.route) })
            }
            composable(Dest.ExpenseEntry.route) {
                val vm: ExpenseEntryViewModel = viewModel(factory = ExpenseEntryViewModelFactory(app.expenseRepository, app.setupRepository))
                ExpenseEntryScreen(vm, onSaved = { navController.popBackStack() })
            }
            composable(Dest.Reports.route) {
                val vm: CashSummaryViewModel = viewModel(factory = CashSummaryViewModelFactory(app.cashSummaryRepository, app.setupRepository))
                CashSummaryScreen(vm)
            }
            composable(Dest.Setup.route) {
                val vm: SetupViewModel = viewModel(factory = SetupViewModelFactory(app.setupRepository))
                SetupScreen(vm)
            }
            composable(Dest.Ledger.route) {
                val vm: LedgerViewModel = viewModel(factory = LedgerViewModelFactory(app.ledgerRepository, app.setupRepository))
                LedgerScreen(vm)
            }
            composable(Dest.Registers.route) {
                val vm: RegistersViewModel = viewModel(factory = RegistersViewModelFactory(app.registerRepository, app.setupRepository))
                RegistersScreen(vm)
            }
            composable(Dest.LedgerViewer.route) {
                val vm: LedgerViewerViewModel = viewModel(factory = LedgerViewerViewModelFactory(app.registerRepository, app.setupRepository))
                LedgerViewerScreen(vm)
            }
            composable(Dest.CashSummary.route) {
                val vm: CashSummaryViewModel = viewModel(factory = CashSummaryViewModelFactory(app.cashSummaryRepository, app.setupRepository))
                CashSummaryScreen(vm)
            }
            composable(Dest.Production.route) {
                val vm: ProductionViewModel = viewModel(factory = ProductionViewModelFactory(app.productionRepository))
                ProductionScreen(vm)
            }
            composable(Dest.AssetRegister.route) {
                val vm: AssetRegisterViewModel = viewModel(factory = AssetRegisterViewModelFactory(app.assetRegisterRepository))
                AssetRegisterScreen(vm)
            }
            composable(Dest.Audit.route) {
                val vm: AuditViewModel = viewModel(factory = AuditViewModelFactory(app.auditRepository))
                AuditScreen(vm)
            }
            composable(Dest.DeliveryChallan.route) {
                val vm: DeliveryChallanViewModel = viewModel(factory = DeliveryChallanViewModelFactory(app.printRepository))
                DeliveryChallanScreen(vm)
            }
            composable(Dest.MoneyReceipt.route) {
                val vm: MoneyReceiptViewModel = viewModel(factory = MoneyReceiptViewModelFactory(app.printRepository))
                MoneyReceiptScreen(vm)
            }
            composable(Dest.Weather.route) {
                val vm: com.mbcerp.ui.weather.WeatherViewModel = viewModel(
                    factory = com.mbcerp.ui.weather.WeatherViewModelFactory(app.database.weatherDao())
                )
                com.mbcerp.ui.weather.WeatherScreen(vm)
            }
        }
    }

    if (showMoreSheet) {
        ModalBottomSheet(onDismissRequest = { showMoreSheet = false }, containerColor = com.mbcerp.ui.theme.AppSurface) {
            LazyColumn {
                items(moreMenuItems) { dest ->
                    val label = stringResource(dest.labelRes)
                    ListItem(
                        headlineContent = { Text(label) },
                        leadingContent = { Icon(dest.icon, contentDescription = null) },
                        modifier = Modifier.clickable {
                            showMoreSheet = false
                            navController.navigate(dest.route) {
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                    Divider()
                }
            }
        }
    }
}
